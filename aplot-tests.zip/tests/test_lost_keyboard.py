"""Test (1.7.0): the diagram takes back a keyboard that Tk has lost.

On a Mac Tk sometimes believes that no window of the program has the
keyboard while the diagram is still the window in front (after a property
window was closed, after clicking between windows).  `focus` then only
remembers the canvas, and every key - the arrows that move the selected
legend too - was thrown away until another program had been in front.

The lost keyboard cannot be brought about on purpose, so here Tk is made
to report it: a click in the diagram, the closing of a property window and
the claim of a window that was activated take it with force then; the
rest (an in-place editor closed because another program came in front)
must not pull the program forward.
"""
import os, sys, tempfile

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from keys_help import Keys

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))
keys = Keys(root, real=False)
x = np.linspace(0.0, 10.0, 12)
app.table.set_dataframe(pd.DataFrame({"x": x, "y1": np.sin(x)}), check_all=True)
keys.settle(4)
plot = app.open_plot("line_symbol")
keys.settle(12)
canvas = plot.canvas.get_tk_widget()

forced = []
real_force = canvas.focus_force
canvas.focus_force = lambda: (forced.append(1), real_force())[1]
lost = {"on": False}
real_holder = plot._keyboard_holder
plot._keyboard_holder = lambda: None if lost["on"] else real_holder()


def forces(action, what):
    forced.clear()
    action()
    keys.settle(3)
    return bool(forced)


# the keyboard is where Tk says: nothing is forced, a click or not
lost["on"] = False
assert not forces(lambda: plot.take_focus(object()), "click"), "forced at once"
assert not forces(plot.take_focus, "plain"), "forced at once"

# Tk has lost it: a click takes it with force ...
lost["on"] = True
assert forces(lambda: plot.take_focus(object()), "click"), \
    "a click left the keyboard lost"
# ... and so does a property window that is closed
dialog = plot.open_title_dialog()
keys.settle(20)
assert forces(dialog.close, "close"), "closing a window left the keyboard lost"
# ... and the window in front that claims it
plot._active = True
aplot.PlotWindow._keyboard_claim = (None, 0.0)
plot._focus_seen = canvas
assert forces(plot._claim_keyboard, "claim"), "the claim left the keyboard lost"
# but without a click (the in-place editor closed when another program
# came in front) the program is not pulled forward
assert not forces(plot.take_focus, "plain"), "forced without a click"
print("a lost keyboard is taken back by a click, a closed window, a claim ok")

lost["on"] = False
assert not errors, errors
print("ALL OK")
