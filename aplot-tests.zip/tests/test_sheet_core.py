"""Headless regression test of the spreadsheet with the 1000-row sheets:
typing, formulas, the fill handle inside the sheet (four directions, series),
new rows at the end, a diagram of a partly filled sheet, a file round trip,
Undo - and that it all stays quick."""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

started = time.perf_counter()
root = tk.Tk()
root.geometry("1100x620+0+0")
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=3):
    for _ in range(times):
        root.update()
        time.sleep(0.02)
        root.update()


settle(4)
took = time.perf_counter() - started
table = app.table
tree = table.tree
assert len(table.df) == 1000
assert took < 8.0, took
print(f"the program starts with a 1000-row sheet in {took:.2f} s ok")


def write(row, column, text):
    table.select_cell(row, column)
    table._begin_edit(str(row), column)
    settle(1)
    table._editor[1].set(text)
    started = time.perf_counter()
    table._commit_edit()
    settle(1)
    return time.perf_counter() - started


# -- 1. typing and formulas in a big sheet ------------------------------------
slowest = 0.0
for row in range(30):
    slowest = max(slowest, write(row, 0, str(row + 1)))
slowest = max(slowest, write(0, 1, "=A1^2"))
assert table.blank_sheet() is False
assert float(table.df.iat[0, 1]) == 1.0
assert slowest < 0.5, f"one cell took {slowest:.3f} s"
print(f"typing into the 1000-row sheet: at most {slowest * 1000:.0f} ms a cell ok")


class Spot:
    def __init__(self, x_root, y_root):
        self.x_root, self.y_root, self.x, self.y = int(x_root), int(y_root), 0, 0


def pull(to_row, to_column):
    """Pull the fill handle of the selection to a cell on the screen."""
    table._refresh_outline()
    settle(1)
    handle = table._get_fill_handle()
    table._on_fill_press(Spot(handle.winfo_rootx() + 3, handle.winfo_rooty() + 3))
    tree.see(str(to_row))
    settle(1)
    box = tree.bbox(str(to_row), f"#{to_column + 1}")
    assert box, (to_row, to_column)
    spot = Spot(tree.winfo_rootx() + box[0] + box[2] // 2,
                tree.winfo_rooty() + box[1] + box[3] // 2)
    table._on_fill_drag(spot)
    settle(1)
    table._on_fill_release(spot)
    settle(2)


# -- 2. the fill handle inside the sheet: never grows it -------------------------
table.select_cell(0, 1)
pull(9, 1)                                        # down
assert [table.cell_formulas.get((r, 1)) for r in (1, 9)] == ["=A2^2", "=A10^2"]
assert float(table.df.iat[9, 1]) == 100.0
assert len(table.df) == 1000
table.select_cell(0, 1)
pull(0, 3)                                        # to the right
assert table.cell_formulas.get((0, 3)) == "=C1^2", table.cell_formulas.get((0, 3))
assert len(table.df.columns) >= 4
write(20, 4, "7")
table.select_cell(20, 4)
pull(17, 4)                                       # up
assert [str(table.df.iat[r, 4]) for r in (17, 18, 19)] == ["7", "7", "7"]
write(25, 4, "1")
write(26, 4, "3")
table.select_block(25, 4, 26, 4, anchor=(25, 4), cursor=(26, 4))
pull(29, 4)                                       # a series
assert [str(table.df.iat[r, 4]) for r in (27, 28, 29)] == ["5", "7", "9"], \
    [table.df.iat[r, 4] for r in (27, 28, 29)]
assert len(table.df) == 1000
print("the fill handle fills down, right, up and series inside the sheet ok")

# -- 3. a row at the end, and Undo -------------------------------------------
index = table.add_row()
assert index == 1000 and len(table.df) == 1001
assert tree.exists("1000") and table.row_tree.exists("1000")
app.undo_step()
settle(2)
table = app.table
tree = table.tree
assert len(table.df) == 1000, len(table.df)
app.undo_step()
settle(2)
table = app.table
tree = table.tree
assert str(table.df.iat[29, 4]) in ("", "nan"), table.df.iat[29, 4]
app.redo_step()
settle(2)
table = app.table
tree = table.tree
assert str(table.df.iat[29, 4]) == "9"
print("a new row at the end, Undo and Redo ok")

# -- 4. a diagram of a partly filled 1000-row sheet ---------------------------
for column in range(2, len(table.df.columns)):
    if column != 1:
        table.set_column_axis(table.df.columns[column], None)
settle(1)
plot = app.open_plot("line")
settle(6)
line = plot.series[list(plot.series)[0]]
xs, ys = line.get_data()
xs = np.asarray(xs, dtype=float)
ys = np.asarray(ys, dtype=float)
drawn = np.isfinite(xs) & np.isfinite(ys)
assert int(drawn.sum()) == 10, int(drawn.sum())     # the rows that have both
assert float(ys[drawn].max()) == 100.0
low, high = plot.ax.get_xlim()
assert low <= 1.0 and 10.0 <= high <= 40.0, (low, high)   # not up to row 1000
plot.canvas.draw()
print("the diagram draws only the filled rows of the 1000 ok")

# -- 5. the file keeps the 1000 rows and the formulas ---------------------------
path = os.path.join(HOME, "big.aplt")
started = time.perf_counter()
assert app.save_project(path) == path
saved = time.perf_counter() - started
size = os.path.getsize(path)
document = aplot.read_project_document(path)
assert len(document["tabs"][0]["rows"]) == 1000
assert app.load_project(path) is True
settle(4)
table = app.table
assert len(table.df) == 1000
assert table.cell_formulas.get((9, 1)) == "=A10^2"
assert float(table.df.iat[9, 1]) == 100.0
print(f"saved ({size // 1024} KB, {saved:.2f} s) and opened again ok")

# -- 6. a new sheet, and a pasted block --------------------------------------
started = time.perf_counter()
app.add_sheet()
settle(3)
took = time.perf_counter() - started
assert len(app.tables) == 2 and len(app.table.df) == 1000
assert took < 3.0, took
print(f"a new 1000-row sheet in {took * 1000:.0f} ms ok")

root.destroy()
print("ALL OK")
