"""Real keys and clicks for the keyboard tests (1.3.8).

With `xdotool` installed every key is typed and every click is made for
real, through the X server: it reaches the window - and inside it the
widget - that holds the keyboard at that very moment, exactly as the key of
a person would.  A window manager (`openbox`, started here when it is
installed) moves the keyboard from window to window as they are clicked,
the way a desktop does.

Without `xdotool` the key is handed to the widget that Tk itself says owns
the keyboard, through all of its bindings, so the same checks still run -
only the part the window manager plays is left out.
"""
import os
import shutil
import subprocess
import time
import tkinter as tk

XDOTOOL = shutil.which("xdotool")
OPENBOX = shutil.which("openbox")

# the characters that are not their own key name, for the same fallback
_KEYSYMS = {" ": "space", ".": "period", "-": "minus", ",": "comma",
            "=": "equal", "*": "asterisk", "+": "plus", "/": "slash",
            "(": "parenleft", ")": "parenright", ":": "colon", ";": "semicolon",
            "^": "asciicircum", "_": "underscore"}
# xdotool names -> Tk names, for the fallback without xdotool
_TK_MODIFIERS = {"ctrl": "Control", "shift": "Shift", "alt": "Alt",
                 "super": "Mod4"}


class Keys:
    """Types keys, clicks and drags - for real when that is possible."""

    def __init__(self, root, real=True, window_manager=True):
        self.root = root
        # APLOT_TEST_KEYS=tk runs the same tests without xdotool
        real = real and os.environ.get("APLOT_TEST_KEYS", "") != "tk"
        self.real = bool(real and XDOTOOL and os.environ.get("DISPLAY"))
        self._pointer = None         # where the pointer was moved last
        self.caps = False            # Caps Lock and Num Lock, as pressed
        self.num = False
        self.wm = None
        if self.real and window_manager and OPENBOX:
            self.wm = subprocess.Popen([OPENBOX], stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL)
            time.sleep(1.0)
        self.settle(6)

    @property
    def how(self):
        if not self.real:
            return "keys handed to Tk (no xdotool)"
        return ("real keys and clicks, xdotool" +
                (" + openbox" if self.wm is not None else ""))

    def close(self):
        if self.wm is not None:
            self.wm.terminate()
            try:
                self.wm.wait(3)
            except subprocess.TimeoutExpired:
                self.wm.kill()
            self.wm = None

    # -- waiting for Tk ---------------------------------------------------
    def settle(self, times=4, pause=0.03):
        for _ in range(times):
            try:
                self.root.update()
            except tk.TclError:
                return
            time.sleep(pause)
            try:
                self.root.update()
            except tk.TclError:
                return

    def _move_to(self, x, y):
        """Move the pointer (--sync waits for it - forever when it is
        there already, so a move to the same place is left out)."""
        x, y = int(x), int(y)
        if self._pointer != (x, y):
            self._x("mousemove", "--sync", str(x), str(y))
            self._pointer = (x, y)

    def _x(self, *args):
        try:                    # never hang a test on a pointer that waits
            subprocess.run([XDOTOOL, *args], check=False, timeout=20,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except subprocess.TimeoutExpired:
            pass

    # -- the keyboard -----------------------------------------------------
    def focus(self):
        """The widget that holds the keyboard (or None)."""
        try:
            return self.root.focus_get()
        except (tk.TclError, KeyError):
            return None

    def press(self, *keys, wait=4):
        """Press keys one after the other: "Tab", "shift+Tab", "ctrl+s"..."""
        for key in keys:
            if self.real:
                self._x("key", "--delay", "15", key)
            else:
                self._generate(key)
            self.settle(wait)

    def lock(self, which, on):
        """Caps Lock ("caps") or Num Lock ("num") on or off."""
        attribute = "caps" if which == "caps" else "num"
        if bool(getattr(self, attribute)) == bool(on):
            return
        setattr(self, attribute, bool(on))
        if self.real:
            self._x("key", "Caps_Lock" if which == "caps" else "Num_Lock")
            self.settle(3)

    def burst(self, *keys):
        """Keys typed all at once, faster than the program takes them."""
        if self.real:
            self._x("key", "--delay", "0", *keys)
        else:
            for key in keys:
                self._generate(key)
        self.settle(10)

    def type(self, text, wait=4):
        """Type a text, character by character."""
        if self.real:
            self._x("type", "--delay", "15", text)
            self.settle(wait)
            return
        for char in text:
            widget = self.focus() or self.root
            keysym = _KEYSYMS.get(char, char)
            widget.event_generate("<KeyPress>", keysym=keysym, when="now")
            self.settle(1)
        self.settle(wait)

    def _generate(self, key):
        parts = key.split("+")
        name = parts[-1]
        modifiers = [_TK_MODIFIERS.get(one.lower(), one) for one in parts[:-1]]
        if "Shift" in modifiers and len(name) == 1:
            name = name.upper()
        if name == "Tab" and "Shift" in modifiers:
            name = "ISO_Left_Tab"
        if self.caps and len(name) == 1 and name.isalpha():
            # Tk would add Shift to a capital letter made up here, so the
            # small one is sent with Lock (as some systems report it, too)
            modifiers.insert(0, "Lock")
        if self.num:
            modifiers.insert(0, "Mod2")
        widget = self.focus() or self.root
        sequence = "<" + "-".join(modifiers + ["KeyPress", name]) + ">"
        widget.event_generate(sequence, when="now")

    # -- the pointer ------------------------------------------------------
    def _spot(self, widget, x, y):
        self.settle(2)
        if x is None:
            x = widget.winfo_width() // 2
        if y is None:
            y = widget.winfo_height() // 2
        return widget.winfo_rootx() + int(x), widget.winfo_rooty() + int(y)

    def click(self, widget, x=None, y=None, button=1, double=False, wait=5):
        """Click a widget - in its middle, or at (x, y) inside it."""
        rx, ry = self._spot(widget, x, y)
        if self.real:
            self._move_to(rx, ry)
            self.settle(1)
            if double:
                self._x("click", "--repeat", "2", "--delay", "80", str(button))
            else:
                self._x("click", str(button))
        else:
            lx, ly = rx - widget.winfo_rootx(), ry - widget.winfo_rooty()
            for _ in range(2 if double else 1):
                widget.event_generate("<ButtonPress-%d>" % button, x=lx, y=ly,
                                      rootx=rx, rooty=ry, when="now")
                widget.event_generate("<ButtonRelease-%d>" % button, x=lx,
                                      y=ly, rootx=rx, rooty=ry, when="now")
        self.settle(wait)

    def drag(self, widget, start, end, steps=10, wait=6):
        """Press at `start` (x, y inside the widget), move, release at `end`."""
        x0, y0 = self._spot(widget, *start)
        x1, y1 = self._spot(widget, *end)
        if not self.real:
            target = widget
            target.event_generate("<ButtonPress-1>", x=start[0], y=start[1],
                                  rootx=x0, rooty=y0, when="now")
            for step in range(1, steps + 1):
                x = x0 + (x1 - x0) * step // steps
                y = y0 + (y1 - y0) * step // steps
                target.event_generate("<B1-Motion>", x=x - widget.winfo_rootx(),
                                      y=y - widget.winfo_rooty(), rootx=x,
                                      rooty=y, state=0x100, when="now")
                self.settle(1)
            target.event_generate("<ButtonRelease-1>", x=end[0], y=end[1],
                                  rootx=x1, rooty=y1, state=0x100, when="now")
            self.settle(wait)
            return
        self._move_to(x0, y0)
        self.settle(1)
        self._x("mousedown", "1")
        self.settle(2)
        for step in range(1, steps + 1):
            x = x0 + (x1 - x0) * step // steps
            y = y0 + (y1 - y0) * step // steps
            self._move_to(x, y)
            self.settle(1)
        self._x("mouseup", "1")
        self.settle(wait)

    def _windows(self):
        found, stack = [], [self.root]
        while stack:
            widget = stack.pop()
            if isinstance(widget, (tk.Tk, tk.Toplevel)):
                found.append(widget)
            stack.extend(widget.winfo_children())
        return found

    @staticmethod
    def _frame(window):
        """(left, top, right, bottom) of a window with its frame: the place
        `wm geometry` gives is where the window manager put the frame (the
        top of the title bar); the window itself - with its menu bar on
        Linux - is below that."""
        place = str(window.wm_geometry())
        _size, _, rest = place.partition("+")
        x, _, y = rest.partition("+")
        left, top = int(x), int(y)
        right = window.winfo_rootx() + window.winfo_width() + 6
        bottom = window.winfo_rooty() + window.winfo_height() + 6
        return left - 2, top - 2, right, bottom

    def _title_spot(self, window):
        """A point of the title bar of `window` that no other window of the
        program covers (clear of its icon and of its buttons), or None."""
        try:
            left, top, right, _bottom = self._frame(window)
            y = top + 12
            covers = [self._frame(other) for other in self._windows()
                      if other is not window and other.winfo_ismapped()]
        except (tk.TclError, ValueError):
            return None
        if y < 1 or y >= window.winfo_rooty():
            return None
        for x in range(left + 36, max(left + 37, right - 90), 12):
            if not any(a <= x <= c and b <= y <= d for a, b, c, d in covers):
                return x, y
        return None

    def activate(self, window):
        """Bring a window to the front, as a click on its title bar does.

        With a window manager its title bar is really clicked; Tk then
        hands the keyboard to whichever widget of that window had it last,
        all by itself.  Without one, the same is done by hand.
        """
        self.settle(2)
        spot = self._title_spot(window) if self.real and self.wm else None
        if spot is not None:
            self._move_to(spot[0], spot[1])
            self.settle(1)
            self._x("click", "1")
            self.settle(8)
            return
        try:
            window.lift()
            last = window.focus_lastfor() or window
            last.focus_force()
        except tk.TclError:
            pass
        self.settle(6)
