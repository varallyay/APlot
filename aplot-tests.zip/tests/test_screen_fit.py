"""Headless test (1.1.1): the property windows open fully on the screen -
beside the diagram when there is room, never out past the right edge or
behind the Dock - and the text of the windows can be made smaller (it is
85 % on a Mac by default)."""
import json, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
from tkinter import font as tkfont
import numpy as np
import pandas as pd
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
# the screen of a Mac: the menu bar on top, the Dock at the bottom
aplot.SCREEN_MARGINS["default"] = aplot.SCREEN_MARGINS["darwin"]

assert aplot.DEFAULTS["window"]["ui_scale"] == (85 if sys.platform == "darwin" else 100)

root = tk.Tk()
before = {name: int(tkfont.nametofont(name).cget("size")) for name in aplot.UI_FONTS}
settings = aplot.Config(os.path.join(HOME, "settings.json"))
settings.set("window", "ui_scale", 85)
app = aplot.App(root, settings)


def settle(times=3, pause=0.02):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


settle(4)
screen_w, screen_h = root.winfo_screenwidth(), root.winfo_screenheight()
left, top, right, bottom = aplot.usable_screen(root)
assert (left, top) == (aplot.SCREEN_SIDE, 40) and right == screen_w - aplot.SCREEN_SIDE
assert bottom <= screen_h - 96, bottom
print(f"screen {screen_w}x{screen_h}: windows may use {left},{top} .. {right},{bottom} ok")

# -- 1. the text of the windows at 85 % -----------------------------------
size = abs(int(tkfont.nametofont("TkDefaultFont").cget("size")))
assert size == max(7, round(abs(before["TkDefaultFont"]) * 0.85)), (size, before)
assert aplot.scale_interface_fonts(root, 100) == before["TkDefaultFont"]
assert aplot.scale_interface_fonts(root, 85) == aplot.scale_interface_fonts(root, 85)
assert abs(aplot.scale_interface_fonts(root, 1)) == max(
    7, round(abs(before["TkDefaultFont"]) * aplot.UI_SCALE_RANGE[0] / 100))
assert aplot.scale_interface_fonts(root, "nonsense") == before["TkDefaultFont"]
aplot.scale_interface_fonts(root, 85)
dialog = app.open_settings()
settle(2)
labels = []


def walk(widget):
    for child in widget.winfo_children():
        try:
            labels.append(str(child.cget("text")))
        except tk.TclError:
            pass
        walk(child)


walk(dialog)
assert any("Text size of the windows" in one for one in labels)
dialog.destroy()
print(f"the text of the windows at 85 %: {before['TkDefaultFont']} -> {size} points ok")

# -- 2. the diagram is no larger than the screen leaves room for ------------
x = np.linspace(0.0, 10.0, 30)
app.table.set_dataframe(pd.DataFrame({"x": x, "y": np.sin(x) + 3.0}), check_all=True)
settle(2)
plot = app.open_plot("line")
settle(6)
assert plot.winfo_height() + aplot.TITLE_BAR <= bottom - top, plot.winfo_height()
assert aplot.geometry_on_screen(root, "1200x900") == \
    f"1200x{min(900, bottom - top - aplot.TITLE_BAR)}"
fitted = aplot.geometry_on_screen(root, f"1200x863+{screen_w - 100}+{screen_h}")
w, rest = fitted.split("x")
h, gx, gy = rest.split("+")
assert int(gx) + int(w) <= right and int(gy) + int(h) + aplot.TITLE_BAR <= bottom, fitted
assert aplot.geometry_on_screen(root, "800x600+-50+-20") == f"800x600+{left}+{top}"
assert aplot.geometry_on_screen(root, "nonsense") == "nonsense"
print("the diagram window fits the screen, a saved place too ok")


# -- 3. every property window opens fully on the screen -----------------------
def inside(window, label):
    settle(20)                       # it is looked at again after 250 ms
    x0, y0 = window.winfo_rootx(), window.winfo_rooty()
    x1, y1 = x0 + window.winfo_width(), y0 + window.winfo_height()
    assert x0 >= left and x1 <= right, (label, x0, x1, right)
    assert y0 >= top and y1 <= bottom, (label, y0, y1, bottom)
    return x0, y0, x1, y1


plot.geometry(f"+0+{top}")
settle(4)
opened = {
    "curve": plot.open_series_dialog(plot.series[list(plot.series)[0]]),
    "axes": plot.open_axes_dialog("x"),
}
for label, window in opened.items():
    box = inside(window, label)
    print(f"  {label:6} {box[2] - box[0]}x{box[3] - box[1]} at {box[0]},{box[1]}")
for window in opened.values():
    window.close()
settle(2)
print("the curve and the axes windows open fully on the screen ok")

# a narrow diagram at the left: the window opens beside it, its top level
plot.geometry(f"500x500+0+{top + 60}")
settle(6)
window = plot.open_series_dialog(plot.series[list(plot.series)[0]])
x0, y0, x1, y1 = inside(window, "beside")
assert x0 >= plot.winfo_rootx() + plot.winfo_width(), (x0, plot.winfo_width())
assert abs(y0 - (plot.winfo_rooty() - aplot.TITLE_BAR)) <= 2 or y0 == top, \
    (y0, plot.winfo_rooty())
window.close()
# a diagram at the right edge: the window opens on its left
plot.geometry(f"500x500+{screen_w - 520}+{top + 60}")
settle(6)
window = plot.open_series_dialog(plot.series[list(plot.series)[0]])
x0, y0, x1, y1 = inside(window, "left of it")
assert x1 <= plot.winfo_rootx(), (x1, plot.winfo_rootx())
window.close()
# a diagram low on the screen: the window is pulled up, clear of the Dock
plot.geometry(f"500x300+0+{screen_h - 330}")
settle(6)
window = plot.open_axes_dialog("x")
inside(window, "low")
window.close()
settle(2)
print("beside the diagram when there is room, left of it, never behind the Dock ok")

# a window that grows after it has opened is brought back as well
window = plot.open_series_dialog(plot.series[list(plot.series)[0]])
settle(20)
window.geometry(f"+{screen_w - 50}+{screen_h - 50}")
settle(4)
assert window.keep_on_screen() is True
inside(window, "moved back")
window.close()
print("a window that sticks out is moved back onto the screen ok")

# -- 4. a saved setting is applied when the settings are saved -------------
app.settings.set("window", "ui_scale", 100)
app._settings_saved = app._settings_saved      # (the dialog calls this)
aplot.messagebox.showinfo = lambda *a, **k: None
app._settings_saved()
assert int(tkfont.nametofont("TkDefaultFont").cget("size")) == before["TkDefaultFont"]
print("a new text size is applied at once ok")

assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.1.1") and "| 1.1.1 | 2026-10-03 |" in aplot.DOCUMENTATION
print("version 1.1.1 or later ok")

root.destroy()
print("ALL OK")
