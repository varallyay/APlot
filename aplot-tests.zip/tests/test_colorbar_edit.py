"""Headless test (1.4.4): the colour bar of the three x, y, z styles -
colour surface, contour lines, filled contours - and of a 2D histogram is
an object of the diagram.  One click selects it, it is dragged to another
place and resized by its eight control points, it lies down when it is
made wider than tall, the arrow keys move it, and all of it is kept by the
curve dialog, by Undo, by a saved diagram and by the exported program.
Its label is written in place by a slow second click and opens a window
of its own on a double click, as the title and the axis labels do.
"""
import math, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from matplotlib.backend_bases import MouseEvent

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def close_all():
    for window in app.open_windows():
        window.destroy()
    settle(2)


def near(a, b, tol=1e-6):
    return all(math.isclose(p, q, abs_tol=tol) for p, q in zip(a, b))


def mouse(plot, name, x, y, dblclick=False):
    event = MouseEvent(name, plot.canvas, x, y, button=1, dblclick=dblclick)
    {"button_press_event": plot._on_button_press,
     "motion_notify_event": plot._on_motion,
     "button_release_event": plot._on_release}[name](event)


def click(plot, x, y, dblclick=False):
    mouse(plot, "button_press_event", x, y, dblclick)
    mouse(plot, "button_release_event", x, y)
    settle(2)


def drag(plot, start, end, steps=5):
    mouse(plot, "button_press_event", *start)
    for step in range(1, steps + 1):
        mouse(plot, "motion_notify_event",
              start[0] + (end[0] - start[0]) * step / steps,
              start[1] + (end[1] - start[1]) * step / steps)
    mouse(plot, "button_release_event", *end)
    settle(2)


def bar_middle(plot, column="y"):
    plot.canvas.draw()
    box = plot.hist2d_bars[column].ax.get_window_extent()
    return (0.5 * (box.x0 + box.x1), 0.5 * (box.y0 + box.y1))


def label_middle(plot, column="y"):
    plot.canvas.draw()
    box = plot.bar_label_artist(column).get_window_extent(plot._renderer())
    return (0.5 * (box.x0 + box.x1), 0.5 * (box.y0 + box.y1))


def pixel(plot, point):
    return tuple(plot.ax.transAxes.transform(point))


xs, ys = np.linspace(0.3, 9.7, 12), np.linspace(101.5, 148.2, 7)
gx, gy = np.meshgrid(xs, ys, indexing="ij")
grid = pd.DataFrame({"x": gx.ravel(), "y": gy.ravel(),
                     "z": np.sin(gx.ravel()) * (gy.ravel() - 100.0)})

# -- 1. every style: selected by a click, dragged, resized ---------------------
for style in tuple(aplot.SURFACE_STYLES) + ("hist2d",):
    app.table.set_dataframe(grid, check_all=True)
    settle(2)
    plot = app.open_plot(style)
    settle(6)
    if style == "hist2d":                  # its bar is off to begin with
        plot.hist2d_cfg.setdefault("y", plot.default_hist2d_cfg())["colorbar"] = True
        plot.refresh_series_visuals("y")
        plot.draw()
        settle(2)
    assert "y" in plot.hist2d_bars, style
    assert near(plot.color_bar_box("y"), aplot.BAR_BOX), style
    here = bar_middle(plot)
    assert plot.object_at(*here) == ("colorbar", "y"), (style, plot.object_at(*here))
    click(plot, *here)
    assert plot.selection == ("colorbar", "y"), (style, plot.selection)
    assert near(plot.color_bar_box("y"), aplot.BAR_BOX), style   # a click moves nothing
    # a narrow bar: the corners and the two ends, not the long sides
    assert [n for n, _p in plot.color_bar_handles("y")] == [0, 1, 2, 3, 4, 6], style
    assert len(plot.selected_handle_positions()) == 6, style
    # dragged 60 pixels to the left and 25 up
    drag(plot, here, (here[0] - 60, here[1] + 25))
    dx, dy = plot._axes_delta(-60, 25)
    box = plot.color_bar_box("y")
    assert near(box, (aplot.BAR_BOX[0] + dx, aplot.BAR_BOX[1] + dy,
                      aplot.BAR_BOX[2], aplot.BAR_BOX[3])), (style, box)
    there = bar_middle(plot)
    assert near(there, (here[0] - 60, here[1] + 25), 1.0), (style, here, there)
    assert plot.selection == ("colorbar", "y"), style
    # the bottom right corner pulled to the right: made wider
    handle = pixel(plot, dict(plot.color_bar_handles("y"))[1])
    drag(plot, handle, (handle[0] + 30, handle[1]))
    wider = plot.color_bar_box("y")
    assert near(wider[:2], box[:2], 1e-3) and near(wider[3:], box[3:], 1e-3), (style, wider)
    assert math.isclose(wider[2], box[2] + plot._axes_delta(30, 0)[0],
                        abs_tol=1e-6), (style, wider, box)
    assert plot.hist2d_bars["y"].orientation == "vertical", style
    # the top right corner pulled far down and right: it lies down
    handle = pixel(plot, dict(plot.color_bar_handles("y"))[2])
    low = pixel(plot, (wider[0] + 0.6, wider[1] + 0.06))
    drag(plot, handle, low)
    flat = plot.color_bar_box("y")
    assert near(flat, (wider[0], wider[1], 0.6, 0.06), 5e-3), (style, flat)
    assert plot.hist2d_bars["y"].orientation == "horizontal", style
    assert plot.selection == ("colorbar", "y"), style
    # the arrow keys carry it
    plot.nudge_selection(aplot.NUDGE_STEP, 0)
    settle(2)
    moved = plot.color_bar_box("y")
    assert moved[0] > flat[0] and near(moved[1:], flat[1:]), (style, moved, flat)
    # drawn again: it is where it was put
    plot.refresh_series_visuals("y")
    plot.draw()
    settle(2)
    assert near(plot.color_bar_box("y"), moved), style
    assert plot.hist2d_bars["y"].orientation == "horizontal", style
    assert plot.selection == ("colorbar", "y"), style
    # the exported program draws it there too
    script = plot.to_script()
    where = ", ".join(f"{float(one):.6g}" for one in moved)
    assert f"inset_axes([{where}])" in script, (style, where)
    assert "orientation='horizontal'" in script, style
    compile(script, "exported", "exec")
    close_all()
    print(f"{style}: the colour bar is selected, dragged, resized, laid down ok")

# -- 2. the curve dialog and Undo keep what the pointer did --------------------
app.table.set_dataframe(grid, check_all=True)
settle(2)
plot = app.open_plot("pcolor")
settle(6)
here = bar_middle(plot)
click(plot, *here)
drag(plot, here, (here[0] - 40, here[1]))
placed = plot.color_bar_box("y")
assert not near(placed, aplot.BAR_BOX)
dialog = plot.open_series_dialog(plot.series["y"])
settle(4)
dialog.sf_bar_label_var.set("Field [V/m]")
settle(4)
assert plot.surface_cfg["y"]["bar_label"] == "Field [V/m]"
assert near(plot.color_bar_box("y"), placed), plot.color_bar_box("y")
assert plot.bar_label_artist("y").get_text() == "Field [V/m]"
# Undo takes the drag back, Redo does it again
dialog.close()
settle(2)
app.undo_step()
settle(4)
assert near(plot.color_bar_box("y"), aplot.BAR_BOX), plot.color_bar_box("y")
assert near(bar_middle(plot), here, 1.0)
app.redo_step()
settle(4)
assert near(plot.color_bar_box("y"), placed)
assert near(bar_middle(plot), (here[0] - 40, here[1]), 1.0)
dialog = plot.open_series_dialog(plot.series["y"])
settle(4)
dialog.sf_bar_label_var.set("Field [V/m]")
settle(4)
assert plot.bar_label_artist("y").get_text() == "Field [V/m]"
print("the curve dialog keeps the place of the bar ok")

# -- 3. the label: one click selects, a slow second click writes in place ------
plot.select_object(None, None)
spot = label_middle(plot)
assert plot.object_at(*spot) == ("barlabel", "y"), plot.object_at(*spot)
click(plot, *spot)
assert plot.selection == ("barlabel", "y"), plot.selection
assert plot.is_marked() and not plot.is_editing_inline()
time.sleep(0.45)
click(plot, *spot)
assert plot.is_editing_inline(), "the slow second click opens the editor"
editor = plot._inline["editor"]
assert editor.get("1.0", "end-1c") == "Field [V/m]"
editor.delete("1.0", "end")
editor.insert("1.0", "Potential [V]")
plot.commit_inline_edit()
settle(4)
assert not plot.is_editing_inline()
assert plot.surface_cfg["y"]["bar_label"] == "Potential [V]"
assert plot.bar_label_artist("y").get_text() == "Potential [V]"
assert plot.bar_label_artist("y").get_visible()
assert plot.selection == ("barlabel", "y"), plot.selection
assert dialog.sf_bar_label_var.get() == "Potential [V]", "the open dialog follows"
assert near(plot.color_bar_box("y"), placed)
# Escape keeps the old text
spot = label_middle(plot)
click(plot, *spot)
time.sleep(0.45)
click(plot, *spot)
assert plot.is_editing_inline()
plot._inline["editor"].insert("1.0", "xxx")
plot.cancel_inline_edit()
settle(2)
assert plot.surface_cfg["y"]["bar_label"] == "Potential [V]"
print("the label of the bar is written in place ok")

# -- 4. a double click on the label opens its own window ------------------------
plot.select_object(None, None)
spot = label_middle(plot)
click(plot, *spot)
mouse(plot, "button_press_event", *spot, dblclick=True)
mouse(plot, "button_release_event", *spot)
settle(4)
assert not plot.is_editing_inline()
window = plot._dialogs.get("bar-label-y")
assert isinstance(window, aplot.TextStyleDialog), plot._dialogs.keys()
window.text_var.set("Phi")
window.size_var.set("17")
window.apply()
settle(4)
label = plot.bar_label_artist("y")
assert label.get_text() == "Phi" and round(label.get_fontsize()) == 17
assert plot.surface_cfg["y"]["bar_label_size"] == 17
window.close()
settle(2)
# the dialog of the curve does not take the size away again
dialog.sf_alpha_var.set("0.9")
dialog._apply()
settle(4)
assert plot.surface_cfg["y"]["bar_label_size"] == 17
assert round(plot.bar_label_artist("y").get_fontsize()) == 17
print("a double click on the label opens its window ok")

# -- 5. dragging the label carries the bar; a double click on the bar opens
#       the curve ------------------------------------------------------------
dialog.close()
settle(2)
plot.select_object(None, None)
spot = label_middle(plot)
before = plot.color_bar_box("y")
drag(plot, spot, (spot[0] + 20, spot[1] - 30))
after = plot.color_bar_box("y")
shift = plot._axes_delta(20, -30)
assert near(after, (before[0] + shift[0], before[1] + shift[1],
                    before[2], before[3])), (before, after)
assert not plot.is_editing_inline()
here = bar_middle(plot)
mouse(plot, "button_press_event", *here, dblclick=True)
mouse(plot, "button_release_event", *here)
settle(4)
assert isinstance(plot._dialogs.get(id(plot.series["y"])),
                  aplot.SeriesStyleDialog)
print("the label carries its bar, the bar opens its curve ok")

# -- 6. saved and opened again: the bar is where it was, labelled as it was ----
document = app.plot_document(plot)
text = repr(document)
assert "bar_box" in text and "bar_label_size" in text
# an empty label takes the text away and the selection with it
plot.select_object("barlabel", "y")
plot.set_text_value("barlabel", "y", "")
plot._check_bar_selection("y")
assert plot.bar_label_artist("y") is None and plot.selection is None
# the bar switched off while it is selected: no control points are left
plot.select_object("colorbar", "y")
assert plot.selection == ("colorbar", "y")
plot.surface_cfg["y"]["colorbar"] = False
plot.refresh_series_visuals("y")
assert plot.selection is None and "y" not in plot.hist2d_bars
print("the diagram keeps the bar; a bar that is gone is not selected ok")
close_all()

print("ALL OK")
