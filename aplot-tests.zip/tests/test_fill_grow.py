"""Headless test (1.1.0): the fill handle pulled past the last row or column
makes the sheet larger while the button is held; a double click never does;
a new sheet has 1000 rows; the version is 1.1.0."""
import json, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True


# -- 0. the settings: 1000 rows, and an old settings file is brought up ------
assert aplot.DEFAULTS["table"]["rows"] == 1000
folder = tempfile.mkdtemp()


def config_from(stored):
    path = os.path.join(folder, "settings.json")
    with open(path, "w") as handle:
        json.dump(stored, handle)
    return aplot.Config(path)


assert config_from({"table": {"rows": 40}}).get("table", "rows") == 1000
assert config_from({"table": {"rows": 250}}).get("table", "rows") == 250
assert config_from({"table": {"rows": 40},
                    "about": {"settings_version": 2}}).get("table", "rows") == 40
saved = config_from({"table": {"rows": 40}})
saved.save()
assert json.load(open(saved.path))["about"]["settings_version"] == 2
assert aplot.Config(saved.path).get("table", "rows") == 1000
print("1000 rows by default; an old settings file with 40 gets 1000 once ok")

root = tk.Tk()
root.geometry("1000x560+0+0")
app = aplot.App(root, aplot.Config(os.path.join(folder, "fresh.json")))


def settle(times=3):
    for _ in range(times):
        root.update()
        time.sleep(0.02)
        root.update()


settle(4)
assert len(app.table.df) == 1000, len(app.table.df)
app.add_sheet()
settle(3)
assert len(app.table.df) == 1000 and len(app.tables) == 2
app.notebook.select(0)
settle(2)
print("the first sheet and a new one have 1000 rows ok")


class Spot:
    """A pointer event at a place of the screen."""

    def __init__(self, x_root, y_root):
        self.x_root, self.y_root, self.x, self.y = int(x_root), int(y_root), 0, 0


def hold(seconds):
    """Keep the button held: the automatic steps run meanwhile."""
    end = time.time() + seconds
    while time.time() < end:
        root.update()
        time.sleep(0.01)


table = app.table
tree = table.tree


def fresh(rows=20):
    table.column_widths.clear()
    table.set_dataframe(pd.DataFrame({"X": np.arange(1.0, rows + 1),
                                      "Y1": [""] * rows, "Y2": [""] * rows}),
                        check_all=True)
    settle(3)
    app.forget_undo()


def write(row, column, text):
    table.select_cell(row, column)
    table._begin_edit(str(row), column)
    settle(1)
    table._editor[1].set(text)
    table._commit_edit()
    settle(1)


def handle_spot(dx=3, dy=3):
    table._refresh_outline()
    settle(1)
    handle = table._get_fill_handle()
    return Spot(handle.winfo_rootx() + dx, handle.winfo_rooty() + dy)


def below_table(by):
    return tree.winfo_rooty() + tree.winfo_height() + by


# -- 1. pulled down past the last row: the sheet grows ------------------------
fresh(20)
write(0, 1, "=A1*2")
before_undo = len(app.undo.done)
table.select_cell(0, 1)
start = handle_spot()
table._on_fill_press(start)
x = start.x_root
table._on_fill_drag(Spot(x, start.y_root + 30))           # into the rows below
table._on_fill_drag(Spot(x, below_table(20)))             # past the bottom
hold(1.5)
grown = len(table.df)
assert grown > 20, f"the sheet grew while the button was held: {grown}"
hint = table.status_label.cget("text")
assert "formula is carried on" in hint and "the sheet grows by" in hint, hint
assert table._fill_direction == "down"
hold(0.6)
assert len(table.df) > grown, "...and goes on growing"
table._on_fill_release(Spot(x, below_table(20)))
settle(3)
last = len(table.df) - 1
assert last >= 21
for row in (1, 19, 20, last):
    assert table.cell_formulas.get((row, 1)) == f"=A{row + 1}*2", \
        (row, table.cell_formulas.get((row, 1)))
assert float(table.df.iat[19, 1]) == 40.0
assert table._row_is_empty(last) is False, "no unused rows were left at the end"
assert table.block_bounds() == (0, 1, last, 1), table.block_bounds()
assert tree.exists(str(last)) and table.row_tree.exists(str(last))
assert len(app.undo.done) == before_undo + 1, "the fill and its rows: one step"
print(f"pulled past row 20, the sheet grew to {len(table.df)} rows, all filled ok")
app.undo_step()
settle(3)
table = app.table
tree = table.tree
assert len(table.df) == 20, len(table.df)
assert set(table.cell_formulas) == {(0, 1)}, table.cell_formulas
print("Undo takes the fill and the new rows back in one step ok")

# -- 2. brought back before letting go: nothing extra stays --------------------
table.select_cell(0, 1)
start = handle_spot()
table._on_fill_press(start)
x = start.x_root
table._on_fill_drag(Spot(x, below_table(40)))
hold(1.0)
assert len(table.df) > 20
# the pointer comes back inside the table: the scrolling stops at once...
table._on_fill_drag(Spot(x, tree.winfo_rooty() + tree.winfo_height() // 2))
assert table._fill_auto_scroll_timer is None
table._yview("moveto", 0.0)                  # ...and goes up to row 6
settle(2)
middle = tree.bbox("5", "#2")
assert middle, "row 6 is on the screen again"
back = Spot(x, tree.winfo_rooty() + middle[1] + middle[3] // 2)
table._on_fill_drag(back)
settle(1)
table._on_fill_release(back)
settle(3)
assert table._fill_dragging is False
assert len(table.df) == 20, len(table.df)
assert table.cell_formulas.get((5, 1)) == "=A6*2"
assert (6, 1) not in table.cell_formulas
print("rows added but not reached are taken away again ok")

# -- 3. pulled to the right past the last column ------------------------------
fresh(10)
write(0, 1, "=A1*2")
columns = list(table.df.columns)
table.select_cell(0, 1)
start = handle_spot()
table._on_fill_press(start)
right_edge = tree.winfo_rootx() + tree.winfo_width()
table._on_fill_drag(Spot(right_edge + 30, start.y_root))
hold(1.2)
assert len(table.df.columns) > len(columns), list(table.df.columns)
assert table._fill_direction == "right"
table._on_fill_release(Spot(right_edge + 30, start.y_root))
settle(3)
names = list(table.df.columns)
assert names[:3] == columns and len(names) >= 4, names
assert names[3].startswith("Y"), names
for column in range(2, len(names)):
    assert table.cell_formulas.get((0, column)), (column, table.cell_formulas)
assert table.cell_formulas[(0, 2)] == "=B1*2"
assert table._column_is_empty(len(names) - 1) is False
assert set(table._checks) == set(names), "every new column has its check buttons"
assert table.column_axis(names[-1]) == "L"
print(f"pulled past the last column, the sheet grew to {len(names)} columns ok")
app.undo_step()
settle(3)
table = app.table
tree = table.tree
assert list(table.df.columns) == columns, list(table.df.columns)

# -- 4. a double click never grows the sheet ---------------------------------
table.set_dataframe(pd.DataFrame({"X": [""] * 1000, "Y1": [""] * 1000}),
                    check_all=True)
settle(3)
for row in range(40):
    table._set_cell_value(row, 0, float(row + 1))
write(0, 1, "=A1+1")
table.select_cell(0, 1)
table._on_fill_double_click()
settle(3)
assert len(table.df) == 1000
filled = sorted(row for (row, col) in table.cell_formulas if col == 1)
assert filled == list(range(40)), filled[-3:]
table.cell_formulas = {(0, 1): "=A1+1"}
for row in range(1000):
    table._set_cell_value(row, 0, "")
table.recalculate_all()
table.select_cell(0, 1)
table._on_fill_double_click()
settle(3)
assert len(table.df) == 1000
assert max(row for (row, col) in table.cell_formulas if col == 1) == 999
print("a double click fills to the neighbour (row 40) or the last row, never more ok")

# -- 5. the speed grows with the distance past the edge -------------------------
assert table._fill_speed(0, aplot.FILL_MOST_ROWS) == 1
assert table._fill_speed(aplot.FILL_SPEED_PIXELS, aplot.FILL_MOST_ROWS) == 2
assert table._fill_speed(10000, aplot.FILL_MOST_ROWS) == aplot.FILL_MOST_ROWS
started = time.perf_counter()
table.grow_rows(500)
settle(1)
took = time.perf_counter() - started
assert len(table.df) == 1500 and took < 2.0, took
assert table.shrink_to(rows=1000) is True and len(table.df) == 1000
print(f"500 rows added in {took * 1000:.0f} ms ok")

# -- 6. the version -----------------------------------------------------------
assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.1.0"), aplot.APP_VERSION
assert "| 1.1.0 | 2026-10-03 |" in aplot.DOCUMENTATION
print("version 1.1.0 or later ok")

root.destroy()
print("ALL OK")
