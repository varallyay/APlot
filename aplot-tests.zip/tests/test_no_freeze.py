"""Headless test (1.6.9): two ways the program froze, and froze no more.

* **Two diagram windows and the keyboard.**  Every diagram takes the
  keyboard when it is activated.  Taking it activates the window on a Mac,
  so when the activations of two diagrams crossed (a click in the second
  one while the first was still taking it) each took it from the other for
  ever.  Here the two are activated crosswise on purpose: the windows settle
  within a moment and the program answers.
* **Paste with the program's own text on the clipboard.**  A paste looks
  for a picture on the clipboard.  Pillow asks `osascript` (or `xclip`) for
  it, and the clipboard - holding cells this program copied - asks the
  program, which is waiting for osascript: neither ever answered.  Now a
  paste in a diagram is over at once.

A watchdog stops the test (and shows where it hung) after 60 seconds.
"""
import faulthandler
import os, sys, tempfile, time

faulthandler.dump_traceback_later(60, exit=True)
HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from keys_help import Keys

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))
keys = Keys(root)
x = np.linspace(0.0, 10.0, 12)
app.table.set_dataframe(pd.DataFrame({"x": x, "y": np.sin(x)}), check_all=True)
keys.settle(4)
runs = {}
take = aplot.PlotWindow.take_focus


def counted(window, *args):
    """How often each window takes the keyboard."""
    runs[str(window)] = runs.get(str(window), 0) + 1
    return take(window, *args)


aplot.PlotWindow.take_focus = counted      # before the windows bind it
first = app.open_plot("line_symbol")
keys.settle(12)
second = app.open_plot("line_symbol")
keys.settle(12)


def pump(seconds):
    end = time.time() + seconds
    while time.time() < end:
        root.update()
        time.sleep(0.01)


# -- 1. the activations of two diagrams cross -----------------------------------
for one, other in ((first, second), (second, first)):
    one.canvas.get_tk_widget().focus_force()       # this one comes in front
    other.canvas.get_tk_widget().focus_set()       # the keyboard goes there
    pump(1.0)
    before = dict(runs)
    pump(1.5)
    assert runs == before, f"the windows still take the keyboard: {before} -> {runs}"
first.canvas.get_tk_widget().focus_force()
second.canvas.get_tk_widget().focus_force()
pump(1.0)
before = dict(runs)
pump(1.5)
assert runs == before, f"the windows still take the keyboard: {before} -> {runs}"
print("two diagrams activated crosswise: they settle, the program answers ok")

# -- 2. paste with the program's own text on the clipboard ------------------------
app.table.clipboard_clear()
app.table.clipboard_append("1\t2\n3\t4")           # as copying cells does
keys.settle(3)
started = time.time()
first.paste_clipboard()
took = time.time() - started
assert took < 5.0, f"the paste took {took:.1f} s"
assert aplot.clipboard_picture(first.canvas.get_tk_widget()) is None
if sys.platform == "darwin":
    assert aplot.MAC_PASTEBOARD.available(), "the clipboard is read inside the program"
    assert aplot.clipboard_serial(root).startswith("count:"), aplot.clipboard_serial(root)
print(f"paste with the program's own text on the clipboard: {took:.2f} s ok")

assert not errors, errors
keys.close()
root.destroy()
print("ALL OK")
