"""Headless test (1.3.7): an empty row stays a gap in the curve when sheets
are drawn together ("Plot with previous tab"), the X values are sorted as
numbers, and the settings button is a narrow gear icon."""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)

root = tk.Tk()
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=6, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


settle()

# -- 1. the hole-keeping of the X values ---------------------------------------
keys = pd.Series([1.0, 2.0, np.nan, 4.0, np.nan, np.nan, 7.0, np.nan])
placed = aplot.App.hold_hole_places(keys).tolist()
assert placed[:2] == [1.0, 2.0] and 2.0 < placed[2] < 4.0, placed
assert 4.0 < placed[4] < placed[5] < 7.0, "two empty rows in a row: two places"
assert np.isnan(placed[7]), "an empty row at the end stays as it is"
assert aplot.App.all_numbers(pd.Series([1.5, "", 2.5, None])) is True
assert aplot.App.all_numbers(pd.Series([1.5, "red", 2.5])) is False
print("an empty row gets a place between its neighbours; empty cells are no text ok")

# -- 2. a sheet with an empty row, drawn together with the next sheet ----------
x = [1.5603, 1.5611, 1.5619, 1.5627, 1.5635, 1.5643, "", 1.57, 1.5708, 1.5716]
y = [10.02, 10.021, 10.021, 10.021, 10.019, 10.016, "", 9.99, 9.997, 10.005]
first = app.table
first.set_dataframe(pd.DataFrame({"X": x, "Y1": y}), check_all=True)
settle(2)
app.add_sheet()
settle(2)
fit_x = np.linspace(1.555, 1.58, 30)
app.table.set_dataframe(pd.DataFrame({"X": fit_x, "fit": 10.0 + 0 * fit_x}),
                        check_all=True)
app.table.plot_with_previous_var.set(True)
settle(2)
app.notebook.select(0)
settle(2)
assert len(app.tab_chain(0)) == 2, "the two sheets are drawn together"
plot = app.open_plot("line_symbol")
settle(8)
line_x, line_y = (np.asarray(one, float) for one in plot.series["Y1"].get_data())
holes = np.where(~np.isfinite(line_y))[0]
assert len(holes) == 1, (line_x, line_y)
hole = int(holes[0])
assert abs(line_x[hole - 1] - 1.5643) < 1e-9 and abs(line_x[hole + 1] - 1.57) < 1e-9, \
    (line_x[hole - 1:hole + 2], line_y[hole - 1:hole + 2])
assert np.all(np.diff(line_x[np.isfinite(line_x)]) > 0), "in the order of X"
fit = np.asarray(plot.series["fit"].get_data()[1], float)
assert np.isfinite(fit).all() and len(fit) == 30, "the other sheet is untouched"
print("the empty row breaks the curve between 1.5643 and 1.57, sheets drawn together ok")
for window in app.open_windows():
    window.destroy()
settle(2)

# -- 3. X values of 9 and 10: sorted as numbers, even with an empty cell --------
first.set_dataframe(pd.DataFrame({"X": [8, 9, "", 10, 11], "Y1": [1, 2, "", 3, 4]}),
                    check_all=True)
app.tables[1].set_dataframe(pd.DataFrame({"X": [8.5, 10.5], "fit": [1.5, 3.5]}),
                            check_all=True)
settle(2)
merged = app.plot_data(index=0)
column_x = [one for one in merged.columns][0]
numbers = pd.to_numeric(merged[column_x], errors="coerce").tolist()
assert numbers == sorted(numbers), numbers
assert 9 < numbers[3] < 10, "the empty row stays between 9 and 10"
print(f"X sorted as numbers, the hole in place: {numbers} ok")

# -- 4. the settings: a narrow gear ------------------------------------------------
button = app.settings_btn
assert str(button.cget("text")) == "" and str(button.cget("image")), "a picture, no words"
assert button.winfo_width() <= app.open_graph_btn.winfo_width() + 2, \
    (button.winfo_width(), app.open_graph_btn.winfo_width())
assert abs(button.winfo_height() - app.open_graph_btn.winfo_height()) <= 1
assert aplot.FILE_ICON_PAINTERS["settings"] is aplot._paint_settings
picture = aplot.file_tool_icon("settings")
assert picture is not None and picture.width() == aplot.ICON_SIZE
source = picture.source.convert("RGBA")
middle = source.getpixel((aplot.ICON_SIZE // 2, aplot.ICON_SIZE // 2))
edge = source.getpixel((1, 1))
assert middle[3] > 200 and edge[3] < 60, (middle, edge)   # the hole, the free corner
opened = []
real = app.open_settings
app.open_settings = lambda *a: opened.append(1)
button.configure(command=app.open_settings)
button.invoke()
assert opened == [1]
app.open_settings = real
print(f"the settings button is a gear, {button.winfo_width()} pixels wide ok")

assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.3.7")
assert "| 1.3.7 | 2026-10-22 |" in aplot.DOCUMENTATION
root.destroy()
print("ALL OK")
