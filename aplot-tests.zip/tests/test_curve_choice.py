"""Headless test (1.7.0): the curve window chooses its curve.

At the top of `Curve properties` a list holds every curve of the diagram
(its legend text, with the column where that differs); choosing one shows
that curve in the window - its own window opens in the very place of the
one before, which closes.  The list follows curves renamed meanwhile, and
the title of the window names the curve it shows.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


x = np.linspace(0.0, 10.0, 15)
app.table.set_dataframe(pd.DataFrame({"x": x, "y1": np.sin(x), "y2": np.cos(x),
                                      "y3": 0.1 * x}), check_all=True)
settle(2)
plot = app.open_plot("line_symbol")
settle(10)
plot.series["y2"].set_label("Cosine")
plot.refresh_legend()
plot.draw()
settle(2)

dialog = plot.open_series_dialog(plot.series["y1"])
settle(20)
values = list(dialog.curve_combo.cget("values"))
assert values == ["y1", "Cosine  (y2)", "y3"], values
assert dialog.curve_var.get() == "y1"
assert "y1" in dialog.title(), dialog.title()
spot = (dialog.winfo_rootx(), dialog.winfo_rooty())

# another curve: its window takes the place of this one
dialog.curve_var.set("Cosine  (y2)")
dialog._curve_chosen()
settle(20)
assert not dialog.winfo_exists(), "the window of the first curve is closed"
second = plot._dialogs.get(id(plot.series["y2"]))
assert second is not None and second.winfo_exists()
assert second.column == "y2" and second.line is plot.series["y2"]
assert second.curve_var.get() == "Cosine  (y2)"
assert "Cosine" in second.title()
now = (second.winfo_rootx(), second.winfo_rooty())
assert abs(now[0] - spot[0]) <= 2 and abs(now[1] - spot[1]) <= 2, (now, spot)
assert id(plot.series["y1"]) not in plot._dialogs
# what is set there belongs to the curve shown
second.lwidth_var.set("4")
second._apply()
settle(2)
assert plot.series["y2"].get_linewidth() == 4.0
assert plot.series["y1"].get_linewidth() != 4.0

# a curve renamed while the window is open: the list follows it
plot.series["y3"].set_label("Ramp")
second._fill_curve_list()
assert "Ramp  (y3)" in list(second.curve_combo.cget("values"))
second.curve_var.set("Ramp  (y3)")
second._curve_chosen()
settle(20)
third = plot._dialogs.get(id(plot.series["y3"]))
assert third is not None and third.column == "y3" and not second.winfo_exists()
# the same curve again changes nothing
third._curve_chosen()
settle(2)
assert third.winfo_exists()
third.close()
settle(2)
print("the curve window chooses its curve, in its own place ok")
assert not errors, errors
print("ALL OK")
