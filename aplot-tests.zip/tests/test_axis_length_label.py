"""Headless test (1.7.0): the length of an axis while its end is pulled.

While an end of an axis is dragged, a label beside that end tells the
length of the axis in the units of the Frame page of the axes window - cm,
inch and per cent of the page - and the message line says it in full, so
the same size can be typed into another diagram.  The label is gone when
the button is let go (it is never part of the picture), the message stays
a moment.  An axis in space tells the lengths of the three axes compared
with one another, as the curve window writes them.
"""
import math, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from matplotlib.backend_bases import MouseEvent

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def mouse(plot, name, x, y):
    event = MouseEvent(name, plot.canvas, x, y, button=1)
    {"button_press_event": plot._on_button_press,
     "motion_notify_event": plot._on_motion,
     "button_release_event": plot._on_release}[name](event)


def message(plot):
    try:
        return str(plot.toolbar.message.get())
    except AttributeError:
        return str(getattr(plot.toolbar, "_message_label", {}).get("text", ""))


x = np.linspace(0.0, 10.0, 15)
app.table.set_dataframe(pd.DataFrame({"x": x, "y": np.sin(x)}), check_all=True)
settle(2)
plot = app.open_plot("line_symbol")
settle(10)
plot.canvas.draw()
box = plot.ax.get_window_extent()

# -- 1. the X axis: its right end pulled to the right --------------------------
plot.select_object("axis", "bottom")
plot.draw()
settle(2)
plot.canvas.draw()
start = tuple(plot.ax.transAxes.transform(plot.selected_handle_positions()[1]))
mouse(plot, "button_press_event", *start)
for step in range(1, 5):
    mouse(plot, "motion_notify_event", start[0] + 10 * step, start[1])
label = plot._length_label
assert label is not None and label.get_visible() and label in plot.fig.texts
part = plot.frame_cfg["x_length"]
cm = part * plot.page_size[0]
text = label.get_text()
assert f"{cm:.2f} cm" in text and f"{cm / 2.54:.2f} in" in text \
    and f"{part * 100:.1f} %" in text, (text, cm, part)
# beside the end that moves: to the right of it, at the height of the axis
plot.canvas.draw()
spot = label.get_window_extent()
end = plot.ax.get_window_extent()
assert spot.x0 > end.x1 and spot.y0 < end.y0 < spot.y1, (spot, end)
assert "Width of the plot area" in plot._length_note
assert f"{part:.4g} of the page" in plot._length_note
mouse(plot, "button_release_event", start[0] + 40, start[1])
settle(2)
assert plot._length_label is None and label not in plot.fig.texts
print("the X axis: its length beside the pulled end, gone after ok")

# -- 2. the Y axis: its top end, the label above it ----------------------------
plot.canvas.draw()
box = plot.ax.get_window_extent()
plot.select_object("axis", "left")
plot.draw()
settle(2)
plot.canvas.draw()
start = tuple(plot.ax.transAxes.transform(plot.selected_handle_positions()[1]))
mouse(plot, "button_press_event", *start)
mouse(plot, "motion_notify_event", start[0], start[1] - 20)
assert plot._shape_drag and plot._shape_drag["mode"] == "axis-end", plot._shape_drag
label = plot._length_label
part = plot.frame_cfg["y_length"]
cm = part * plot.page_size[1]
assert label is not None and f"{cm:.2f} cm" in label.get_text(), label
plot.canvas.draw()
spot, end = label.get_window_extent(), plot.ax.get_window_extent()
assert spot.y0 > end.y1, (spot, end)
assert "Height of the plot area" in plot._length_note
mouse(plot, "button_release_event", start[0], start[1] - 20)
settle(2)
assert plot._length_label is None
# a picture of the diagram has no label in it
assert not any("cm" in one.get_text() for one in plot.fig.texts)
print("the Y axis: its length above the pulled end ok")

# -- 3. an axis in space: the three lengths compared ---------------------------
for window in app.open_windows():
    window.destroy()
settle(2)
xs, ys = np.linspace(-3.0, 3.0, 13), np.linspace(-2.0, 2.0, 9)
gx, gy = np.meshgrid(xs, ys, indexing="ij")
app.table.set_dataframe(pd.DataFrame({"x": gx.ravel(), "y": gy.ravel(),
                                      "z": np.exp(-(gx.ravel() ** 2))}),
                        check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)
plot.canvas.draw()
ends = plot.axis3d_ends("x")
middle = (0.5 * (ends[0][0] + ends[1][0]), 0.5 * (ends[0][1] + ends[1][1]))
mouse(plot, "button_press_event", *middle)
mouse(plot, "button_release_event", *middle)
settle(2)
assert plot.selection == ("axis3d", "x"), plot.selection
plot.canvas.draw()
handle = tuple(plot.ax.transAxes.transform(plot.selected_handle_positions()[1]))
away = (ends[1][0] + 0.5 * (ends[1][0] - ends[0][0]),
        ends[1][1] + 0.5 * (ends[1][1] - ends[0][1]))
time.sleep(aplot.RENAME_DELAY / 1000.0 + 0.1)
mouse(plot, "button_press_event", *handle)
for step in range(1, 4):
    mouse(plot, "motion_notify_event", handle[0] + (away[0] - handle[0]) * step / 3,
          handle[1] + (away[1] - handle[1]) * step / 3)
label = plot._length_label
assert label is not None and label.get_text().startswith("X : Y : Z = "), label
box3 = plot.view3d_box()
assert aplot.field_number(round(box3[0], 2)) in label.get_text(), (label.get_text(), box3)
mouse(plot, "button_release_event", *away)
settle(2)
assert plot._length_label is None
print("an axis in space: the three lengths compared ok")

assert not errors, errors
print("ALL OK")
