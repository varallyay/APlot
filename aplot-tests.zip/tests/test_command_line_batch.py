"""Headless test (1.8.0): pictures from the command line, no window.

  aplot.py --export GRAPH.aplt ...            the pictures of saved graphs
  aplot.py --template STYLE.aplt DATA ...     new numbers, a saved look

Each call is run as a program, the way a shell script or a simulation
pipeline calls it: what it writes, what it prints (one line per file
written), what it says on stderr and its exit code (0 done, 1 a file
failed - the others are still done -, 2 the command line is wrong)."""
import os, sys, subprocess, tempfile

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
PROGRAM = os.path.join(HERE, "..", "aplot.py")
sys.path.insert(0, os.path.join(HERE, ".."))

import numpy as np
import pandas as pd
import matplotlib
import aplot

WORK = tempfile.mkdtemp()
os.chdir(WORK)


def run(*args):
    done = subprocess.run([sys.executable, PROGRAM, *args], capture_output=True,
                          text=True, env=dict(os.environ, HOME=HOME), timeout=300)
    lines = [one for one in done.stdout.splitlines() if one.strip()]
    return done.returncode, lines, done.stderr


def picture_size(path):
    return matplotlib.image.imread(path).shape[:2]


# a saved look: spectra, black dashed sum, legend outside on the right
lam = np.linspace(1260.0, 1360.0, 101)


def spectra(scale):
    return pd.DataFrame({"Wavelength (nm)": lam,
                         "TE0": scale * (0.27 + 0.34 * (lam - 1260) / 100),
                         "TM1": scale * (0.17 + 0.09 * np.sin((lam - 1260) / 9)),
                         "sum": np.full_like(lam, 0.9)})


style = aplot.Graph(spectra(1.0), style="line")
(style.diagram().title("").axis("y", label="Power fraction", range=(0, 1))
 .curve("sum", color="#000000", linestyle="--").legend(position="outside right"))
style.save("style.aplt")
style.add_diagram("scatter")
style.save("two.aplt")
aplot.close()
for name, scale in (("run_a", 1.0), ("run_b", 0.5)):
    spectra(scale).to_csv(f"{name}.csv", index=False)
spectra(1.0).drop(columns=["TM1"]).to_csv("short.csv", sep=";", index=False)

# -- --export ------------------------------------------------------------------------
code, lines, err = run("--export", "style.aplt")
assert code == 0 and lines == ["style.pdf"], (code, lines, err)
assert open("style.pdf", "rb").read(4) == b"%PDF"
code, lines, err = run("--export", "two.aplt", "style.aplt", "--out", "pictures",
                       "--format", "png", "--dpi", "50")
assert code == 0, err
assert lines == [os.path.join("pictures", "two_1.png"), os.path.join("pictures", "two_2.png"),
                 os.path.join("pictures", "style.png")], lines
small = picture_size(os.path.join("pictures", "style.png"))
code, lines, err = run("--export", "style.aplt", "--out", "big.png", "--dpi", "100")
assert code == 0 and lines == ["big.png"], (lines, err)
big = picture_size("big.png")
assert abs(big[0] / small[0] - 2.0) < 0.05, (big, small)       # --dpi counts
print("--export: next to the graph, into a folder, into a file, at a dpi ok")

# -- --template -----------------------------------------------------------------------
code, lines, err = run("--template", "style.aplt", "run_a.csv", "run_b.csv",
                       "--out", "runs", "--save-graph")
assert code == 0, err
assert lines == [os.path.join("runs", n) for n in
                 ("run_a.pdf", "run_a.aplt", "run_b.pdf", "run_b.aplt")], lines
made = aplot.Graph.open(os.path.join("runs", "run_b.aplt"))
assert np.allclose(made.data["TE0"], spectra(0.5)["TE0"]), "the new numbers"
curves = {c["column"]: c for c in made.document["plots"][0]["series"]}
assert curves["sum"]["color"] == "#000000" and curves["sum"]["linestyle"] == "--"
assert curves["TE0"]["legend_pos"][0] > 1.0, "the legend stays outside"
assert made.document["plots"][0]["axes"]["y"]["label"] == "Power fraction"
print("--template: one picture and one graph per data file, the look kept ok")

# a separator of its own (;) is recognised, as by Import data; missing curves
code, lines, err = run("--template", "style.aplt", "short.csv", "--out", "short.png")
assert code == 1 and lines == [], (code, lines)
assert "short.csv" in err and "'TM1'" in err and "the columns are" in err, err
code, lines, err = run("--template", "style.aplt", "short.csv", "--out", "short.png",
                       "--allow-missing")
assert code == 0 and lines == ["short.png"], (code, lines, err)
print("a missing column fails with a message, --allow-missing leaves it out ok")

# -- failures: one bad file does not stop the others; usage errors ----------------
code, lines, err = run("--template", "style.aplt", "run_a.csv", "nothere.csv",
                       "run_b.csv", "--out", "partly")
assert code == 1, code
assert lines == [os.path.join("partly", "run_a.pdf"), os.path.join("partly", "run_b.pdf")], lines
assert "nothere.csv" in err, err
code, lines, err = run("--export", "nothere.aplt")
assert code == 1 and "nothere.aplt" in err, (code, err)
for args, said in ((("--export",), "required"),
                   (("--export", "style.aplt", "--format", "bmpx"), "unknown picture format"),
                   (("--export", "style.aplt", "two.aplt", "--out", "one.pdf"), "must be a folder"),
                   (("--export", "style.aplt", "--out", "x.png", "--format", "pdf"), "disagree"),
                   (("--template", "style.aplt"), "required")):
    code, lines, err = run(*args)
    assert code == 2 and said in err and lines == [], (args, code, err)
print("a failing file is reported and the rest is done; usage errors exit 2 ok")

assert not os.path.exists(os.path.join(HOME, ".aplot")), "no settings were written"
print("ALL OK")
