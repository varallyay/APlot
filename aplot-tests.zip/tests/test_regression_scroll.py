"""Headless test (1.3.8): the regression window keeps its size.

A polynomial of a high order has many parameters.  Their list used to grow
with every one of them, and from about ten parameters the window was taller
than the screen: the Fit and Close buttons were gone below its edge.  Now:

* the list grows up to seven parameters and then stays that tall, with a
  scroll bar at its edge (the wheel and Tab reach every row);
* the answer under it scrolls the same way after a long fit;
* on a small screen both give up rows until the whole window fits;
* values typed in stay when only the order changes, and a value typed into
  a row out of sight is used by the fit.
"""
import os, sys, tempfile

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from keys_help import Keys

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
root.geometry("700x480+10+40")
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))
keys = Keys(root)
x = np.linspace(-2.0, 2.0, 40)
app.table.set_dataframe(pd.DataFrame({"x": x, "y1": 1 + x - x ** 3,
                                      "y2": np.cos(x), "y3": np.sin(2 * x)}),
                        check_all=True)
keys.settle(4)

dialog = app.open_regression()
keys.settle(12)
dialog.plot_var.set(False)          # no diagram: only the window is looked at
poly = [model.code for model in aplot.FIT_MODELS].index("poly")
dialog.method_list.selection_clear(0, "end")
dialog.method_list.selection_set(poly)
dialog._method_chosen()
keys.settle(6)
area = dialog.params_area
_left, top, _right, bottom = aplot.usable_screen(dialog)
room = bottom - top - aplot.TITLE_BAR


def order(value):
    dialog.setting_vars["order"].set(str(value))
    keys.settle(8)
    dialog.update_idletasks()
    return dialog.winfo_reqheight()


def on_screen():
    """The whole window, buttons included, on the usable screen."""
    dialog.update_idletasks()
    keys.settle(6)
    assert dialog.winfo_reqheight() <= room, (dialog.winfo_reqheight(), room)
    for button in (dialog.fit_button,):
        bottom_edge = button.winfo_rooty() + button.winfo_height()
        assert button.winfo_ismapped() and bottom_edge <= bottom, \
            ("the Fit button is off the screen", bottom_edge, bottom)


# -- 1. it grows up to seven parameters, then it stays --------------------------
heights = {n: order(n) for n in range(1, aplot.MAX_POLY_ORDER + 1)}
print("heights by order:", heights, "room", room)
seven = aplot.FIT_ROWS_SHOWN - 1            # order 6: seven parameters
tallest = max(heights.values())
assert tallest <= room, ("never taller than the screen", heights, room)
# it grows with every parameter until seven (or until the screen is full)...
full = min(n for n in heights if heights[n] >= tallest - 2)
grows = [heights[n] for n in range(1, full + 1)]
assert grows == sorted(grows) and len(set(grows)) == len(grows), heights
assert full <= seven, ("it stops growing at seven parameters", heights)
if full < seven:
    assert tallest >= room - 40, ("it stopped early only for the screen", heights)
# ...and then it stays as it is, however many more there are
for n in range(full, aplot.MAX_POLY_ORDER + 1):
    assert abs(heights[n] - tallest) <= 2, (n, heights)
tall_enough = full == seven
assert len(dialog.start_vars) == aplot.MAX_POLY_ORDER + 1
assert area.scrolls(), "eleven parameters: the list scrolls"
assert area.bar.winfo_ismapped(), "with a scroll bar at its edge"
order(seven)
assert not area.scrolls() or not tall_enough, "seven fit without one"
if tall_enough:
    assert not area.bar.winfo_ismapped()
on_screen()
print("the list of parameters grows up to seven, then it scrolls ok")

# -- 2. every row is reached: the wheel and Tab -----------------------------------
order(aplot.MAX_POLY_ORDER)
on_screen()
canvas = area.canvas
assert canvas.yview()[0] == 0.0
last = dialog.param_entries[-1]
for _ in range(20):                         # the wheel, over the rows
    if keys.real:
        keys.click(canvas, button=5, wait=1)
    else:
        middle = canvas.winfo_containing(canvas.winfo_rootx() + canvas.winfo_width() // 2,
                                         canvas.winfo_rooty() + canvas.winfo_height() // 2)
        if root._windowingsystem == "x11":
            middle.event_generate("<Button-5>")
        else:
            middle.event_generate("<MouseWheel>", delta=-120)
        keys.settle(1)
keys.settle(4)
assert canvas.yview()[1] >= 0.999, ("the wheel scrolls to the end", canvas.yview())
canvas.yview_moveto(0.0)
keys.settle(2)
dialog.param_entries[0].focus_force()
keys.settle(4)
for _ in range(2 * aplot.MAX_POLY_ORDER):
    widget = dialog.focus_get()
    if widget is last:
        break
    widget.event_generate("<Tab>") if not keys.real else keys.press("Tab")
    keys.settle(2)
assert dialog.focus_get() is last, dialog.focus_get()
keys.settle(4)
top_edge = last.winfo_rooty()
assert canvas.winfo_rooty() <= top_edge and \
    top_edge + last.winfo_height() <= canvas.winfo_rooty() + canvas.winfo_height() + 1, \
    "Tab scrolled the last row into view"
print("the wheel and Tab reach every row ok")

# -- 3. typed values stay with the order; a hidden row is used by the fit -------
for entry in dialog.param_entries:
    entry.delete(0, "end")
dialog.start_vars[0].set("1")
dialog.start_vars[-1].set("0")              # c10, out of sight at first
dialog.hold_vars[-1].set(True)
order(aplot.MAX_POLY_ORDER - 1)
assert dialog.start_vars[0].get() == "1", "c0 kept"
order(aplot.MAX_POLY_ORDER)
assert dialog.start_vars[0].get() == "1" and dialog.start_vars[-1].get() == "", \
    "c10 came back empty (it was gone in between)"
dialog.start_vars[-1].set("0")
dialog.hold_vars[-1].set(True)
start, hold = dialog.starting_values()
assert start[-1] == 0.0 and hold[-1] is True, (start, hold)
results = dialog.run_fit()
keys.settle(10)
assert results, "the fit ran"
fit = results[0]
assert abs(fit["params"][-1]) < 1e-12, ("c10 was held at 0", fit["params"])
print("typed values stay, a row out of sight counts in the fit ok")

# -- 4. a long answer scrolls as well; the window still fits --------------------
answer = dialog.result_area
assert len(results) == 3
assert answer.scrolls(), "three columns of eleven parameters: it scrolls"
assert answer.bar.winfo_ismapped()
on_screen()
line = aplot.tkfont.nametofont("TkDefaultFont").metrics("linespace")
assert int(answer.canvas.cget("height")) <= aplot.FIT_SUMMARY_LINES * line + 2
print("a long answer scrolls, the buttons stay on the screen ok")

# -- 5. a small screen: the lists give up rows, never the buttons ----------------
real_usable = aplot.usable_screen
try:
    aplot.usable_screen = lambda widget: (0, 0, 1280, 720)
    dialog.fit_to_screen()
    keys.settle(6)
    dialog.update_idletasks()
    assert dialog.winfo_reqheight() <= 720 - aplot.TITLE_BAR, dialog.winfo_reqheight()
    shown = int(area.canvas.cget("height"))
    assert shown >= dialog._rows_height(3), "never fewer than three rows"
    assert shown < dialog._rows_height(aplot.FIT_ROWS_SHOWN), "it gave up rows"
    assert int(answer.canvas.cget("height")) >= 2 * line, "two lines at least"
finally:
    aplot.usable_screen = real_usable
dialog.fit_to_screen()
keys.settle(4)
print("on a small screen the lists give up rows, the buttons stay ok")

# -- 6. other methods: a few parameters, no scroll bar ----------------------------
for code in ("line", "decay2", "gauss"):
    index = [model.code for model in aplot.FIT_MODELS].index(code)
    dialog.method_list.selection_clear(0, "end")
    dialog.method_list.selection_set(index)
    dialog._method_chosen()
    keys.settle(6)
    count = len(dialog.start_vars)
    assert area.scrolls() == (count > aplot.FIT_ROWS_SHOWN), (code, count)
    assert all(var.get() == "" for var in dialog.start_vars), "a new method starts afresh"
on_screen()
print("the other methods: as before ok")

# -- 7. the version -----------------------------------------------------------
assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.3.8")
assert "| 1.3.8 | 2026-11-04 |" in aplot.DOCUMENTATION
assert "seven parameters" in aplot.DOCUMENTATION
print(f"version {aplot.APP_VERSION} ok")

assert not errors, errors
dialog.close()
keys.close()
print("ALL OK")
