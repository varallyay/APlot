"""Test (1.6.5): text pasted into the sheet that is wider or longer than the
sheet makes the sheet larger - to the right and downwards - instead of
cutting the pasted block off; Undo takes the paste back in one step."""
import json, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True

folder = tempfile.mkdtemp()
path = os.path.join(folder, "settings.json")
with open(path, "w") as handle:
    json.dump({"table": {"rows": 20, "auto_extend": False},
               "about": {"settings_version": 99}}, handle)

root = tk.Tk()
root.geometry("700x500+0+0")
app = aplot.App(root, aplot.Config(path))


def settle(times=3):
    for _ in range(times):
        root.update()
        time.sleep(0.02)
        root.update()


settle(4)
table = app.table
rows0, cols0 = len(table.df), len(table.df.columns)
print("sheet", rows0, "x", cols0)
# a first change gives the new sheet its starting point for Undo
table.select_cell(0, 0)
assert table.paste_block("7\t8")
settle()

# three columns pasted at the next to last column: the third one needs a
# new column, and five rows at the last but two need two new rows
text = "\n".join("\t".join(str(10 * r + c) for c in (1, 2, 3)) for r in range(5))
table.select_cell(rows0 - 3, cols0 - 2)
assert table.paste_block(text)
settle()
assert len(table.df.columns) == cols0 + 1, len(table.df.columns)
assert len(table.df) == rows0 + 2, len(table.df)
for r in range(5):
    for c in range(3):
        value = table.df.iloc[rows0 - 3 + r, cols0 - 2 + c]
        assert float(value) == 10 * r + c + 1, (r, c, value)
# the table on the screen shows the new column too
assert len(table.tree["columns"]) == cols0 + 1
shown = table.tree.item(str(rows0 + 1), "values")
assert [float(v) for v in shown[-3:]] == [41, 42, 43], shown
assert table.block_bounds() == (rows0 - 3, cols0 - 2, rows0 + 1, cols0), \
    table.block_bounds()
print("wider and longer paste grows the sheet ok")

# Undo takes the whole paste back - the new rows and column with it
settle(); app.undo_step(); settle()
assert len(app.table.df.columns) == cols0, len(app.table.df.columns)
assert len(app.table.df) == rows0, len(app.table.df)
assert all(str(v) == "" for v in app.table.df.iloc[rows0 - 3:, cols0 - 2])
app.redo_step(); settle()
table = app.table
assert len(table.df.columns) == cols0 + 1 and len(table.df) == rows0 + 2
assert float(table.df.iloc[rows0 + 1, cols0]) == 43
print("undo and redo of the paste ok")

# a paste that fits leaves the size alone
table.select_cell(0, 0)
assert table.paste_block("1\t2\n3\t4")
settle()
assert len(table.df.columns) == cols0 + 1 and len(table.df) == rows0 + 2
print("paste that fits does not grow ok")

# a block much wider than the sheet
table.select_cell(0, 0)
assert table.paste_block("\t".join(str(i) for i in range(30)))
settle()
assert len(table.df.columns) == 30, len(table.df.columns)
assert float(table.df.iloc[0, 29]) == 29
print("paste of 30 columns gives 30 columns ok")
root.destroy()
print("ALL OK")
