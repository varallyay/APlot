"""Headless test (1.7.0): `Copy graph style` and `Paste graph style`.

The right click on the background of a graph copies the look of the whole
graph; on another graph it pastes it: the page, the frame, the lengths and
the place of the axes, their lines, ticks, ranges and labels, the title,
the legend and every curve's plot style, line, marker and colours - the
curves one by one in their order.  The other graph keeps what it shows:
its columns, its legend texts, its drawings and text boxes; a curve it has
beyond those of the copied graph keeps its own style.  Undo takes the
paste back in one step.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from matplotlib.colors import to_hex

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


x = np.linspace(0.0, 10.0, 15)
app.table.set_dataframe(pd.DataFrame({"x": x, "a": np.sin(x), "b": np.cos(x)}),
                        check_all=True)
settle(2)
source = app.open_plot("line_symbol")
settle(10)
t = np.linspace(0.0, 50.0, 20)
app.table.set_dataframe(pd.DataFrame({"time": t, "p": t ** 0.5, "q": np.log1p(t),
                                      "r": 0.1 * t}), check_all=True)
settle(2)
target = app.open_plot("line")
settle(10)
target.series["p"].set_label("Pressure")
target.refresh_legend()
note = target.add_note((0.3, 0.6), text="my note")
target.draw()
settle(2)

# -- the copied graph is set up the way a careful user would ---------------
frame = dict(source.frame_cfg)
frame.update({"x_length": 0.5, "y_length": 0.35, "left": 0.2, "bottom": 0.25,
              "width": 2.5, "style": "box"})
source.apply_frame(frame)
cfg = dict(source.axis_cfg["x"])
cfg.update({"auto": False, "min": -1.0, "max": 12.0, "label": "Time [s]",
            "label_size": 17, "tick_size": 13})
source.apply_axis("x", cfg)
cfg = dict(source.axis_cfg["y"])
cfg.update({"auto": False, "min": -2.0, "max": 2.0, "label": "Signal [V]"})
source.apply_axis("y", cfg)
source.ax.set_title("My title")
source.fonts["title"] = 21
line = source.series["a"]
line.set_color("#c03020"); line.set_linewidth(3.5); line.set_linestyle("--")
line.set_marker("s"); line.set_markersize(9)
source.series["b"].set_color("#2050c0"); source.series["b"].set_marker("^")
source.legend_state["a"]["size"] = 7
source.legend_state["a"]["pos"] = (0.15, 0.2)
source.refresh_series_visuals("a"); source.refresh_series_visuals("b")
source.refresh_legend()
source.draw()
settle(2)

# -- copy on the one, paste on the other -----------------------------------
source.copy_graph_style()
assert aplot.PlotWindow._style_clipboard["curves"] == 2
before = app.plot_document(target)
assert target.paste_graph_style()
settle(4)
for key in ("x_length", "y_length", "left", "bottom", "width", "style"):
    assert target.frame_cfg[key] == source.frame_cfg[key], key
assert tuple(target.ax.get_xlim()) == (-1.0, 12.0), target.ax.get_xlim()
assert tuple(target.ax.get_ylim()) == (-2.0, 2.0), target.ax.get_ylim()
assert target.ax.get_xlabel() == "Time [s]" and target.ax.get_ylabel() == "Signal [V]"
assert target.axis_cfg["x"]["label_size"] == 17 and target.axis_cfg["x"]["tick_size"] == 13
assert target.ax.get_title() == "My title" and target.fonts["title"] == 21
# the curves, one by one in their order
first, second, third = (target.series[name] for name in ("p", "q", "r"))
assert to_hex(first.get_color()) == "#c03020" and first.get_linewidth() == 3.5
assert first.get_linestyle() == "--" and first.get_marker() == "s"
assert first.get_markersize() == 9
assert to_hex(second.get_color()) == "#2050c0" and second.get_marker() == "^"
assert target.series_style.get("p", target.plot_style) == "line_symbol"
assert target.legend_state["p"]["size"] == 7
assert tuple(target.legend_state["p"]["pos"]) == (0.15, 0.2)
# what the graph shows stays its own
assert list(target.series) == ["p", "q", "r"]
assert first.get_label() == "Pressure", first.get_label()
assert second.get_label() == "q"
assert note in target.note_state, "the text box stays"
# the third curve has no partner in the copied graph: its own style
assert third.get_marker() in ("None", "none", "", None) or third.get_marker() == "None"
print("the style of the whole graph and of its curves, in order ok")

# -- Undo takes it back in one step ----------------------------------------
app.undo_step()
settle(4)
assert tuple(target.ax.get_xlim()) != (-1.0, 12.0)
assert target.ax.get_title() != "My title"
assert to_hex(target.series["p"].get_color()) != "#c03020"
assert target.series["p"].get_label() == "Pressure"
print("Undo takes the pasted style back ok")

# -- the right click menu of the background --------------------------------
menus = []
real_popup = tk.Menu.tk_popup
tk.Menu.tk_popup = lambda self, *a, **k: menus.append(self)
try:
    aplot.PlotWindow._style_clipboard = None
    target.show_object_menu(5, 5, 10, 10)
    menu = menus[-1]
    labels = [menu.entrycget(i, "label") for i in range(menu.index("end") + 1)
              if menu.type(i) == "command"]
    assert "Copy graph style" in labels and "Paste graph style" in labels, labels
    index = labels.index("Paste graph style")
    entries = [i for i in range(menu.index("end") + 1) if menu.type(i) == "command"]
    assert menu.entrycget(entries[index], "state") == "disabled"
    source.copy_graph_style()
    target.show_object_menu(5, 5, 10, 10)
    menu = menus[-1]
    entries = [i for i in range(menu.index("end") + 1) if menu.type(i) == "command"]
    labels = [menu.entrycget(i, "label") for i in entries]
    assert menu.entrycget(entries[labels.index("Paste graph style")], "state") == "normal"
    menu.invoke(entries[labels.index("Paste graph style")])
    settle(4)
    assert target.ax.get_title() == "My title"
finally:
    tk.Menu.tk_popup = real_popup
print("the menu of the background copies and pastes the style ok")

# -- a saved graph keeps the pasted style ----------------------------------
document = app.plot_document(target)
target.ax.set_title("other")
app.apply_plot_document(document)
settle(4)
assert target.ax.get_title() == "My title"
assert not errors, errors
print("ALL OK")
