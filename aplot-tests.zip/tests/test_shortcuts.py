"""Headless test (1.3.8): every keyboard shortcut, typed for real.

In the spreadsheet window (on the table, in an open cell, in the formula
bar) and in a diagram window, each shortcut must start its own command and
no other one - also with Caps Lock on (before 1.3.8 Ctrl+O, S, E, R, I, Z
and Q did nothing then) and with Num Lock on (on Linux, Ctrl+O, S and E
were taken for Ctrl+Alt+O, S and E: Import data, Export data and Export as
script).  The commands themselves are replaced by recorders here; what is
checked is which one a key reaches.
"""
import os, sys, tempfile

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from keys_help import Keys

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None

# -- 0. the modifiers of the commands, as this system has them ------------------
if sys.platform == "darwin":
    assert aplot.COMMAND_MODIFIERS == ("Control", "Command")
else:
    # "Command" is Mod1 to Tk: Alt on Linux, Num Lock on Windows
    assert aplot.COMMAND_MODIFIERS == ("Control",), aplot.COMMAND_MODIFIERS
    # "Option" is Mod2: Num Lock on Linux
    assert aplot.SECOND_MODIFIERS == ("Alt",), aplot.SECOND_MODIFIERS


class Key:
    def __init__(self, state, char="a"):
        self.state, self.char = state, char


assert aplot.is_command_key(Key(0x0004)), "Ctrl is a command"
assert not aplot.is_command_key(Key(0x0000)), "a plain key is typing"
assert not aplot.is_command_key(Key(0x0001)), "Shift is typing"
assert not aplot.is_command_key(Key(0x0002)), "Caps Lock is typing"
if sys.platform.startswith("linux"):
    assert not aplot.is_command_key(Key(0x0010)), "Num Lock (Mod2) is typing"
real_platform = sys.platform
try:
    sys.platform = "win32"          # AltGr on Windows: Ctrl and Alt at once
    assert aplot.altgr_character(Key(0x20004, "@")), "AltGr+V on a Hungarian keyboard"
    assert not aplot.altgr_character(Key(0x20004, "\x0f")), "Ctrl+Alt+O is a command"
    assert not aplot.altgr_character(Key(0x0004, "@"))
finally:
    sys.platform = real_platform
assert not aplot.altgr_character(Key(0x20004, "@")), "only on Windows"
print("the modifiers of the commands on this system ok")

# -- the commands are replaced by recorders --------------------------------------
calls = []


def recorder(name):
    def record(self, *args, **kwargs):
        calls.append(name)
        return None
    return record


for name in ("open_graph", "save_graph", "save_csv", "export_figure",
             "export_script", "open_regression", "load_csv", "undo_step",
             "redo_step", "edit_command", "quit_app", "new_random_numbers"):
    setattr(aplot.App, name, recorder(name))
for name in ("select_all_cells", "copy_block", "paste_block", "cut_block",
             "duplicate_block", "select_columns_of_block",
             "select_rows_of_block", "clear_block"):
    setattr(aplot.DataTable, name, recorder(name))
for name in ("copy_shortcut", "paste_clipboard", "cut_selection",
             "duplicate_selection", "reset_zoom", "zoom_by", "delete_selection"):
    setattr(aplot.PlotWindow, name, recorder(name))

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
SW, SH = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry(f"{int(SW * 0.44)}x{int(SH * 0.6)}+10+40")
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))
keys = Keys(root)
print("keys:", keys.how)
x = np.linspace(0.0, 10.0, 12)
app.table.set_dataframe(pd.DataFrame({"x": x, "y1": np.sin(x), "y2": np.cos(x)}),
                        check_all=True)
keys.settle(4)
table = app.table

FILE = [("ctrl+o", "open_graph"), ("ctrl+s", "save_graph"),
        ("ctrl+shift+s", "save_csv"), ("ctrl+e", "export_figure"),
        ("ctrl+shift+e", "export_script"), ("ctrl+alt+o", "load_csv"),
        ("ctrl+alt+s", "save_csv"), ("ctrl+alt+e", "export_script"),
        ("ctrl+r", "open_regression"), ("ctrl+i", "load_csv"),
        ("ctrl+z", "undo_step"), ("ctrl+shift+z", "redo_step"),
        ("ctrl+q", "quit_app"), ("F9", "new_random_numbers")]
SHEET = [("ctrl+a", "select_all_cells"), ("ctrl+c", "copy_block"),
         ("ctrl+v", "paste_block"), ("ctrl+x", "cut_block"),
         ("ctrl+d", "duplicate_block"), ("ctrl+space", "select_columns_of_block"),
         ("shift+space", "select_rows_of_block"), ("Delete", "clear_block"),
         ("BackSpace", "clear_block")]
DIAGRAM = [("ctrl+c", "copy_shortcut"), ("ctrl+v", "paste_clipboard"),
           ("ctrl+x", "cut_selection"), ("ctrl+d", "duplicate_selection"),
           ("ctrl+0", "reset_zoom"), ("ctrl+plus", "zoom_by"),
           ("ctrl+equal", "zoom_by"), ("ctrl+minus", "zoom_by"),
           ("Delete", "delete_selection"), ("BackSpace", "delete_selection")]


def check(where, combos, prepare=None):
    wrong = []
    for key, wanted in combos:
        if prepare is not None:
            prepare()
        calls.clear()
        keys.press(key, wait=3)
        if calls != [wanted]:
            wrong.append(f"{key} -> {calls or 'nothing'} (not {wanted})")
    assert not wrong, f"{where}: " + "; ".join(wrong)
    print(f"{where}: all {len(combos)} keys ok")


def on_table():
    if table._editor is not None:
        table._leave_editor()
    table.tree.focus_set()
    keys.settle(1)


def in_a_cell():
    if table._editor is None:
        table.edit_cursor()
        keys.settle(2)


def in_the_formula_bar():
    table.formula_bar.entry.focus_set()
    keys.settle(1)


box = table.tree.bbox("1", "#2")
keys.click(table.tree, box[0] + box[2] // 2, box[1] + box[3] // 2)
keys.press("Escape")

# -- 1. the spreadsheet window ----------------------------------------------------
check("the table", FILE + SHEET, on_table)
check("an open cell", FILE, in_a_cell)
check("the formula bar", FILE, in_the_formula_bar)
for which in ("caps", "num"):
    keys.lock(which, True)
    try:
        check(f"the table, {which} lock on", FILE + SHEET, on_table)
        check(f"an open cell, {which} lock on", FILE, in_a_cell)
    finally:
        keys.lock(which, False)

# -- 2. an open cell keeps the keys of its text ----------------------------------
on_table()
table.edit_cursor()
keys.settle(2)
editor = table._editor[0]
editor.delete(0, "end")
keys.type("hello")
calls.clear()
keys.press("ctrl+a")
assert editor.selection_present() and editor.get() == "hello"
keys.press("ctrl+c")
assert root.clipboard_get() == "hello", root.clipboard_get()
assert calls == [], f"the table's own commands stayed out: {calls}"
keys.press("Escape")
print("an open cell: Ctrl+A and Ctrl+C work on its text ok")

# -- 3. a diagram window --------------------------------------------------------
plot = app.open_plot("line_symbol")
keys.settle(12)
plot.geometry(f"{int(SW * 0.5)}x{int(SH * 0.7)}+{int(SW * 0.47)}+40")
keys.settle(8)
keys.activate(plot)
assert keys.focus() is not None and keys.focus().winfo_toplevel() is plot
check("the diagram", FILE + DIAGRAM)
for which in ("caps", "num"):
    keys.lock(which, True)
    try:
        check(f"the diagram, {which} lock on", FILE + DIAGRAM)
    finally:
        keys.lock(which, False)

assert not errors, errors
keys.close()
print("ALL OK")
