"""Headless test (after 1.7.0): a legend box moved above the plot area is on the
saved picture whole.  `ax.add_artist` ties the box to the plot area, and
the picture is cut to what lies inside that tie: in 1.7.0 a box above
the graph was cut off in the saved PNG (and the copied picture), although
the screen showed it."""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import matplotlib
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: False
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=6, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


settle()
x = np.linspace(0.0, 10.0, 30)
app.table.set_dataframe(pd.DataFrame({"x": x, "y": np.sin(x) + 3.0,
                                      "z": np.cos(x) + 3.0}), check_all=True)
settle()
plot = app.open_plot("line")
settle()
assert len(plot.legends) >= 1, plot.legends

# every box above the top of the plot area, as the user dragged them there
for index, column in enumerate(plot.legend_state):
    plot.legend_state[column]["pos"] = (0.4 + 0.4 * index, 1.3)
plot.refresh_legend()
plot.canvas.draw()


def inside(outer, inner, slack=1.0):
    return (outer.x0 - slack <= inner.x0 and inner.x1 <= outer.x1 + slack
            and outer.y0 - slack <= inner.y0 and inner.y1 <= outer.y1 + slack)


renderer = plot.canvas.get_renderer()
axes_top = plot.ax.get_window_extent(renderer).y1
cut = plot.fig.get_tightbbox(renderer).transformed(plot.fig.dpi_scale_trans)
for column, legend in plot.legends.items():
    box = legend.get_window_extent(renderer)
    assert box.y0 > axes_top, (column, box, axes_top)      # really above it
    assert not legend.get_clip_on(), column
    assert inside(cut, box), (column, box, cut)
print("the boxes above the graph are inside the cut-out of the page ok")

# the written picture is as tall as the graph and the boxes over it
path = plot.figure_image(os.path.join(HOME, "graph.png"), dpi=100)
height = matplotlib.image.imread(path).shape[0]
top = max(legend.get_window_extent(renderer).y1 for legend in plot.legends.values())
bottom = cut.y0
assert height >= (top - bottom) * 100.0 / plot.fig.dpi - 2, (height, top, bottom)
print(f"the picture is {height} px tall, the boxes are on it ok")

# the exported program puts its boxes outside the clipping too
assert "legend.set_clip_on(False)" in plot.to_script()
print("the exported program does the same ok")

root.destroy()
print("ALL OK")
