"""Headless test (1.3.0): the installed APlot is a program of its own, and
an update installs itself wherever the running file lies.

* APlot.app (built here as on a Mac: only the folder, no macOS needed) and
  the Linux install hold a copy of the program and start that copy;
* an installation of an older APlot that starts the file being edited is
  given a copy of its own;
* updating a git working copy (a real repository, with a pretend GitHub in
  a folder), a file only an administrator may write, and the fall-back:
  installing the new version for the user.
Nothing outside a temporary home folder is touched.
"""
import os, re, shutil, subprocess, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import tkinter as tk
import aplot

Path = aplot.Path
said = []
aplot.messagebox.showinfo = lambda *a, **k: said.append(("info",) + a)
aplot.messagebox.showwarning = lambda *a, **k: said.append(("warning",) + a)
aplot.messagebox.showerror = lambda *a, **k: said.append(("error",) + a)
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.UPDATE_FOLDER = Path(HOME) / ".aplot" / "updates"
aplot.UPDATE_BACKUPS = Path(HOME) / ".aplot" / "backups"
SOURCE = open(aplot.__file__, encoding="utf-8").read()


def version_file(path, version):
    """A copy of aplot.py that says it is `version`."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(re.sub(r'^APP_VERSION = "[^"]*"', f'APP_VERSION = "{version}"',
                           SOURCE, count=1, flags=re.M), encoding="utf-8")
    return path


def version_of(path):
    return aplot.program_facts(Path(path).read_text(encoding="utf-8"))["version"]


def run_version(command):
    done = subprocess.run(command + ["--version"], capture_output=True,
                          text=True, timeout=120)
    assert done.returncode == 0, done.stderr
    return done.stdout.strip()


assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.3.0")
assert "| 1.3.0 | 2026-10-05 |" in aplot.DOCUMENTATION
work = Path(tempfile.mkdtemp()) / "My Code"             # with a space in it
edited = version_file(work / "aplot.py", "1.2.9")

# -- 1. APlot.app holds a copy and starts it ---------------------------------
apps = Path(HOME) / "Applications"
bundle = aplot.make_macos_app(apps, program=edited, platform="darwin")
assert bundle == apps / "APlot.app", bundle
copy = bundle / "Contents" / "Resources" / "aplot.py"
assert copy.read_bytes() == edited.read_bytes()
launcher = bundle / "Contents" / "MacOS" / "APlot"
text = launcher.read_text()
assert str(edited) not in text and "Resources/aplot.py" in text, text
assert aplot.BUNDLE_MARK in text and os.access(launcher, os.X_OK)
assert aplot.app_bundle_of(copy) == bundle and aplot.app_bundle_of(edited) is None
assert aplot.is_installed_copy(copy, "darwin") and not aplot.is_installed_copy(edited, "darwin")
assert run_version([str(launcher)]).startswith("APlot 1.2.9")
version_file(edited, "1.2.10")                 # the file is edited...
assert version_of(copy) == "1.2.9"             # ...the app does not change
# the app can be moved and still finds its copy
moved = Path(tempfile.mkdtemp()) / "APlot.app"
shutil.copytree(bundle, moved)
assert run_version([str(moved / "Contents" / "MacOS" / "APlot")]).startswith("APlot 1.2.9")
shutil.rmtree(moved)
# renewed from its own copy: the copy stays, the rest is written again
assert aplot.make_macos_app(apps, program=copy, platform="darwin") == bundle
assert version_of(copy) == "1.2.9"
assert aplot.make_macos_app(apps, program=edited) is None or sys.platform == "darwin"
print("APlot.app holds a copy of its own, starts it, and may be moved ok")

# -- 2. the Linux install holds a copy as well -----------------------------
prefix = Path(tempfile.mkdtemp())
written = aplot.install_linux_desktop(prefix=prefix, program=edited, refresh=False)
paths = aplot.linux_desktop_paths(prefix=prefix)
assert paths["program"] in written and paths["launcher"] in written
assert paths["program"] == prefix / "share" / "aplot" / "aplot.py"
assert paths["program"].read_bytes() == edited.read_bytes()
entry = paths["desktop"].read_text()
exec_line = [line for line in entry.splitlines() if line.startswith("Exec=")][0]
assert str(paths["program"]) in exec_line and "My Code" not in exec_line, exec_line
assert run_version([str(paths["launcher"])]).startswith("APlot 1.2.10")
version_file(edited, "1.2.11")
assert version_of(paths["program"]) == "1.2.10", "the installed copy stays"
# installed again from its own copy: nothing to copy, no error
aplot.install_linux_desktop(prefix=prefix, program=paths["program"], refresh=False)
assert version_of(paths["program"]) == "1.2.10"
removed = aplot.uninstall_linux_desktop(prefix=prefix, refresh=False)
assert paths["program"] in removed and paths["launcher"] in removed
assert not paths["program_folder"].exists()
print("the Linux install holds a copy, `aplot` starts it, uninstall takes it ok")

# -- 3. an installation of an older APlot gets a copy of its own ---------------
# Linux: a menu entry of 1.2.1 starts the edited file itself
mine = aplot.linux_desktop_paths()
mine["desktop"].parent.mkdir(parents=True, exist_ok=True)
mine["desktop"].write_text(aplot.DESKTOP_ENTRY.format(
    name="APlot", icon="aplot", mime=aplot.PROJECT_MIMETYPE,
    command=f"{aplot.desktop_quote(sys.executable)} {aplot.desktop_quote(edited)}"))
notes = aplot.separate_installation(program=edited, platform="linux")
assert notes and "installed on its own" in notes[0], notes
assert version_of(mine["program"]) == "1.2.11"
assert str(mine["program"]) in mine["desktop"].read_text()
assert aplot.separate_installation(program=edited, platform="linux") == [], "once"
assert aplot.separate_installation(program=mine["program"], platform="linux") == []
# Mac: an APlot.app of 1.2.1 whose launcher starts the edited file
shutil.rmtree(bundle)
(bundle / "Contents" / "MacOS").mkdir(parents=True)
launcher.write_text("#!/bin/sh\nexport APLOT_APP_BUNDLE=1\n"
                    f"exec {sys.executable} '{edited}' \"$@\"\n")
notes = aplot.separate_installation(program=edited, platform="darwin")
assert notes and "a copy of its own" in notes[0], notes
assert version_of(copy) == "1.2.11" and str(edited) not in launcher.read_text()
assert aplot.separate_installation(program=edited, platform="darwin") == []
print("an older APlot.app or menu entry is given a copy of its own, once ok")

# -- 4. a git working copy -----------------------------------------------------
GIT = ["git", "-c", "user.name=Test", "-c", "user.email=test@example.org",
       "-c", "init.defaultBranch=main", "-c", "advice.detachedHead=false"]


def git(folder, *args):
    done = subprocess.run(GIT + ["-C", str(folder), *args], capture_output=True,
                          text=True, timeout=60)
    assert done.returncode == 0, (args, done.stderr)
    return done.stdout.strip()


github = Path(tempfile.mkdtemp()) / "varallyay" / "APlot.git"   # the "GitHub"
github.mkdir(parents=True)
git(github, "init", "--bare", "-q")
author = Path(tempfile.mkdtemp()) / "author"
subprocess.run(GIT + ["clone", "-q", str(github), str(author)], check=True,
               capture_output=True)
version_file(author / "aplot.py", "1.3.0")
git(author, "symbolic-ref", "HEAD", "refs/heads/main")
git(author, "add", "aplot.py")
git(author, "commit", "-q", "-m", "1.3.0")
git(author, "push", "-q", "origin", "main")
clone = Path(tempfile.mkdtemp()) / "APlot"
subprocess.run(GIT + ["clone", "-q", str(github), str(clone)], check=True,
               capture_output=True)
version_file(author / "aplot.py", "9.9.0")                    # a new release
git(author, "commit", "-q", "-am", "9.9.0")
git(author, "push", "-q", "origin", "main")
download = version_file(aplot.UPDATE_FOLDER / "9.9.0" / "aplot.py", "9.9.0")
facts = {"version": "9.9.0", "date": "2099-01-01", "quicklook": aplot.QUICKLOOK_VERSION}
target = clone / "aplot.py"
result = aplot.install_update(download, facts, target=target, platform="linux")
assert result["installed"] is True and version_of(target) == "9.9.0", result
assert result["where"] == clone and result["backup"] is None
assert result["command"] == [sys.executable, str(target)]
assert "git pull" in result["notes"][0]
assert git(clone, "status", "--porcelain") == "", "a clean copy, as git left it"
print("a clean git copy of GitHub is brought up to date with git pull ok")

# a copy with work of its own is never touched: the user gets an installed APlot
version_file(author / "aplot.py", "9.9.1")
git(author, "commit", "-q", "-am", "9.9.1")
git(author, "push", "-q", "origin", "main")
with open(target, "a", encoding="utf-8") as handle:
    handle.write("\n# my own change\n")
mine_before = target.read_text()
download = version_file(aplot.UPDATE_FOLDER / "9.9.1" / "aplot.py", "9.9.1")
facts = dict(facts, version="9.9.1")
own_calls = []


def pretend_own_copy(program, platform=None):
    own_calls.append((Path(program), platform))
    return {"program": Path(HOME) / "own.py", "where": Path(HOME) / "own.py",
            "command": [sys.executable, str(Path(HOME) / "own.py")],
            "start": "the menu"}


result = aplot.install_update(download, facts, target=target, platform="linux",
                              own_copy=pretend_own_copy)
assert target.read_text() == mine_before, "the work in the copy is untouched"
assert own_calls == [(download, "linux")] and result["installed"] is True
assert result["command"] == [sys.executable, str(Path(HOME) / "own.py")]
note = result["notes"][0]
assert "left as it is" in note and "not committed" in note and "updates itself" in note, note
# other branches and other repositories are not pulled either
git(clone, "checkout", "-q", "--", "aplot.py")
git(clone, "checkout", "-q", "-b", "experiment")
assert aplot.git_update(clone)[0] is False and "experiment" in aplot.git_update(clone)[1]
git(clone, "checkout", "-q", "main")
git(clone, "remote", "set-url", "origin", str(author))
assert aplot.git_update(clone) == (False, f"it is not a copy of {aplot.UPDATE_PAGE}")
print("a git copy with changes, another branch or another remote is left alone ok")

# -- 5. a file only an administrator may write --------------------------------
system = Path(tempfile.mkdtemp()) / "aplot.py"
version_file(system, "1.3.0")
real_access = aplot.os.access
aplot.os.access = lambda path, mode, *a, **k: (
    False if str(path) in (str(system), str(system.parent)) else real_access(path, mode))
try:
    def admin_yes(new, old, platform=None):
        shutil.copyfile(new, old)
        return True, ""

    result = aplot.install_update(download, facts, target=system, platform="linux",
                                  administrator=admin_yes)
    assert result["installed"] and version_of(system) == "9.9.1", result
    assert result["backup"] and version_of(result["backup"]) == "1.3.0"
    version_file(system, "1.3.0")
    own_calls.clear()
    result = aplot.install_update(
        download, facts, target=system, platform="linux",
        administrator=lambda *a: (False, "the password of an administrator was not given"),
        own_copy=pretend_own_copy)
    assert version_of(system) == "1.3.0" and own_calls and result["installed"]
    assert "only an administrator may write it" in result["notes"][0]
    result = aplot.install_update(
        download, facts, target=system, platform="linux",
        administrator=lambda *a: (False, "no password"),
        own_copy=lambda *a: None)
    assert result["installed"] is False and str(download) in result["notes"][0]
finally:
    aplot.os.access = real_access
ok, why = aplot.copy_as_administrator(download, system, platform="win32")
assert ok is False and why
print("a system file: the password is asked for, else the user gets a copy ok")

# -- 6. the copy for the user, for real ---------------------------------------
own = aplot.install_own_copy(download, platform="linux")
assert own and version_of(own["program"]) == "9.9.1"
assert own["program"] == aplot.linux_desktop_paths()["program"]
assert own["command"] == [sys.executable, str(own["program"])]
own = aplot.install_own_copy(download, platform="darwin")
assert own["where"] == Path(HOME) / "Applications" / "APlot.app"
assert version_of(own["program"]) == "9.9.1"
assert own["command"][:4] == ["/usr/bin/open", "-n", "-a", str(own["where"])]
assert own["command"][-1] == "--args", "the graph is handed on after it"
print("the new version installed for the user: Linux menu or APlot.app ok")

# -- 7. the first start after an update, inside APlot.app ---------------------
settings = aplot.Config(os.path.join(HOME, "settings.json"))
real_target = aplot.update_target
inside = Path(HOME) / "Applications" / "APlot.app" / "Contents" / "Resources" / "aplot.py"
aplot.update_target = lambda: inside
plist = Path(HOME) / "Applications" / "APlot.app" / "Contents" / "Info.plist"
plist.write_text("old")
settings.set("update_state", "updated_from", "1.2.0")
info = aplot.after_update(settings, platform="darwin")
assert any("brought up to date" in one for one in info["notes"]), info
assert aplot.APP_VERSION in plist.read_text()
# a bundle that does not hold the running program is not touched
aplot.update_target = lambda: edited
plist.write_text("old")
settings.set("update_state", "updated_from", "1.2.0")
info = aplot.after_update(settings, platform="darwin")
assert plist.read_text() == "old" and not info["notes"]
# a newer version left a note: an older copy started meanwhile leaves it
settings.set("update_state", "updated_from", "99.0.0")
assert aplot.after_update(settings, platform="darwin") is None
assert settings.get("update_state", "updated_from") == "99.0.0"
settings.set("update_state", "updated_from", "")
aplot.update_target = real_target
print("after an update APlot.app is renewed only around its own copy ok")

# -- 8. the windows name the program file ---------------------------------------
root = tk.Tk()
app = aplot.App(root, settings)
root.update()
said.clear()
app.show_about()
about = said[-1][2]
assert f"Program: {aplot.program_place()}" in about, about
assert aplot.short_path(Path(HOME) / "x") == "~/x" and aplot.short_path("/usr/x") == "/usr/x"
dialog = aplot.UpdateDialog(root, {"version": "9.9.9", "date": "2099-01-01"},
                            on_update=lambda: None)
labels = []


def walk(widget):
    for child in widget.winfo_children():
        try:
            labels.append(str(child.cget("text")))
        except tk.TclError:
            pass
        walk(child)


walk(dialog)
assert any(f"in {aplot.program_place()}" in one for one in labels), labels
dialog.close()
said.clear()
assert app._separate_installation() == []
root.destroy()
print("About and the update window say which file is running ok")
print("ALL OK")
