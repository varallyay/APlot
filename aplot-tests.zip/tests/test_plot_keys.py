"""Headless test (1.3.8): the arrow keys in a diagram window, typed for real.

The selected object (a legend box, the title, a text box) moves with the
arrow keys - one pixel, ten with Shift - and keeps doing so when one goes
back and forth between the spreadsheet and the diagram:

* the sheet's window brought to the front and the diagram again;
* a cell edited (and left open) in the sheet, then the diagram again;
* `Update` (after an edit, after moving a column to the right axis): the
  diagram comes to the front *with the keyboard* - before 1.3.8 the
  keyboard stayed with the sheet behind it, and the arrows walked its cells;
* the axes window: while it is in front after `Apply`, the arrows move the
  object (a text field of the window keeps them for its text); after `OK`,
  `Close` or `Esc` the diagram has them back;
* of two diagrams, `Update` gives the keyboard to the one used last.
"""
import os, sys, tempfile, time, copy

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from keys_help import Keys

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
SW, SH = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry(f"{int(SW * 0.44)}x{int(SH * 0.6)}+10+40")
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))
keys = Keys(root)
print("keys:", keys.how)
x = np.linspace(0.0, 10.0, 12)
app.table.set_dataframe(pd.DataFrame({"x": x, "y1": np.sin(x), "y2": np.cos(x)}),
                        check_all=True)
keys.settle(4)


def open_diagram(left):
    window = app.open_plot("line_symbol")
    keys.settle(12)
    window.geometry(f"{int(SW * 0.5)}x{int(SH * 0.72)}+{int(left)}+40")
    keys.settle(6)
    window.set_zoom(0.5)            # all of the page in view, at every size
    keys.settle(10)
    return window


plot = open_diagram(SW * 0.47)
canvas = plot.canvas.get_tk_widget()


def spot(window, kind, key):
    """Where an object is, in pixels of the canvas widget."""
    window.canvas.draw()
    keys.settle(2)
    box = window.object_extent(kind, key)
    widget = window.canvas.get_tk_widget()
    height = window.fig.bbox.height
    return (int((box.x0 + box.x1) / 2 - widget.canvasx(0)),
            int(height - (box.y0 + box.y1) / 2 - widget.canvasy(0)))


def pixels(window=None):
    """Where the selected object is on the screen (its middle, pixels)."""
    window = window or plot
    window.canvas.draw()
    box = window.object_extent(*window.selection)
    return ((box.x0 + box.x1) / 2.0, (box.y0 + box.y1) / 2.0)


def select(kind, key, window=None):
    window = window or plot
    window.select_object(None, None)
    window.draw()
    keys.settle(2)
    keys.activate(window)
    widget = window.canvas.get_tk_widget()
    keys.click(widget, *spot(window, kind, key))
    time.sleep(aplot.RENAME_DELAY / 1000.0 + 0.1)   # never a second click
    keys.settle(2)
    assert window.selection == (kind, key), (window.selection, kind, key)


def moves(key, dx, dy, what, window=None, step=aplot.NUDGE_STEP):
    """The arrow `key` moves the selected object by (dx, dy) steps."""
    window = window or plot
    before = pixels(window)
    keys.press(key)
    after = pixels(window)
    got = (after[0] - before[0], after[1] - before[1])
    wanted = (dx * step, dy * step)
    assert abs(got[0] - wanted[0]) <= 1.01 and abs(got[1] - wanted[1]) <= 1.01, \
        f"{what}: {key} moved it by {got}, not {wanted}"


def stays(key, what, window=None):
    window = window or plot
    before = copy.deepcopy(window.selected_state())
    keys.press(key)
    assert window.selected_state() == before, f"{what}: {key} moved the object"


def focus_window():
    widget = keys.focus()
    return widget.winfo_toplevel() if widget is not None else None


def buttons(window, text):
    found = []
    stack = [window]
    while stack:
        widget = stack.pop()
        if widget.winfo_class() == "TButton" and str(widget.cget("text")) == text:
            found.append(widget)
        stack.extend(widget.winfo_children())
    return found


# -- 1. one pixel per arrow, ten with Shift ----------------------------------
for kind, key in (("legend", "y1"), ("text", "title")):
    select(kind, key)
    moves("Right", 1, 0, f"the {kind}")
    moves("Up", 0, 1, f"the {kind}")
    moves("Left", -1, 0, f"the {kind}")
    moves("Down", 0, -1, f"the {kind}")
    moves("shift+Right", 1, 0, f"the {kind}", step=aplot.NUDGE_BIG_STEP)
    moves("shift+Down", 0, -1, f"the {kind}", step=aplot.NUDGE_BIG_STEP)
note = plot.add_note((0.3, 0.55), text="Note")
keys.settle(4)
select("note", note)
moves("Right", 1, 0, "the text box")
moves("shift+Up", 0, 1, "the text box", step=aplot.NUDGE_BIG_STEP)
print("one pixel per arrow, ten with Shift: legend, title, text box ok")

# -- 2. to the sheet and back ---------------------------------------------------
select("legend", "y1")
table = app.table
keys.activate(root)
assert focus_window() is root, focus_window()
cursor = tuple(table.cursor)
stays("Down", "the sheet has the keyboard")
assert tuple(table.cursor) != cursor, "the arrow walked the sheet"
keys.activate(plot)
assert focus_window() is plot, focus_window()
moves("Right", 1, 0, "back in the diagram")
print("to the sheet and back: the arrows follow the window in front ok")

# -- 3. a cell edited (and left open), then the diagram again ---------------------
box = table.tree.bbox("2", "#2")
keys.click(table.tree, box[0] + box[2] // 2, box[1] + box[3] // 2)
keys.type("0.5")
keys.press("Return")                 # the next cell is open now
assert table._editor is not None
keys.activate(plot)
assert focus_window() is plot, focus_window()
moves("Left", -1, 0, "after editing a cell")
assert table.df.iat[2, 1] == 0.5, table.df.iat[2, 1]
print("a cell edited, then the diagram: the arrows move the object ok")

# -- 4. Update: the diagram in front has the keyboard -----------------------------
keys.activate(root)
box = table.tree.bbox("3", "#2")
keys.click(table.tree, box[0] + box[2] // 2, box[1] + box[3] // 2)
keys.type("0.25")
keys.press("Return")
keys.click(app.update_btn)
assert focus_window() is plot, ("Update leaves the keyboard with the sheet",
                                focus_window())
assert table._editor is None, "the open cell was kept and closed"
moves("Right", 1, 0, "right after Update")
moves("shift+Left", -1, 0, "right after Update", step=aplot.NUDGE_BIG_STEP)
keys.activate(root)
keys.click(table._checks["y2"]["R"])          # a column to the right axis
assert table.column_axis("y2") == "R", table.column_axis("y2")
keys.click(app.update_btn)
assert plot.right_axis_carries_curves(), "the right axis is drawn"
assert focus_window() is plot, focus_window()
moves("Up", 0, 1, "after a column went to the right axis")
print("Update brings the diagram forward with the keyboard ok")

# -- 5. the axes window ----------------------------------------------------------
for leave in ("OK", "Close", "Escape"):
    dialog = plot.open_axes_dialog("y")
    keys.settle(25)
    keys.activate(dialog)
    keys.click(buttons(dialog, "Apply")[0])
    assert focus_window() is dialog, focus_window()
    moves("Right", 1, 0, f"the axes window in front after Apply ({leave})")
    moves("shift+Up", 0, 1, "the axes window in front",
          step=aplot.NUDGE_BIG_STEP)
    moves("shift+Down", 0, -1, "the axes window in front",
          step=aplot.NUDGE_BIG_STEP)
    fields = []
    stack = [dialog]
    while stack:
        widget = stack.pop()
        if widget.winfo_class() in ("TEntry", "TSpinbox") and widget.winfo_viewable():
            fields.append(widget)
        stack.extend(widget.winfo_children())
    assert fields, "the axes window has fields"
    field = sorted(fields, key=lambda w: (w.winfo_rooty(), w.winfo_rootx()))[0]
    keys.click(field)
    assert keys.focus() is field, keys.focus()
    field.icursor("end")
    cursor = field.index("insert")
    stays("Left", "a text field keeps its arrows")
    if field.get():
        assert field.index("insert") == cursor - 1, "the text cursor moved"
    if leave == "Escape":
        keys.press("Escape")
    else:
        keys.click(buttons(dialog, leave)[0])
    assert not dialog.winfo_exists(), f"{leave} closes the window"
    assert focus_window() is plot, (leave, focus_window())
    moves("Left", -1, 0, f"after {leave} in the axes window")
print("the axes window: Apply, a text field, OK, Close and Esc ok")

# -- 6. two diagrams: Update gives the keyboard to the one used last ----------
# a small second one under the sheet's window, clear of every title bar
root.geometry(f"{int(SW * 0.44)}x{int(SH * 0.5)}+10+40")
second = app.open_plot("line_symbol")
keys.settle(12)
second.geometry(f"{int(SW * 0.42)}x{int(SH * 0.3)}+10+{int(SH * 0.5) + 110}")
keys.settle(6)
second.set_zoom(0.25)
keys.settle(10)
keys.activate(second)
assert focus_window() is second, focus_window()
second.select_object("legend", "y2")
second.draw()
keys.settle(2)
keys.activate(root)
keys.click(app.update_btn)
assert focus_window() is second, ("the diagram used last", focus_window())
moves("Right", 1, 0, "the second diagram", window=second)
select("legend", "y1")
keys.activate(root)
keys.click(app.update_btn)
assert focus_window() is plot, ("the first one, used last now", focus_window())
moves("Right", 1, 0, "the first diagram")
print("two diagrams: Update gives the keyboard to the one used last ok")

assert not errors, errors
keys.close()
print("ALL OK")
