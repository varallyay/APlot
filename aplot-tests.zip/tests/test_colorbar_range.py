"""Headless test (1.4.5): the range of the colours is set at the colour bar
itself - a double click on the bar opens its window, whose two fields show
the whole range of the data to begin with and lay the colour scale over a
narrower or a wider range once other numbers are typed in - and the label
of the bar is a text of its own: it is dragged like the label of an axis,
without its bar, and follows the bar when that is moved.
"""
import math, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from matplotlib.colors import LogNorm
from matplotlib.backend_bases import MouseEvent

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def close_all():
    for window in app.open_windows():
        window.destroy()
    settle(2)


def near(a, b, tol=1e-6):
    return all(math.isclose(p, q, abs_tol=tol) for p, q in zip(a, b))


def mouse(plot, name, x, y, dblclick=False):
    event = MouseEvent(name, plot.canvas, x, y, button=1, dblclick=dblclick)
    {"button_press_event": plot._on_button_press,
     "motion_notify_event": plot._on_motion,
     "button_release_event": plot._on_release}[name](event)


def click(plot, x, y, dblclick=False):
    mouse(plot, "button_press_event", x, y, dblclick)
    mouse(plot, "button_release_event", x, y)
    settle(2)


def drag(plot, start, end, steps=5):
    mouse(plot, "button_press_event", *start)
    for step in range(1, steps + 1):
        mouse(plot, "motion_notify_event",
              start[0] + (end[0] - start[0]) * step / steps,
              start[1] + (end[1] - start[1]) * step / steps)
    mouse(plot, "button_release_event", *end)
    settle(2)


def bar_middle(plot, column="y"):
    plot.canvas.draw()
    box = plot.hist2d_bars[column].ax.get_window_extent()
    return (0.5 * (box.x0 + box.x1), 0.5 * (box.y0 + box.y1))


def label_middle(plot, column="y"):
    plot.canvas.draw()
    box = plot.bar_label_artist(column).get_window_extent(plot._renderer())
    return (0.5 * (box.x0 + box.x1), 0.5 * (box.y0 + box.y1))


def norm_of(plot, column="y"):
    norm = plot.hist2d_bars[column].mappable.norm
    return float(norm.vmin), float(norm.vmax)


def bar_window(plot, column="y"):
    here = bar_middle(plot, column)
    mouse(plot, "button_press_event", *here, dblclick=True)
    mouse(plot, "button_release_event", *here)
    settle(4)
    window = plot._dialogs.get(f"bar-{column}")
    assert isinstance(window, aplot.ColorBarDialog), list(plot._dialogs)
    return window


xs, ys = np.linspace(0.3, 9.7, 12), np.linspace(101.5, 148.2, 7)
gx, gy = np.meshgrid(xs, ys, indexing="ij")
zs = np.exp(gx.ravel()) * (gy.ravel() - 100.0)
grid = pd.DataFrame({"x": gx.ravel(), "y": gy.ravel(), "z": zs})
z_low, z_high = float(zs.min()), float(zs.max())

# -- 1. the three x, y, z styles: the window of the bar sets the range ---------
for style in aplot.SURFACE_STYLES:
    app.table.set_dataframe(grid, check_all=True)
    settle(2)
    plot = app.open_plot(style)
    settle(6)
    assert near(norm_of(plot), (z_low, z_high), 1e-3), (style, norm_of(plot))
    window = bar_window(plot)
    # to begin with the fields show the whole range of the data ...
    assert window.low_var.get() == plot.range_text(z_low), window.low_var.get()
    assert window.high_var.get() == plot.range_text(z_high), window.high_var.get()
    assert window.has_log and not window.log_var.get()
    # ... and applying them as they are types nothing in
    window.apply()
    settle(3)
    assert plot.surface_cfg["y"]["vmin"] is None, style
    assert plot.surface_cfg["y"]["vmax"] is None, style
    # a narrower range: the colour scale is laid over it
    window.low_var.set("100")
    window.high_var.set("5000")
    window.apply()
    settle(4)
    assert plot.surface_cfg["y"]["vmin"] == 100.0, style
    assert plot.surface_cfg["y"]["vmax"] == 5000.0, style
    assert near(norm_of(plot), (100.0, 5000.0)), (style, norm_of(plot))
    assert "y" in plot.hist2d_bars and plot.selection == ("colorbar", "y"), style
    assert window.low_var.get() == "100" and window.high_var.get() == "5000"
    # only one end typed: the other one goes on following the data
    window.low_var.set("")
    window.apply()
    settle(4)
    assert plot.surface_cfg["y"]["vmin"] is None, style
    assert plot.surface_cfg["y"]["vmax"] == 5000.0, style
    assert near(norm_of(plot), (z_low, 5000.0), 1e-3), (style, norm_of(plot))
    assert window.low_var.get() == plot.range_text(z_low), window.low_var.get()
    # a wider range than the data squeezes the colours
    window.low_var.set("-1e6")
    window.high_var.set("2e6")
    window.apply()
    settle(4)
    assert near(norm_of(plot), (-1e6, 2e6)), (style, norm_of(plot))
    # the logarithmic scale with a range of its own
    window.low_var.set("10")
    window.high_var.set("1e4")
    window.log_var.set(True)
    window.apply()
    settle(4)
    assert plot.surface_cfg["y"]["log"] is True, style
    assert isinstance(plot.hist2d_bars["y"].mappable.norm, LogNorm), style
    assert near(norm_of(plot), (10.0, 1e4), 1e-6), (style, norm_of(plot))
    # the exported program has the same range
    script = plot.to_script()
    compile(script, "exported", "exec")
    assert "LogNorm" in script, style
    # the open curve dialog follows, and does not put the old range back
    dialog = plot.open_series_dialog(plot.series["y"])
    settle(4)
    assert dialog.sf_vmin_var.get() == "10" and dialog.sf_vmax_var.get() == "10000"
    window.high_var.set("2e4")
    window.apply()
    settle(4)
    assert dialog.sf_vmax_var.get() == "20000", dialog.sf_vmax_var.get()
    dialog.sf_alpha_var.set("0.9")
    dialog._apply()
    settle(4)
    assert plot.surface_cfg["y"]["vmax"] == 2e4, style
    assert near(norm_of(plot), (10.0, 2e4), 1e-6), (style, norm_of(plot))
    # ... and what is typed there shows in the window of the bar
    dialog.sf_vmin_var.set("20")
    settle(4)
    assert window.low_var.get() == "20", window.low_var.get()
    # `Whole range of the data` lets both ends go
    window.whole_range()
    settle(4)
    assert plot.surface_cfg["y"]["vmin"] is None, style
    assert plot.surface_cfg["y"]["vmax"] is None, style
    assert near(norm_of(plot), (z_low, z_high), 1e-3), (style, norm_of(plot))
    assert dialog.sf_vmin_var.get() == "" and dialog.sf_vmax_var.get() == ""
    # Undo takes one Apply back
    window.log_var.set(False)
    window.low_var.set("100")
    window.apply()
    settle(4)
    assert near(norm_of(plot)[:1], (100.0,)), style
    app.undo_step()
    settle(4)
    assert plot.surface_cfg["y"]["vmin"] is None, style
    close_all()
    print(f"{style}: the range of the colours is set at the bar ok")

# -- 2. a 2D histogram has a range too -----------------------------------------
rng = np.random.default_rng(3)
cloud = pd.DataFrame({"x": rng.normal(0.0, 1.0, 4000),
                      "y": rng.normal(0.0, 1.0, 4000)})
app.table.set_dataframe(cloud, check_all=True)
settle(2)
plot = app.open_plot("hist2d")
settle(6)
plot.hist2d_cfg.setdefault("y", plot.default_hist2d_cfg())["colorbar"] = True
plot.refresh_series_visuals("y")
plot.draw()
settle(2)
whole = plot.color_data_range("y")
assert whole is not None and whole[0] >= 1 and whole[1] > 10, whole
assert near(norm_of(plot), whole), (norm_of(plot), whole)
window = bar_window(plot)
assert not window.has_log
assert window.low_var.get() == plot.range_text(whole[0])
assert window.high_var.get() == plot.range_text(whole[1])
window.high_var.set("10")
window.label_var.set("Counts")
window.apply()
settle(4)
assert plot.hist2d_cfg["y"]["vmax"] == 10.0 and plot.hist2d_cfg["y"]["vmin"] is None
assert near(norm_of(plot), (whole[0], 10.0)), norm_of(plot)
assert plot.bar_label_artist("y").get_text() == "Counts"
script = plot.to_script()
compile(script, "exported", "exec")
assert "vmax=10.0" in script and "set_label('Counts'" in script
# the curve dialog has the two fields, and keeps the label of the bar
dialog = plot.open_series_dialog(plot.series["y"])
settle(4)
assert dialog.h2_vmax_var.get() == "10" and dialog.h2_vmin_var.get() == ""
dialog.h2_vmin_var.set("2")
settle(4)
assert plot.hist2d_cfg["y"]["vmin"] == 2.0
assert near(norm_of(plot), (2.0, 10.0)), norm_of(plot)
assert plot.bar_label_artist("y").get_text() == "Counts"
assert window.low_var.get() == "2", window.low_var.get()
close_all()
print("a 2D histogram: the range of the counts and the label of its bar ok")

# -- 3. the label is dragged on its own; the bar stays ------------------------
app.table.set_dataframe(grid, check_all=True)
settle(2)
plot = app.open_plot("pcolor")
settle(6)
plot.set_bar_label("y", "Field [V/m]")
plot.draw()
settle(2)
assert plot.bar_label_offset("y") == (0.0, 0.0)
box = plot.color_bar_box("y")
bar_at = bar_middle(plot)
spot = label_middle(plot)
assert plot.object_at(*spot) == ("barlabel", "y"), plot.object_at(*spot)
# a click selects and moves nothing
click(plot, *spot)
assert plot.selection == ("barlabel", "y") and plot.is_marked()
assert plot.bar_label_offset("y") == (0.0, 0.0)
# dragged 30 pixels to the right and 40 up
drag(plot, spot, (spot[0] + 30, spot[1] + 40))
assert near(plot.color_bar_box("y"), box), "the bar stays where it is"
assert near(bar_middle(plot), bar_at, 0.5)
offset = plot.bar_label_offset("y")
assert near(offset, (plot.points(30), plot.points(40)), 1e-6), offset
there = label_middle(plot)
assert near(there, (spot[0] + 30, spot[1] + 40), 1.5), (spot, there)
assert plot.selection == ("barlabel", "y") and not plot.is_editing_inline()
assert plot.surface_cfg["y"]["bar_label_offset"] == list(offset)
# the label is found where it stands now, and the bar is not found between
assert plot.object_at(*there) == ("barlabel", "y")
far = (there[0], there[1] + 60)
drag(plot, there, far)
there = label_middle(plot)
assert near(there, far, 1.5), (far, there)
between = (0.5 * (there[0] + bar_at[0]) + 40, there[1])
assert plot.object_at(*between)[0] != "colorbar", plot.object_at(*between)
# the arrow keys move the label, not the bar
before = plot.bar_label_offset("y")
plot.nudge_selection(aplot.NUDGE_STEP, 0)
settle(2)
after = plot.bar_label_offset("y")
assert after[0] > before[0] and after[1] == before[1], (before, after)
assert near(plot.color_bar_box("y"), box)
# Undo takes the last drag back - the arrow key first
app.undo_step()
settle(4)
assert near(plot.bar_label_offset("y"), before), plot.bar_label_offset("y")
app.undo_step()
settle(4)
assert near(plot.bar_label_offset("y"), offset), plot.bar_label_offset("y")
app.redo_step()
settle(4)
assert near(plot.bar_label_offset("y"), before)
# dragging the bar carries its label along, as far from it as it was put
before_label, before_bar = label_middle(plot), bar_middle(plot)
plot.select_object(None, None)
drag(plot, before_bar, (before_bar[0] - 50, before_bar[1] + 10))
assert near(bar_middle(plot), (before_bar[0] - 50, before_bar[1] + 10), 1.0)
assert near(label_middle(plot), (before_label[0] - 50, before_label[1] + 10), 1.5)
assert near(plot.bar_label_offset("y"), before)
# the curve dialog, another text and a new range keep the place of the label
dialog = plot.open_series_dialog(plot.series["y"])
settle(4)
dialog.sf_bar_label_var.set("Potential [V]")
settle(4)
assert near(plot.bar_label_offset("y"), before)
plot.set_color_range("y", 100, 5000)
plot.draw()
settle(2)
assert near(plot.bar_label_offset("y"), before)
assert plot.bar_label_artist("y").get_text() == "Potential [V]"
dialog.close()
settle(2)
# the exported program and a saved diagram keep it
script = plot.to_script()
compile(script, "exported", "exec")
assert "yaxis.label.set_transform(" in script
assert "bar_label_offset" in repr(app.plot_document(plot))
# the slow second click still writes the label in place
plot.select_object(None, None)
spot = label_middle(plot)
click(plot, *spot)
time.sleep(0.45)
click(plot, *spot)
assert plot.is_editing_inline(), "the slow second click opens the editor"
plot.cancel_inline_edit()
settle(2)
assert near(plot.bar_label_offset("y"), before)
# `Reset dragged texts` puts it back beside its bar
plot.reset_text_offsets()
settle(2)
assert plot.bar_label_offset("y") == (0.0, 0.0)
assert "bar_label_offset" not in plot.surface_cfg["y"]
print("the label of the bar is dragged on its own ok")
close_all()

print("ALL OK")
