"""Headless test (1.7.0): `3D Wireframe` - x, y, z drawn as a net of lines
in space (ax.plot_wireframe), on the same axes in space as `3D Surface`:
the view, the axes, the Z page and the colour scale are the surface's.
The lines are drawn in one colour to begin with, or every piece in the
colour of its height (with a colour bar); the curve window shows the
lines of the net instead of the painting of a surface; scattered points
are joined into the edges of triangles; the exported program draws the
same net, and a saved diagram keeps it.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import matplotlib
import aplot

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def run_script(plot):
    script = plot.to_script()
    compile(script, "exported", "exec")
    space = {"__name__": "exported"}
    backend = matplotlib.get_backend()
    try:
        matplotlib.use("Agg", force=True)
        exec(compile(script.replace("plt.show()", ""), "diagram.py", "exec"),
             space)
    finally:
        import matplotlib.pyplot as plt
        plt.close("all")
        matplotlib.use(backend, force=True)
    return script, space


xs, ys = np.linspace(-3.0, 3.0, 25), np.linspace(-2.0, 2.0, 17)
gx, gy = np.meshgrid(xs, ys, indexing="ij")
zs = 10.0 * np.exp(-(gx.ravel() ** 2 + gy.ravel() ** 2) / 2.0)
grid = pd.DataFrame({"x": gx.ravel(), "y": gy.ravel(), "height": zs})

# -- 1. the style is there, and draws a net of lines in space -----------------
codes = [code for _label, code, *_rest in aplot.PLOT_STYLES]
assert codes.index("wireframe3d") == codes.index("surface3d") + 1
assert "wireframe3d" in aplot.SURFACE_STYLES and "wireframe3d" in aplot.SPACE_STYLES
assert "wireframe3d" in aplot.PLOT_ICON_PAINTERS
assert aplot.plot_tool_icon is not None
app.table.set_dataframe(grid, check_all=True)
settle(2)
plot = app.open_plot("wireframe3d")
settle(8)
assert plot.is_3d() and plot.ax3d is not None and not plot.ax.axison
main = plot.surface_artists["y"][0]
assert type(main).__name__ == "Line3DCollection", type(main)
assert main.axes is plot.ax3d
assert plot.surface_cfg["y"]["colorbar"] is False
assert plot.frame_cfg["style"] == aplot.SURFACE3D_FRAME
# all 25 x 17 lines of the grid: fewer than WIREFRAME_LINES
assert len(main._segments3d) == 25 + 17, len(main._segments3d)
print("the style draws a net of lines in space ok")

# -- 2. the curve window: the lines of the net, not the painting -------------
dialog = plot.open_series_dialog(plot.series["y"])
settle(10)
box = dialog.surface3d_box
assert box.winfo_ismapped() and dialog.surface_box.winfo_ismapped()
assert "wireframe" in str(box.cget("text"))
shown = lambda row: all(one.winfo_ismapped() for one in box.grid_slaves(row=row))
hidden = lambda row: not any(one.winfo_ismapped() for one in box.grid_slaves(row=row))
assert all(shown(row) for row in dialog.WIRE3D_ROWS)
assert all(hidden(row) for row in dialog.PAINT3D_ROWS)
assert box.grid_slaves(row=0), "the view is there as for a surface"
dialog.sf_wires_var.set("10")
dialog.sf_wire_width_var.set("2.5")
dialog.sf_wire_color.set_color("#aa2200")
dialog._apply()
settle(4)
main = plot.surface_artists["y"][0]
assert plot.surface_cfg["y"]["wires"] == 10
# matplotlib takes every n-th row: 10 lines asked, 9 or 10 drawn
assert 16 <= len(main._segments3d) <= 20, len(main._segments3d)
assert abs(float(np.ravel(main.get_linewidth())[0]) - 2.5) < 1e-9
assert matplotlib.colors.to_hex(main.get_color()[0]) == "#aa2200"
# every piece in the colour of its height, with the colour bar
dialog.sf_wire_onecolor_var.set(False)
dialog.sf_bar_var.set(True)
dialog._apply()
settle(4)
main = plot.surface_artists["y"][0]
assert main.get_array() is not None and len(main.get_array()) > 20
low, high = float(np.min(main.get_array())), float(np.max(main.get_array()))
assert 0.0 <= low < 1.0 and 9.0 < high <= 10.0, (low, high)
assert "y" in plot.hist2d_bars, "the colour bar"
# to a painted surface: its own lines come back, the net's go
dialog.plot_style_var.set(aplot.name_of(aplot.PLOT_STYLES, "surface3d", ""))
dialog._on_style_changed()
settle(6)
assert "surface" in str(box.cget("text"))
assert all(shown(row) for row in dialog.PAINT3D_ROWS)
assert all(hidden(row) for row in dialog.WIRE3D_ROWS)
assert type(plot.surface_artists["y"][0]).__name__ == "Poly3DCollection"
dialog.plot_style_var.set(aplot.name_of(aplot.PLOT_STYLES, "wireframe3d", ""))
dialog._on_style_changed()
settle(6)
assert plot.is_3d() and type(plot.surface_artists["y"][0]).__name__ == "Line3DCollection"
dialog.close()
settle(2)
print("the curve window: lines, width, colour, colour by height ok")

# -- 3. the exported program and the saved diagram ----------------------------
script, space = run_script(plot)
assert "ax3d.plot_wireframe(" in script and "Line3DCollection(" in script
assert "fig.colorbar(surf_" in script
document = app.plot_document(plot)
assert "wireframe3d" in repr(document)
app.apply_plot_document(document)
settle(6)
plot = app.open_windows()[-1]
assert plot.is_3d()
main = plot.surface_artists["y"][0]
assert type(main).__name__ == "Line3DCollection" and main.get_array() is not None
assert plot.surface_cfg["y"]["wires"] == 10
plot.surface_cfg["y"]["wire_onecolor"] = True
plot.refresh_series_visuals("y")
plot.draw()
settle(2)
script, space = run_script(plot)
assert "ax3d.plot_wireframe(" in script and "Line3DCollection(" not in script
print("the exported program and the saved diagram keep the net ok")

# -- 4. a logarithmic Z axis and scattered points -----------------------------
plot.axis_cfg["z"]["scale"] = "log"
plot.apply_axis("z", dict(plot.axis_cfg["z"]))
plot.draw()
settle(4)
assert type(plot.surface_artists["y"][0]).__name__ == "Line3DCollection"
run_script(plot)
for window in app.open_windows():
    window.destroy()
settle(2)
rng = np.random.default_rng(3)
scattered = pd.DataFrame({"x": rng.uniform(-3, 3, 60), "y": rng.uniform(-2, 2, 60)})
scattered["height"] = 10.0 * np.exp(-(scattered.x ** 2 + scattered.y ** 2) / 2.0)
app.table.set_dataframe(scattered, check_all=True)
settle(2)
plot = app.open_plot("wireframe3d")
settle(8)
main = plot.surface_artists["y"][0]
assert type(main).__name__ == "Poly3DCollection", type(main)
assert np.allclose(main.get_facecolor()[:, 3], 0.0), "the triangles are not painted"
script, _space = run_script(plot)
assert "ax3d.plot_trisurf(" in script and "color=(1, 1, 1, 0)" in script
print("a logarithmic Z axis and scattered points ok")

assert not errors, errors
print("ALL OK")
