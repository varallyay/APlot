"""Headless test (1.3.6): APlot installed by a package.

* a package leaves PACKAGED beside the program: About, the updater and the
  start know it;
* the files of a .deb or .rpm are never written over: an update goes into
  the user's own copy, and the package's start then hands over to it;
* a self-contained APlot writes an update into a folder of the user, and
  its bootstrap starts the newer program;
* a flatpak that is not self-contained is told to update the flatpak;
* the Linux install can write into a package tree (destdir) with the final
  paths in its files; APlot.app gets real .icns icons without iconutil and
  a launcher that finds conda, python.org or Homebrew Python.
Nothing outside temporary folders is touched.
"""
import importlib.util, io, os, re, shutil, struct, subprocess, sys, tempfile

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
for name in ("APLOT_FROZEN", "APLOT_UPDATE_TARGET", "APLOT_NEWEST", "FLATPAK_ID"):
    os.environ.pop(name, None)

import aplot

Path = aplot.Path
aplot.UPDATE_FOLDER = Path(HOME) / ".aplot" / "updates"
aplot.UPDATE_BACKUPS = Path(HOME) / ".aplot" / "backups"
SOURCE = open(aplot.__file__, encoding="utf-8").read()


def version_file(path, version):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(re.sub(r'^APP_VERSION = "[^"]*"', f'APP_VERSION = "{version}"',
                           SOURCE, count=1, flags=re.M), encoding="utf-8")
    return path


def version_of(path):
    return aplot.program_facts(Path(path).read_text(encoding="utf-8"))["version"]


assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.3.6")
assert "| 1.3.6 | 2026-10-16 |" in aplot.DOCUMENTATION

# -- 1. the mark of a package ---------------------------------------------------
packaged = version_file(Path(tempfile.mkdtemp()) / "share" / "aplot" / "aplot.py", "1.3.6")
own = version_file(Path(tempfile.mkdtemp()) / "aplot.py", "1.3.6")
assert aplot.package_kind(own) == "" and aplot.is_installed_copy(own, "linux") is False
(packaged.parent / aplot.PACKAGE_MARK).write_text("deb\n")
assert aplot.package_kind(packaged) == "deb" and aplot.is_installed_copy(packaged, "linux")
os.environ["APLOT_FROZEN"] = "msi"
assert aplot.package_kind(own) == "msi"
del os.environ["APLOT_FROZEN"]
os.environ["FLATPAK_ID"] = "hu.feti.APlot"
assert aplot.package_kind(own) == "flatpak"
del os.environ["FLATPAK_ID"]
print("PACKAGED beside the program, a self-contained build and a flatpak are told apart ok")

# -- 2. updating a .deb: the package is left alone, the user gets a copy ---------
download = version_file(aplot.UPDATE_FOLDER / "9.9.0" / "aplot.py", "9.9.0")
facts = {"version": "9.9.0", "date": "2099-01-01", "quicklook": aplot.QUICKLOOK_VERSION}
calls = []


def pretend_own(program, platform=None):
    calls.append(Path(program))
    target = aplot.linux_desktop_paths()["program"]
    aplot.copy_program(program, target)
    return {"program": target, "where": target, "command": [sys.executable, str(target)],
            "start": "the applications menu"}


asked_admin = []
before = packaged.read_bytes()
result = aplot.install_update(download, facts, target=packaged, platform="linux",
                              own_copy=pretend_own,
                              administrator=lambda *a: asked_admin.append(a) or (True, ""))
assert packaged.read_bytes() == before, "the file of the package is untouched"
assert asked_admin == [], "no password is asked to write over a package"
assert result["installed"] and calls == [download], result
assert ".deb package" in result["notes"][0] and "left as it is" in result["notes"][0]
user_copy = aplot.linux_desktop_paths()["program"]
assert version_of(user_copy) == "9.9.0"
print("a .deb is never written over: the update is installed for the user ok")

# ...and the package's start hands over to that newer copy (and only then)
assert aplot.newer_installed_copy(packaged, "linux") == user_copy
assert aplot.newer_installed_copy(own, "linux") is None, "a file of one's own is never passed over"
os.environ["APLOT_NEWEST"] = "1"
assert aplot.newer_installed_copy(packaged, "linux") is None, "no second hand-over"
del os.environ["APLOT_NEWEST"]
version_file(user_copy, "1.0.0")                 # a newer package came later
assert aplot.newer_installed_copy(packaged, "linux") is None
assert aplot.newer_installed_copy(user_copy, "linux") is None   # (PACKAGE_PROGRAM absent)
print("the package's start goes on with the newer user copy, never with an older one ok")

# -- 3. a flatpak that is not self-contained is told to update the flatpak -------
os.environ["FLATPAK_ID"] = "hu.feti.APlot"
result = aplot.install_update(download, facts, target=own, platform="linux",
                              own_copy=lambda *a: calls.append("own") or None)
del os.environ["FLATPAK_ID"]
assert result["installed"] is False and ".flatpak" in result["notes"][0], result
assert version_of(own) == "1.3.6"
print("a flatpak is updated by flatpak ok")

# -- 4. a self-contained APlot: the update goes to the user's folder ---------------
updated = Path(HOME) / "Library" / "Application Support" / "APlot" / "aplot.py"
os.environ["APLOT_FROZEN"] = "dmg"
os.environ["APLOT_UPDATE_TARGET"] = str(updated)
assert aplot.update_target() == updated
result = aplot.install_update(download, facts, target=aplot.update_target(),
                              platform="darwin")
assert result["installed"] and version_of(updated) == "9.9.0", result
assert result["command"] == [sys.executable], "the application itself starts again"
assert result["backup"] is not None
assert aplot.package_kind() == "dmg" and aplot.is_installed_copy()
assert aplot.newer_installed_copy() is None and aplot.separate_installation() == []
settings = aplot.Config(os.path.join(HOME, "settings.json"))
settings.set("update_state", "updated_from", "1.0.0")
info = aplot.after_update(settings, platform="darwin")
assert info is not None and not info["notes"], "nothing outside the application to renew"
del os.environ["APLOT_FROZEN"], os.environ["APLOT_UPDATE_TARGET"]
print("a self-contained APlot writes its update into the user's folder ok")

# its bootstrap starts the newer of the two programs
spec = importlib.util.spec_from_file_location(
    "aplot_frozen", os.path.join(HERE, "..", "packaging", "frozen", "aplot_frozen.py"))
if spec is not None and os.path.exists(spec.origin):
    boot = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(boot)
    bundled = version_file(Path(tempfile.mkdtemp()) / "aplot.py", "1.3.6")
    assert boot.version_of(bundled) == (1, 3, 6) and boot.version_of("/nowhere") == ()
    ran = []
    boot.bundled_program = lambda: bundled
    boot.updated_program = lambda: updated
    boot.runpy.run_path = lambda path, run_name=None: ran.append(Path(path))
    saved_argv = sys.argv
    sys.argv = ["APlot", str(updated), "graph.aplt"]
    boot.main()
    assert ran[-1] == updated and sys.argv == ["APlot", "graph.aplt"], (ran, sys.argv)
    assert os.environ["APLOT_UPDATE_TARGET"] == str(updated)
    version_file(updated, "1.0.0")
    boot.main()
    assert ran[-1] == bundled, "an older update does not hold back a newer package"
    sys.argv = saved_argv
    for name in ("APLOT_FROZEN", "APLOT_UPDATE_TARGET"):
        os.environ.pop(name, None)
    print("the bootstrap of a self-contained APlot starts the newer program ok")
else:
    print("(packaging/frozen is not beside the tests: the bootstrap is left out)")

# -- 5. the Linux install written into a package tree ------------------------------
tree = Path(tempfile.mkdtemp())
written = aplot.install_linux_desktop(system=True, prefix="/usr", program=own,
                                      python="/usr/bin/python3", refresh=False,
                                      destdir=tree, package="rpm")
assert all(str(path).startswith(str(tree)) for path in written), "only into the tree"
assert (tree / "usr/share/aplot/aplot.py").read_bytes() == own.read_bytes()
assert (tree / "usr/share/aplot/PACKAGED").read_text().strip() == "rpm"
launcher = (tree / "usr/bin/aplot").read_text()
assert "/usr/bin/python3 /usr/share/aplot/aplot.py" in launcher and str(tree) not in launcher
entry = (tree / "usr/share/applications/aplot.desktop").read_text()
assert "Exec=/usr/bin/python3 /usr/share/aplot/aplot.py %f" in entry, entry
assert "/usr/bin/aplot-thumbnailer" in (tree / "usr/share/thumbnailers/aplot.thumbnailer").read_text()
assert not (tree / "usr/share/nautilus").exists()
print("the files of a .deb/.rpm are written into the tree with their /usr paths ok")

# -- 6. APlot.app built on another system: icons and the launcher -----------------
data = aplot.icns_bytes(aplot.app_icon_png)
assert data[:4] == b"icns" and struct.unpack(">I", data[4:8])[0] == len(data)
kinds, position = [], 8
while position < len(data):
    kind, size = data[position:position + 4], struct.unpack(">I", data[position + 4:position + 8])[0]
    assert data[position + 8:position + 16] == b"\x89PNG\r\n\x1a\n"
    kinds.append(kind.decode())
    position += size
assert {"ic07", "ic08", "ic09", "ic10", "icp4"} <= set(kinds), kinds
apps = Path(tempfile.mkdtemp())
bundle = aplot.make_macos_app(apps, program=own, platform="darwin", python="", package="dmg")
resources = bundle / "Contents" / "Resources"
assert (resources / "APlot.icns").read_bytes()[:4] == b"icns", "a real .icns, not a PNG"
assert (resources / aplot.PACKAGE_MARK).read_text().strip() == "dmg"
assert aplot.package_kind(resources / "aplot.py") == "dmg"
launcher = bundle / "Contents" / "MacOS" / "APlot"
text = launcher.read_text()
for place in ("/opt/anaconda3/bin/python3", "$HOME/miniforge3/bin/python3",
              "/Library/Frameworks/Python.framework/Versions/Current/bin/python3",
              "/opt/homebrew/bin/python3"):
    assert place in text, place
assert " /usr/bin/python3" not in text, "Apple's own python3 is never tried"
# the launcher at work, with pretend Pythons in a pretend home folder
home = Path(tempfile.mkdtemp())
log = home / "log.txt"


def pretend_python(path, answer):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f'#!/bin/sh\nif [ "$1" = "-c" ]; then exit {answer}; fi\n'
                    f'echo "$0 $*" > "{log}"\n')
    path.chmod(0o755)


def start(*arguments):
    if log.exists():
        log.unlink()
    done = subprocess.run(["sh", str(launcher), *arguments], env={
        "HOME": str(home), "PATH": "/usr/bin:/bin"}, capture_output=True, text=True,
        timeout=60)
    return done.returncode, (log.read_text().strip() if log.exists() else "")


pretend_python(home / "anaconda3" / "bin" / "python3", 1)        # no packages
pretend_python(home / "miniforge3" / "bin" / "python3", 0)       # everything
code, line = start("/Users/me/my graph.aplt")
assert line.startswith(str(home / "miniforge3" / "bin" / "python3")), line
assert line.endswith("Contents/Resources/aplot.py /Users/me/my graph.aplt"), line
(home / "miniforge3" / "bin" / "python3").unlink()
code, line = start()
assert line.startswith(str(home / "anaconda3")), "none has the packages: the first one"
shutil.rmtree(home / "anaconda3")
code, line = start()
if not any(os.path.exists(one) for one in ("/usr/local/bin/python3", "/opt/homebrew/bin/python3",
                                           "/opt/anaconda3/bin/python3")):
    assert code == 1 and line == "", "no Python at all: the message, and nothing started"
print("APlot.app: real .icns icons, and a launcher that finds conda and the others ok")

print("ALL OK")
