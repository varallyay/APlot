#!/bin/sh
# Run every headless test in this folder at one screen size.
# The keyboard tests (test_sheet_keys, test_shortcuts, test_plot_keys,
# test_regression_scroll) type and click for real when xdotool is
# installed, with openbox as the window manager when that is installed
# too; without them the keys are handed to Tk (APLOT_TEST_KEYS=tk does
# that on purpose).
cd "$(dirname "$0")"
geom="${1:-1280x800}"
fails=""
for f in test_*.py; do
  out=$(xvfb-run -a --server-args="-screen 0 ${geom}x24" python3.12 -u "$f" 2>&1)
  if printf '%s' "$out" | grep -q '^ALL OK$'; then
    printf '%-28s ok\n' "$f"
  else
    printf '%-28s FAILED\n' "$f"; printf '%s\n' "$out" | tail -25
    fails="$fails $f"
  fi
done
if [ -n "$fails" ]; then echo "FAILED:$fails"; else echo "EVERY TEST OK ($geom)"; fi
