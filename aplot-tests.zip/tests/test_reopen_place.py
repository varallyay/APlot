"""Headless test (1.2.1): a graph opens again with its window at the saved
size and place, scrolled to the same point of the page, at the same zoom -
and it appears there at once, without jumping."""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: False
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=6, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


settle()
x = np.linspace(0.0, 10.0, 30)
app.table.set_dataframe(pd.DataFrame({"x": x, "y": np.sin(x) + 3.0}), check_all=True)
settle()
plot = app.open_plot("line")
settle()
left, top, right, bottom = aplot.usable_screen(root)
plot.geometry(f"820x600+{left + 120}+{top + 30}")
settle()
plot.set_zoom(2.0)
settle()
plot.view.xview_moveto(0.30)
plot.view.yview_moveto(0.25)
settle()
saved_geometry = plot.geometry()
centre = plot.view_center()
assert centre is not None and 0.0 < centre[0] < 1.0 and 0.0 < centre[1] < 1.0, centre
state = plot.to_state()
assert state["view"]["center"] == centre and state["geometry"] == saved_geometry
path = os.path.join(HOME, "graph.aplt")
assert app.save_project(path) == path
assert aplot.read_project_document(path)["plots"][0]["view"]["center"] == centre
print(f"saved: {saved_geometry}, the middle of the window at {centre} of the page ok")


def watch_maps():
    shown = []
    real = aplot.PlotWindow.__init__

    def spy(self, *args, **kwargs):
        real(self, *args, **kwargs)
        self.bind("<Map>", lambda e, w=self: shown.append(
            (w.winfo_width(), w.winfo_height())) if e.widget is w else None,
            add="+")

    aplot.PlotWindow.__init__ = spy
    return shown, real


# -- 1. opened again: size, place, zoom and scrolling -------------------------
shown, real = watch_maps()
assert app.load_project(path) is True
settle(20)
aplot.PlotWindow.__init__ = real
again = app.open_windows()[0]
assert again.geometry() == saved_geometry, (again.geometry(), saved_geometry)
assert abs(again.zoom - 2.0) < 1e-9
got = again.view_center()
assert abs(got[0] - centre[0]) < 0.003 and abs(got[1] - centre[1]) < 0.003, (got, centre)
assert shown and shown[0] == (820, 600), f"it appears at its size at once: {shown}"
print(f"opened again: {again.geometry()}, scrolled to {got}, zoom {again.zoom} ok")

# -- 2. scrolling or moving the window is not an edit ------------------------
assert app.is_modified() is False
again.view.xview_moveto(0.0)
again.geometry(f"+{left + 10}+{top + 10}")
settle()
assert app.is_modified() is False, "moving and scrolling are not edits"
print("moving and scrolling the window does not make the graph 'edited' ok")

# -- 3. a smaller window (another screen): the same point in the middle --------
document = aplot.read_project_document(path)
document["plots"][0]["geometry"] = f"600x420+{left + 40}+{top + 40}"
small = os.path.join(HOME, "small.aplt")
aplot.write_project_file(small, document)
assert app.load_project(small) is True
settle(20)
window = app.open_windows()[0]
assert window.winfo_width() == 600 and window.winfo_height() == 420
got = window.view_center()
assert abs(got[0] - centre[0]) < 0.003 and abs(got[1] - centre[1]) < 0.003, (got, centre)
print("in a smaller window the same point of the page is in the middle ok")

# -- 4. Undo does not move or scroll the window ------------------------------
window.view.xview_moveto(0.0)
window.view.yview_moveto(0.0)
window.geometry(f"700x500+{left + 60}+{top + 50}")
settle()
before_view = (window.view.xview()[0], window.view.yview()[0])
with window.changed("the title"):
    window.ax.set_title("A new title")
window.draw()
settle()
app.undo_step()
settle(10)
assert window.ax.get_title() != "A new title"
assert window.winfo_width() == 700 and window.winfo_height() == 500
assert (window.view.xview()[0], window.view.yview()[0]) == before_view
print("Undo leaves the window where it is and as it is scrolled ok")

# -- 5. a file without the view (an older APlot) opens as before ---------------
del document["plots"][0]["view"]
old = os.path.join(HOME, "old.aplt")
aplot.write_project_file(old, document)
assert app.load_project(old) is True
settle(20)
assert app.open_windows()[0].winfo_ismapped()
print("an older file without the saved view opens as before ok")

assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.2.1")
root.destroy()
print("ALL OK")
