"""Headless test (1.3.5): every curve drawn with markers gets a marker of its
own - circle, square, triangle, diamond... - and they are used again from
the start when there are more curves than kinds.  The marker of the
settings is the first; a curve whose marker was chosen, and a saved graph,
keep theirs; the setting switched off gives every curve the same one.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def sheet(curves, points=12):
    x = np.linspace(0.0, 10.0, points)
    frame = {"x": x}
    for index in range(curves):
        frame[f"c{index + 1}"] = np.sin(x + index) + index
    app.table.set_dataframe(pd.DataFrame(frame), check_all=True)
    settle(2)


def markers(plot):
    return [plot.series[name].get_marker() for name in plot.series]


def close_all():
    for window in app.open_windows():
        window.destroy()
    settle(2)


# -- 1. three curves: circle, square, triangle ---------------------------------
assert aplot.DEFAULTS["plot"]["marker_cycle"] is True
sheet(3)
plot = app.open_plot("line_symbol")
settle(6)
assert markers(plot) == ["o", "s", "^"], markers(plot)
legend = [handle.get_marker() for handle in plot.ax.get_legend_handles_labels()[0]]
assert legend[:3] == ["o", "s", "^"], legend
print("three curves: circle, square, triangle ok")
close_all()

# -- 2. more curves than kinds: used again from the start ------------------------
kinds = len(aplot.MARKER_SEQUENCE)
assert len(set(aplot.MARKER_SEQUENCE)) == kinds
assert all(code in [row[1] for row in aplot.MARKERS] for code in aplot.MARKER_SEQUENCE)
sheet(kinds + 2)
plot = app.open_plot("line_symbol")
settle(6)
got = markers(plot)
assert got[:kinds] == list(aplot.MARKER_SEQUENCE), got
assert got[kinds:] == list(aplot.MARKER_SEQUENCE[:2]), got
print(f"{kinds + 2} curves: all {kinds} kinds, then circle and square again ok")
close_all()

# -- 3. symbols only, error bars; a plain line has none --------------------------
sheet(3)
for style in ("scatter",):
    plot = app.open_plot(style)
    settle(6)
    assert markers(plot) == ["o", "s", "^"], (style, markers(plot))
    close_all()
sheet(4)                                 # x, mean, sd, mean, sd
plot = app.open_plot("errorbar")
settle(6)
assert markers(plot) == ["o", "s"], markers(plot)
close_all()
sheet(3)
plot = app.open_plot("line")
settle(6)
assert all(str(code).lower() == "none" for code in markers(plot)), markers(plot)
print("symbols only and error bars too; a plain line keeps no marker ok")

# a curve switched to markers in its window gets a kind of its own
plot.series_style["c1"] = "line_symbol"
plot.series["c1"].set_marker("o")
plot.series["c2"].set_marker("s")
dialog = plot.open_series_dialog(plot.series["c3"])
settle(6)
assert dialog.default_marker() == "Triangle up", dialog.default_marker()
dialog.close()
close_all()
print("a curve given markers in its window gets the next free kind ok")

# -- 4. a new column: a free kind; the chosen markers stay -------------------------
sheet(3)
plot = app.open_plot("line_symbol")
settle(6)
plot.series["c2"].set_marker("D")                 # chosen by the user
frame = app.table.df.copy()
frame["c4"] = np.linspace(0.0, 10.0, len(frame)) / 3.0
app.table.set_dataframe(frame, check_all=True)
settle(2)
app.update_plot()
settle(6)
assert markers(plot) == ["o", "D", "^", "s"], markers(plot)
print("a curve added later takes a kind no curve has; chosen ones stay ok")

# -- 5. a saved graph keeps its markers ----------------------------------------------
for line in plot.series.values():
    line.set_marker("o")                          # as an older APlot drew it
graph = os.path.join(HOME, "same.aplt")
assert app.save_project(graph) == graph
close_all()
assert app.load_project(graph) is True
settle(8)
again = app.open_windows()[0]
assert markers(again) == ["o", "o", "o", "o"], markers(again)
print("a saved graph opens with the markers it was saved with ok")
close_all()

# -- 6. the settings: the first marker, and the switch ----------------------------
settings.set("plot", "marker", "Square")
sheet(3)
plot = app.open_plot("line_symbol")
settle(6)
assert markers(plot) == ["s", "^", "D"], markers(plot)
close_all()
settings.set("plot", "marker", "Point")           # not in the sequence: first
plot = app.open_plot("line_symbol")
settle(6)
assert markers(plot) == [".", "o", "s"], markers(plot)
close_all()
settings.set("plot", "marker", "Circle")
settings.set("plot", "marker_cycle", False)
plot = app.open_plot("line_symbol")
settle(6)
assert markers(plot) == ["o", "o", "o"], markers(plot)
close_all()
settings.set("plot", "marker_cycle", True)
dialog = app.open_settings()
settle(2)
labels = []


def walk(widget):
    for child in widget.winfo_children():
        try:
            labels.append(str(child.cget("text")))
        except tk.TclError:
            pass
        walk(child)


walk(dialog)
assert "A different marker for every curve" in labels
dialog.destroy()
print("the first marker comes from the settings; switched off, all the same ok")

assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.3.5")
assert "| 1.3.5 | 2026-10-15 |" in aplot.DOCUMENTATION
root.destroy()
print("ALL OK")
