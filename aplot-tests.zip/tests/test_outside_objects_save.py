"""Headless test (1.7.1): whatever stands outside the plot area is on the
saved picture whole, in every direction, and the picture really shows it -
the box is not only inside the cut-out, its text and its handle are painted.

The cases come from the figures of a simulation report drawn with APlot:
  * six legend boxes stacked to the RIGHT of the graph (a long legend that
    does not fit over the curves), to the LEFT of the Y axis label and
    UNDER the X axis label, side by side,
  * symbols with fitted lines whose label starts with "_" (no box for them),
    the symbol boxes outside on the right,
  * a colour surface with an outline drawn as a one-level contour on top:
    its colour bar with a label beside the graph, then laid down above it,
  * a graph saved and opened again keeps its outside boxes, and the
    exported matplotlib program unclips every one of them.
Before 1.7.1 the legend boxes outside the plot area were cut off in the
saved and the copied picture although the screen showed them."""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import matplotlib
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: False
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))
DPI = 100


def settle(times=6, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def close_all():
    for window in app.open_windows():
        window.destroy()
    settle(2)


def diagram(frame, style="line"):
    close_all()
    app.table.set_dataframe(frame, check_all=True)
    settle(2)
    plot = app.open_plot(style)
    settle(8)
    assert plot is not None
    return plot


def place_legends(plot, where):
    """where(index) -> (x, y, loc): the boxes moved as the user drags them."""
    for index, column in enumerate(plot.legends):
        x, y, loc = where(index)
        plot.legend_state[column]["pos"] = (x, y)
        plot.legend_state[column]["loc"] = loc
    plot.refresh_legend()
    plot.canvas.draw()
    settle(2)


def picture(plot, name):
    """The saved picture and where a point of the screen lands on it."""
    path = plot.figure_image(os.path.join(HOME, name), dpi=DPI)
    image = matplotlib.image.imread(path)
    renderer = plot.canvas.get_renderer()
    cut = plot.fig.get_tightbbox(renderer)              # in inches
    pad = aplot.EXPORT_PAD
    scale = DPI / plot.fig.dpi

    def to_pixels(box):
        left = (box.x0 / plot.fig.dpi - (cut.x0 - pad)) * DPI
        top = (cut.y1 + pad - box.y1 / plot.fig.dpi) * DPI
        return left, top, left + box.width * scale, top + box.height * scale
    return image, to_pixels, renderer


def painted(image, left, top, right, bottom):
    """Is anything drawn (not paper, not see-through) in this rectangle?"""
    rows = slice(max(0, int(round(top))), int(round(bottom)))
    cols = slice(max(0, int(round(left))), int(round(right)))
    part = image[rows, cols]
    if part.size == 0:
        return False
    alpha = part[..., 3] if part.shape[-1] == 4 else np.ones(part.shape[:2])
    ink = (alpha > 0.1) & (part[..., :3].min(axis=-1) < 0.8)
    return bool(ink.any())


def whole_on_picture(image, to_pixels, box, what):
    """The box lies on the picture, and each of its halves has ink: a box cut
    off on any side would lose the ink of that side."""
    left, top, right, bottom = to_pixels(box)
    height, width = image.shape[:2]
    assert left >= -2 and top >= -2 and right <= width + 2 and bottom <= height + 2, \
        (what, (left, top, right, bottom), (width, height))
    mid_x, mid_y = (left + right) / 2.0, (top + bottom) / 2.0
    for half, rect in (("left", (left, top, mid_x, bottom)),
                       ("right", (mid_x, top, right, bottom)),
                       ("upper", (left, top, right, mid_y)),
                       ("lower", (left, mid_y, right, bottom))):
        assert painted(image, *rect), (what, half, rect)


def check_legends(plot, name, outside):
    """outside(box, axes_box) is True where the box is meant to stand."""
    image, to_pixels, renderer = picture(plot, name)
    axes_box = plot.ax.get_window_extent(renderer)
    assert plot.legends, "no legend box at all"
    for column, legend in plot.legends.items():
        box = legend.get_window_extent(renderer)
        assert outside(box, axes_box), (column, box, axes_box)
        assert not legend.get_clip_on(), column
        whole_on_picture(image, to_pixels, box, column)
    return image


settle()
step = aplot.LEGEND_STACK_STEP
lam = np.linspace(1260.0, 1360.0, 201)

# -- 1. six boxes stacked on the right, two on the left, three underneath -------
spectra = pd.DataFrame({
    "Wavelength (nm)": lam,
    "TE$_0$": 0.27 + 0.34 * (lam - 1260) / 100,
    "TE$_1$": 0.45 - 0.41 * (lam - 1260) / 100,
    "TM$_1$": 0.17 + 0.09 * np.sin((lam - 1260) / 60),
    "TE$_2$+TM$_0$+TE$_3$": 0.03 * np.exp(-(lam - 1260) / 30),
    "sum of modes": np.full_like(lam, 0.90),
    "plane (Poynting)": np.full_like(lam, 0.91)})
plot = diagram(spectra)
assert len(plot.legends) == 6, list(plot.legends)
place_legends(plot, lambda i: (1.03, 1.0 - i * step, "upper left"))
check_legends(plot, "right.png", lambda box, ax: box.x0 > ax.x1)
print("six boxes stacked on the right of the graph are painted whole ok")

place_legends(plot, lambda i: (-0.30, 1.0 - i * step, "upper right"))
check_legends(plot, "left.png", lambda box, ax: box.x1 < ax.x0)
print("the boxes left of the Y axis and its label are painted whole ok")

place_legends(plot, lambda i: (0.34 * (i % 3), -0.30 - (i // 3) * step, "upper left"))
check_legends(plot, "below.png", lambda box, ax: box.y1 < ax.y0)
print("the boxes under the X axis and its label are painted whole ok")

# a graph saved and opened again: the boxes are still out there, whole
place_legends(plot, lambda i: (1.03, 1.0 - i * step, "upper left"))
graph = os.path.join(HOME, "right.aplt")
assert app.save_project(graph, quiet=True)
places = {column: tuple(plot.legend_state[column]["pos"]) for column in plot.legends}
assert app.load_project(graph)
settle(10)
plot = app.open_windows()[-1]
for column, pos in places.items():
    assert np.allclose(plot.legend_state[column]["pos"], pos), (column, pos)
check_legends(plot, "reopened.png", lambda box, ax: box.x0 > ax.x1)
print("saved and opened again, the boxes are still outside and whole ok")

# the exported program unclips every box, not only the first one
script = plot.to_script()
assert script.count("legend.set_clip_on(False)") == len(plot.legends), \
    script.count("legend.set_clip_on(False)")
print("the exported program unclips all six boxes ok")

# -- 2. symbols with fitted lines that have no box --------------------------------
length = np.arange(0.0, 221.0, 10.0)
frame = {"Section length L (um)": length}
style = {}
for index, (slope, offset) in enumerate(((0.41, -43.5), (1.97, -34.5), (1.57, 9.0))):
    points = np.full_like(length, np.nan)
    for at in (50.0, 100.0, 150.0, 200.0):
        points[length == at] = slope * at + offset
    frame[f"pair {index}"] = points
    frame[f"pair {index} fit"] = slope * length + offset
    style[f"pair {index}"] = dict(plot_style="scatter", marker="os^"[index],
                                  linestyle="None")
    style[f"pair {index} fit"] = dict(linestyle="--", label="_nolegend_",
                                      auto_label=False)
plot = diagram(pd.DataFrame(frame))
state = plot.to_state()
for curve in state["series"]:
    curve.update(style.get(curve["column"], {}))
plot.apply_state(state, place=False)
settle(6)
assert sorted(plot.legends) == ["pair 0", "pair 1", "pair 2"], sorted(plot.legends)
place_legends(plot, lambda i: (1.03, 1.0 - i * step, "upper left"))
check_legends(plot, "symbols.png", lambda box, ax: box.x0 > ax.x1)
print("only the symbols have boxes, outside on the right and whole ok")

# -- 3. a colour surface, an outline contour on it, and its colour bar ------------
y = np.linspace(-0.8, 1.6, 61)
z = np.linspace(-0.8, 0.8, 41)
Y, Z = np.meshgrid(y, z)
field = (np.exp(-((Y - 0.0) / 0.3) ** 2 - ((Z - 0.12) / 0.15) ** 2)
         - np.exp(-((Y - 0.8) / 0.3) ** 2 - ((Z - 0.12) / 0.15) ** 2))
core = ((np.abs(Y - 0.4) <= 0.75) & (Z >= 0.0) & (Z <= 0.25)).astype(float)
plot = diagram(pd.DataFrame({"y (um)": Y.ravel(), "z (um)": Z.ravel(),
                             "field": field.ravel(), "z2": Z.ravel(),
                             "n": core.ravel()}), style="pcolor")
state = plot.to_state()
surface, outline = state["series"][0], state["series"][1]
surface["surface_cfg"].update(cmap="coolwarm", vmin=-1.0, vmax=1.0,
                              shading="smooth", bar_label="Re $E_y$ (norm.)")
outline["plot_style"] = "contour"
outline["surface_cfg"].update(levels=1, vmin=0.0, vmax=1.0, onecolor=True,
                              color="#000000", colorbar=False)
state["legend"]["visible"] = False
plot.apply_state(state, place=False)
settle(8)
column = surface["column"]
assert column in plot.hist2d_bars, list(plot.hist2d_bars)
assert outline["column"] not in plot.hist2d_bars, "the outline has no colour bar"


def check_bar(name, outside):
    plot.canvas.draw()
    image, to_pixels, renderer = picture(plot, name)
    bar = plot.hist2d_bars[column]
    axes_box = plot.ax.get_window_extent(renderer)
    whole = bar.ax.get_tightbbox(renderer)              # numbers and label too
    assert outside(bar.ax.get_window_extent(renderer), axes_box), name
    whole_on_picture(image, to_pixels, whole, name)
    label = bar.ax.yaxis.label if not bar.aplot_flat else bar.ax.xaxis.label
    assert label.get_text() == "Re $E_y$ (norm.)", label.get_text()
    left, top, right, bottom = to_pixels(label.get_window_extent(renderer))
    assert painted(image, left, top, right, bottom), (name, "label")


check_bar("bar_right.png", lambda box, ax: box.x0 >= ax.x1 - 1)
print("the colour bar beside the graph, numbers and label, is whole ok")

assert plot.set_color_bar_box(column, (0.0, 1.12, 1.0, 0.07))
settle(4)
assert plot.hist2d_bars[column].aplot_flat, "a wide bar lies down"
check_bar("bar_above.png", lambda box, ax: box.y0 >= ax.y1 - 1)
print("the colour bar laid down above the graph is whole ok")

root.destroy()
print("ALL OK")
