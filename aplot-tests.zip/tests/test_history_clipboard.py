"""Test (1.6.6): the version history is a file of its own (VERSION_HISTORY.md,
the same text as aplot.VERSION_HISTORY) and no longer a part of the README;
Help > Version history shows it.  A diagram copied on Windows goes to the
clipboard as a PNG and as a bitmap laid on white - never on grey."""
import io, os, struct, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import tkinter as tk
import numpy as np
import aplot
from matplotlib.figure import Figure

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None

# -- 0. the version ---------------------------------------------------------
assert aplot.version_tuple(aplot.APP_VERSION) >= (1, 6, 6), aplot.APP_VERSION

# -- 1. the history: its own file, the same text in the program ---------------
folder = os.path.dirname(os.path.abspath(aplot.__file__))
readme = open(os.path.join(folder, "README.md"), encoding="utf-8").read()
history = open(os.path.join(folder, "VERSION_HISTORY.md"), encoding="utf-8").read()
assert readme == aplot.DOCUMENTATION, "README.md and the built-in text differ"
assert history == aplot.VERSION_HISTORY, "VERSION_HISTORY.md and the built-in text differ"
assert aplot.version_history(readme) == [], "the README has no history any more"
assert "VERSION_HISTORY.md" in readme
rows = aplot.version_history(history)
assert rows[0][:2] == (aplot.APP_VERSION, aplot.APP_VERSION_DATE), rows[0][:2]
assert rows[-1][0] == "1.0.0" and len(rows) >= 34
assert [r[0] for r in rows] == [r[0] for r in aplot.version_history(aplot.VERSION_HISTORY)]
assert "| 1.6.6 | 2026-11-23 |" in aplot.VERSION_HISTORY
# newest first in the file itself, so that its first bytes hold the news
found = [line.split(" | ")[0][2:] for line in history.splitlines()
         if line.startswith("| 1.") or line.startswith("| 2.")]
assert found == sorted(found, key=aplot.version_tuple, reverse=True)
assert aplot.load_version_history() == history
print("the version history is VERSION_HISTORY.md, the README has none ok")

# -- 2. the picture for the clipboard of Windows ----------------------------
for width in (2.0, 2.01):                 # an odd width: rows are padded
    fig = Figure(figsize=(width, 1.5))
    fig.set_facecolor("none")
    ax = fig.add_subplot()
    ax.set_facecolor("none")
    ax.plot([0, 1], [0, 1], color="red", lw=3)
    path = os.path.join(HOME, "figure.png")
    fig.savefig(path, dpi=97, transparent=True, bbox_inches="tight")
    source = np.asarray(aplot.Image.open(path).convert("RGBA"))
    assert source[0, 0, 3] == 0, "the page is see-through"
    white = aplot.png_pixels_on_white(path)
    assert white.shape == source.shape[:2] + (3,) and white.dtype == np.uint8
    assert tuple(white[0, 0]) == (255, 255, 255), "see-through is white"
    solid = source[..., 3] == 255
    assert (white[solid] == source[solid][:, :3]).all(), "colours are kept"
    dib = aplot.dib_from_pixels(white, dpi=300)
    bitmap = b"BM" + struct.pack("<IHHI", 14 + len(dib), 0, 0, 54) + dib
    back = aplot.Image.open(io.BytesIO(bitmap))
    back.load()
    assert back.size == (source.shape[1], source.shape[0]), back.size
    assert (np.asarray(back.convert("RGB")) == white).all()
    assert round(back.info["dpi"][0]) == 300
print("the bitmap for Windows is laid on white, PNG colours kept ok")

if sys.platform.startswith("win"):
    assert aplot.copy_png_to_clipboard(path, dpi=300)
    from PIL import ImageGrab
    grabbed = ImageGrab.grabclipboard()
    assert grabbed is not None, "nothing on the clipboard"
    assert grabbed.size == (source.shape[1], source.shape[0]), grabbed.size
    corner = grabbed.convert("RGBA").getpixel((0, 0))
    assert corner[3] == 0 or corner[:3] == (255, 255, 255), corner
    print("Windows: the clipboard holds the picture, not grey ok")

# -- 3. Help > Version history ----------------------------------------------
root = tk.Tk()
root.geometry("900x500+0+0")
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))
for _ in range(4):
    root.update()
    time.sleep(0.02)
window = app.show_version_history()
root.update()
assert window.title() == f"{aplot.APP_NAME} version history"
assert f"| {aplot.APP_VERSION} |" in window.text.get("1.0", "end")
assert app.show_version_history() is window, "one window, brought forward"
window.destroy()
root.destroy()
print("Help > Version history shows it ok")
print("ALL OK")
