"""Headless test (1.6.8): renaming a sheet of a group drawn together ("Plot
with previous tab") keeps its curves.  A curve of that sheet is called
"Y1 (<sheet name>)"; the diagram used to take the new name for a new curve,
so the legend text written for it was lost and it was drawn in the next
colour of the cycle - the next sheet then got a colour further on still."""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import pandas as pd
import matplotlib
from matplotlib.colors import to_hex
import aplot

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)

root = tk.Tk()
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=6, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def sheet(shift):
    xs = [0.0, 1.0, 2.0, 3.0]
    return pd.DataFrame({"X": xs, "Y1": [x + shift for x in xs]})


def glued_sheet(shift):
    app.add_sheet()
    settle(2)
    app.table.set_dataframe(sheet(shift), check_all=True)
    app.table.plot_with_previous_var.set(True)
    settle(2)


def look(plot):
    """{curve: (legend text, colour, marker)}"""
    return {name: (line.get_label(), to_hex(line.get_color()),
                   line.get_marker())
            for name, line in plot.series.items()}


settle()
app.table.set_dataframe(sheet(0), check_all=True)
settle(2)
glued_sheet(1)
app.notebook.select(0)
settle(2)
plot = app.open_plot("line_symbol")
settle(8)
assert list(plot.series) == ["Y1", "Y1 (Data 2)"], list(plot.series)
plot.series["Y1"].set_label("50 um")
plot.series["Y1 (Data 2)"].set_label("70 um")
plot.refresh_legend()
before = look(plot)

app.set_tab_name(1, "20")
settle(4)
assert list(plot.series) == ["Y1", "Y1 (20)"], list(plot.series)
after = look(plot)
assert after["Y1"] == before["Y1"], (after, before)
assert after["Y1 (20)"] == before["Y1 (Data 2)"], (after, before)
print("a renamed sheet keeps the legend text, colour and marker ok")

glued_sheet(2)
app.notebook.select(0)
settle(2)
app.update_plot()
settle(6)
assert list(plot.series) == ["Y1", "Y1 (20)", "Y1 (Data 3)"], list(plot.series)
colours = [look(plot)[name][1] for name in plot.series]
assert len(set(colours)) == 3, colours
cycle = [to_hex(c) for c in
         matplotlib.rcParams["axes.prop_cycle"].by_key()["color"]]
assert colours == cycle[:3], f"{colours} is not the start of {cycle[:3]}"
print("the next sheet gets the next colour of the cycle ok")

# sheet 2 takes the name of sheet 3: the curve of sheet 3 must give way
# ("Y1 (Data 3)" -> "Y1 (Data 3 2)") while the one of sheet 2 moves in
plot.series["Y1 (Data 3)"].set_label("100 um")
before = look(plot)
app.set_tab_name(1, "Data 3")
settle(4)
assert list(plot.series) == ["Y1", "Y1 (Data 3)", "Y1 (Data 3 2)"], \
    list(plot.series)
after = look(plot)
assert after["Y1 (Data 3)"] == before["Y1 (20)"], (after, before)
assert after["Y1 (Data 3 2)"] == before["Y1 (Data 3)"], (after, before)
print("curves that trade names keep their own look ok")

root.destroy()
print("ALL OK")
