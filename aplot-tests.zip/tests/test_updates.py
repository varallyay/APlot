"""Headless test (1.2.0, 1.3.0): looking for a new version and installing it.

GitHub is played by a small web server on this computer, and the program
that is "updated" is a copy in a temporary folder - never aplot.py itself.
"""
import functools, http.server, json, os, re, shutil, stat, sys, tempfile
import threading, time, zipfile

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import tkinter as tk
import aplot

said = []
aplot.messagebox.showinfo = lambda *a, **k: said.append(("info",) + a)
aplot.messagebox.showwarning = lambda *a, **k: said.append(("warning",) + a)
aplot.messagebox.showerror = lambda *a, **k: said.append(("error",) + a)
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.UPDATE_FOLDER = aplot.Path(HOME) / "updates"
aplot.UPDATE_BACKUPS = aplot.Path(HOME) / "backups"

# -- 0. versions ------------------------------------------------------------
assert aplot.version_tuple("1.10.2") == (1, 10, 2) and aplot.version_tuple("v2.0") == (2, 0)
assert aplot.version_tuple("") == () and aplot.version_tuple("1.x") == ()
assert aplot.is_newer("1.10.0", "1.9.9") and not aplot.is_newer("1.2.0", "1.2.0")
assert not aplot.is_newer("", "1.0.0") and aplot.is_newer("1.0.1", "")
assert aplot.APP_VERSION == "1.2.0" or aplot.is_newer(aplot.APP_VERSION, "1.2.0")
facts = aplot.program_facts(open(aplot.__file__, encoding="utf-8").read(40000))
assert facts["version"] == aplot.APP_VERSION and facts["quicklook"] == aplot.QUICKLOOK_VERSION
rows = aplot.version_history(aplot.DOCUMENTATION, "1.1.0")
assert [row[0] for row in rows][:2] == [aplot.APP_VERSION, "1.1.2"] or rows[0][0] == aplot.APP_VERSION
assert all(aplot.is_newer(row[0], "1.1.0") for row in rows)
print("versions are compared as numbers, the history is read ok")

# -- 1. a pretend GitHub ----------------------------------------------------
source_text = open(aplot.__file__, encoding="utf-8").read()


def release(folder, version, quicklook=None, broken=False):
    """A folder that looks like the repository, with `version` in it."""
    os.makedirs(folder, exist_ok=True)
    text = re.sub(r'^APP_VERSION = "[^"]*"', f'APP_VERSION = "{version}"',
                  source_text, count=1, flags=re.M)
    if quicklook:
        text = re.sub(r'^QUICKLOOK_VERSION = "[^"]*"',
                      f'QUICKLOOK_VERSION = "{quicklook}"', text, count=1, flags=re.M)
    if broken:
        text += "\ndef broken(:\n"
    with open(os.path.join(folder, "aplot.py"), "w", encoding="utf-8") as handle:
        handle.write(text)
    readme = ("# APlot\n\n### Version history\n\n| Version | Date | What changed |\n"
              "| --- | --- | --- |\n"
              f"| {version} | 2099-01-01 | A pretend release for the test. |\n"
              f"| {aplot.APP_VERSION} | {aplot.APP_VERSION_DATE} | This one. |\n")
    with open(os.path.join(folder, "README.md"), "w", encoding="utf-8") as handle:
        handle.write(readme)
    with zipfile.ZipFile(os.path.join(folder, "APlotQuickLook.zip"), "w") as archive:
        archive.writestr("APlotQuickLook/build.sh", "echo build\n")
        archive.writestr("APlotQuickLook/install.sh", "echo install\n")
    return folder


SITE = tempfile.mkdtemp()
release(os.path.join(SITE, "new"), "9.9.0", quicklook="9.0.0")
release(os.path.join(SITE, "same"), aplot.APP_VERSION)
release(os.path.join(SITE, "broken"), "9.9.1", broken=True)
handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=SITE)
handler.log_message = lambda *a, **k: None
http.server.SimpleHTTPRequestHandler.log_message = lambda *a, **k: None
server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
server.handle_error = lambda *a, **k: None    # a check reads only the start
threading.Thread(target=server.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{server.server_address[1]}/"
NEW, SAME, BROKEN = BASE + "new/", BASE + "same/", BASE + "broken/"
NOWHERE = "http://127.0.0.1:9/"            # nothing answers there

facts = aplot.check_for_update(source=NEW)
assert facts["newer"] is True and facts["version"] == "9.9.0", facts
assert facts["quicklook"] == "9.0.0" and facts["date"] == aplot.APP_VERSION_DATE
same = aplot.check_for_update(source=SAME)
assert same["newer"] is False and same["version"] == aplot.APP_VERSION
try:
    aplot.check_for_update(source=NOWHERE)
    raise AssertionError("no answer must be an UpdateError")
except aplot.UpdateError:
    pass
print("the version on GitHub is read from the first part of the file ok")

# -- 2. downloading: only a real APlot of that version is accepted ------------
program = aplot.download_update(facts, source=NEW)
assert program.exists() and aplot.program_facts(program.read_text())["version"] == "9.9.0"
for bad_source, bad_facts in ((BROKEN, {"version": "9.9.1"}),       # damaged
                              (NEW, {"version": "9.9.5"})):        # not that one
    try:
        aplot.download_update(bad_facts, source=bad_source)
        raise AssertionError(f"{bad_source} must be refused")
    except aplot.UpdateError:
        pass
print("the download is checked: it compiles, it is APlot, it is that version ok")

# -- 3. installing over a copy of the program --------------------------------
place = tempfile.mkdtemp()
target = aplot.Path(place) / "aplot.py"
shutil.copy2(aplot.__file__, target)
os.chmod(target, 0o755)
(aplot.Path(place) / "README.md").write_text("old documentation")
old_text = target.read_text()
result = aplot.install_update(program, facts, target=target, source=NEW,
                              platform="linux")
assert result["installed"] is True, result
assert aplot.program_facts(target.read_text())["version"] == "9.9.0"
assert stat.S_IMODE(os.stat(target).st_mode) == 0o755, "it can still be run"
assert result["backup"].read_text() == old_text
assert result["backup"].name == f"aplot-{aplot.APP_VERSION}.py"
assert "pretend release" in (aplot.Path(place) / "README.md").read_text()
assert result["command"] == [sys.executable, str(target)]
assert not (aplot.Path(place) / "APlotQuickLook").exists(), "Linux needs no Quick Look"
assert not [n for n in os.listdir(place) if n.startswith(".aplot-update-")]
print("installed: the new program in place, the old one kept, the README too ok")

# on a Mac, new Quick Look extensions are unpacked (beside the download,
# not into the program's folder - that may be inside APlot.app) and explained
shutil.copy2(aplot.__file__, target)
result = aplot.install_update(program, facts, target=target, source=NEW,
                              platform="darwin")
assert (program.parent / "APlotQuickLook" / "build.sh").exists()
assert not (aplot.Path(place) / "APlotQuickLook").exists()
assert any("sh build.sh" in note and "sh install.sh" in note for note in result["notes"])
# ...not when they have not changed
shutil.copy2(aplot.__file__, target)
same_ql = dict(facts, quicklook=aplot.QUICKLOOK_VERSION)
result = aplot.install_update(program, same_ql, target=target, source=NEW,
                              platform="darwin")
assert not any("Quick Look" in note for note in result["notes"]), result["notes"]
# a git working copy is never written over (one git cannot pull: the new
# version is installed for the user instead - see test_install_copy.py)
os.makedirs(os.path.join(place, ".git"))
shutil.copy2(aplot.__file__, target)
asked = []
result = aplot.install_update(program, facts, target=target, source=NEW,
                              platform="linux",
                              own_copy=lambda *a: asked.append(a) or None)
assert result["installed"] is False and asked, result
assert "git working copy" in result["notes"][0] and str(program) in result["notes"][0]
assert aplot.program_facts(target.read_text())["version"] == aplot.APP_VERSION
shutil.rmtree(os.path.join(place, ".git"))
print("Quick Look on a Mac only when it is new; a git copy is not written over ok")

# -- 4. the menu command and the weekly look ---------------------------------
root = tk.Tk()
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)


def settle(times=3, pause=0.02):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def wait():
    end = time.time() + 30
    while app._update_busy and time.time() < end:
        settle(1, 0.05)
    assert not app._update_busy, "the look on GitHub ended"
    settle(3)


def offers():
    return [w for w in root.winfo_children() if isinstance(w, aplot.UpdateDialog)]


settle(4)
menu = root.nametowidget(str(root.cget("menu"))).nametowidget("help")
labels = [menu.entrycget(i, "label") for i in range(menu.index("end") + 1)
          if menu.type(i) == "command"]
assert "Check for updates..." in labels, labels
dialog = app.open_settings()
settle(2)
tabs = [dialog.nametowidget(t) for t in dialog.winfo_children()]
notebooks = []


def walk(widget):
    for child in widget.winfo_children():
        if child.winfo_class() == "TNotebook":
            notebooks.append(child)
        walk(child)


walk(dialog)
assert notebooks and "Updates" in [notebooks[0].tab(t, "text") for t in notebooks[0].tabs()]
dialog.destroy()

aplot.UPDATE_SOURCE = SAME
said.clear()
assert app.check_for_updates() is True
wait()
assert said and said[-1][0] == "info" and "is up to date" in said[-1][2], said
assert float(settings.get("update_state", "last_check")) > time.time() - 60
aplot.UPDATE_SOURCE = NOWHERE
said.clear()
app.check_for_updates()
wait()
assert said and said[-1][0] == "warning" and aplot.UPDATE_PAGE in said[-1][2], said
print("Help > Check for updates says up to date, or that GitHub was not reached ok")

aplot.UPDATE_SOURCE = NEW
said.clear()
app.check_for_updates()
wait()
dialogs = offers()
assert len(dialogs) == 1 and not said, said
assert "9.9.0" in dialogs[0].news.get("1.0", "end"), "what is new is shown"
dialogs[0].close()
print("a newer version is offered with what is new ok")

# the weekly look at the start: not within the week, and never the skipped one
settings.set("update_state", "last_check", time.time() - 2 * 86400)
assert app.auto_check_for_updates() is False
settings.set("update_state", "last_check", time.time() - 8 * 86400)
assert app.auto_check_for_updates() is True
wait()
assert len(offers()) == 1
offers()[0]._skip()
settle(2)
assert settings.get("update_state", "skipped") == "9.9.0"
settings.set("update_state", "last_check", 0.0)
said.clear()
app.auto_check_for_updates()
wait()
assert offers() == [] and said == [], "a skipped version is not offered again"
settings.set("updates", "auto_check", False)
settings.set("update_state", "last_check", 0.0)
assert app.auto_check_for_updates() is False
settings.set("updates", "auto_check", True)
print("once a week at the start, silent when up to date, a skipped version stays skipped ok")

# -- 5. updating from the window: install, remember, start again ---------------
shutil.copy2(aplot.__file__, target)
aplot.update_target = lambda: target
started = []
aplot.restart_program = lambda command, root=None: started.append(command)
graph = os.path.join(HOME, "graph.aplt")
assert app.save_project(graph) == graph
said.clear()
assert app.perform_update(facts) is True
wait()
assert started, said
assert started[0][:2] == [sys.executable, str(target)]
assert started[0][-1] == graph, "the graph is opened again"
assert aplot.program_facts(target.read_text())["version"] == "9.9.0"
assert settings.get("update_state", "updated_from") == aplot.APP_VERSION
assert said and said[-1][0] == "info" and "starts again" in said[-1][2]
assert f"installed in {aplot.short_path(target)}" in said[-1][2], said[-1][2]
print("Update now installs it, remembers it and starts the program again ok")

# the first start of the new version: what is new, and the files outside
settings.set("update_state", "updated_from", "1.1.0")
settings.set("update_state", "notes", "Something to be told.")
said.clear()
info = app._greet_new_version()
assert info and info["from"] == "1.1.0"
# ... in a window of its own with a scroll bar, never taller than the main
# window however much there is to tell
news = app._news_window
assert isinstance(news, aplot.UpdateNewsDialog) and not said, said
labels = [str(w.cget("text")) for w in news.body.winfo_children()
          if w.winfo_class() == "TLabel"]
assert any(f"from 1.1.0 to {aplot.APP_VERSION}" in one for one in labels), labels
text = news.news.get("1.0", "end")
assert "What is new" in text and "Something to be told." in text
assert str(news.news.cget("state")) == "disabled"
for _ in range(30):
    root.update()
    time.sleep(0.02)
assert news.winfo_ismapped()
assert news.winfo_height() <= root.winfo_height(), (
    news.winfo_height(), root.winfo_height())
first, last = news.news.yview()
assert first == 0.0 and last < 1.0, "the long history is scrolled"
news.news.yview_moveto(1.0)
root.update()
assert news.news.yview()[1] == 1.0
news.close()
assert settings.get("update_state", "updated_from") == ""
assert app._greet_new_version() is None, "only once"
# on Linux the desktop files are written again by the new version
aplot.install_linux_desktop(refresh=False)
desktop = aplot.linux_desktop_paths()["desktop"]
os.utime(desktop, (0, 0))
settings.set("update_state", "updated_from", "1.1.0")
info = aplot.after_update(settings, platform="linux")
assert any("desktop integration" in note for note in info["notes"]), info
assert desktop.stat().st_mtime > 0
print("the new version says what is new and refreshes the desktop files ok")

# -- 6. the command line --------------------------------------------------------
shutil.copy2(aplot.__file__, target)
lines = []
assert aplot.command_line_update(install=False, out=lines.append) == 0
assert "9.9.0" in lines[0] and "--update" in lines[-1]
lines.clear()
assert aplot.command_line_update(install=True, out=lines.append) == 0, lines
assert aplot.program_facts(target.read_text())["version"] == "9.9.0"
aplot.UPDATE_SOURCE = SAME
lines.clear()
assert aplot.command_line_update(out=lines.append) == 0 and "up to date" in lines[0]
print("--check-update and --update ok")

root.destroy()
server.shutdown()
print("ALL OK")
