"""Test (1.6.6): an update is finished only when APlot has closed, and a new
version that was not put in place is told at the next start - never again
the old version started as if nothing had happened (what FSP Viewer 0.2.7
did on Windows: its helper stood in the program folder, so the folder could
not be replaced).

* the restart: the new APlot starts in the home folder (not in the folder an
  update replaces) and afresh (PYINSTALLER_RESET_ENVIRONMENT); a helper is
  started beside APlot, which ends;
* macOS (run only there): the APlot.app of a real disk image is copied beside
  the old one, and put in its place by the helper only after the process
  that runs APlot has ended; the new one is started with the graph; when the
  swap fails, the old one is put back, started, and the reason is told;
* the next start: the reason the helper wrote is told once; the very program
  that was updated, starting as the old version, says the update did not
  take place - another copy of APlot of that older version does not.
"""
import os, plistlib, shutil, subprocess, sys, tempfile, time
from pathlib import Path

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import tkinter as tk
import aplot

for name in ("APLOT_FROZEN", "APLOT_VERSIONS", "APLOT_UPDATE_TARGET"):
    os.environ.pop(name, None)
aplot.UPDATE_FAILED = Path(HOME) / ".aplot" / "update-failed.txt"
said = []
aplot.messagebox.showinfo = lambda *a, **k: said.append(("info",) + a)
aplot.messagebox.showwarning = lambda *a, **k: said.append(("warning",) + a)
aplot.messagebox.showerror = lambda *a, **k: said.append(("error",) + a)

# -- 1. the restart ------------------------------------------------------------
calls = []


class Stop(Exception):
    pass


def fake_exit(code):
    calls.append(("exit", code))
    raise Stop


saved = (aplot.subprocess.Popen, aplot.os._exit, aplot.os.execve, aplot.os.chdir,
         sys.platform)
aplot.subprocess.Popen = lambda command, **options: calls.append(("popen", command, options))
aplot.os._exit = fake_exit
aplot.os.execve = lambda path, args, env: calls.append(("execve", path, args, env))
aplot.os.chdir = lambda where: calls.append(("chdir", where))
try:
    os.environ["_PYI_ARCHIVE_FILE"] = "/old/APlot"          # as the bootloader left it
    aplot.restart_program(["/usr/lib/aplot/APlot", "/g/x.aplt"], env={"A": "1"})
    kind, path, args, env = calls[-1]
    assert calls[-2] == ("chdir", HOME), calls
    assert (kind, path, args) == ("execve", "/usr/lib/aplot/APlot", ["/usr/lib/aplot/APlot", "/g/x.aplt"])
    assert env["PYINSTALLER_RESET_ENVIRONMENT"] == "1" and env["A"] == "1"
    calls.clear()
    try:
        aplot.restart_program(["/bin/sh", "/u/install-update.sh"], detached=True)
    except Stop:
        pass
    assert calls[0][0] == "popen" and calls[0][2]["start_new_session"] and calls[0][2]["cwd"] == HOME
    assert calls[-1] == ("exit", 0), "a helper waits for this process: it ends"
    sys.platform = "win32"
    for detached, hidden in ((True, 0x08000000), (False, 0)):
        calls.clear()
        try:
            aplot.restart_program('cmd.exe /d /s /c ""C:\\u\\install-update.cmd""'
                                  if detached else ["C:\\v\\APlot.exe"],
                                  env={"APLOT_UPDATE_OPEN": "C:\\g\\x.aplt"},
                                  detached=detached)
        except Stop:
            pass
        options = calls[0][2]
        assert options["creationflags"] == hidden and options["cwd"] == HOME, options
        assert options["env"]["PYINSTALLER_RESET_ENVIRONMENT"] == "1"
        assert options["env"]["APLOT_UPDATE_OPEN"] == "C:\\g\\x.aplt"
        assert calls[-1] == ("exit", 0)
finally:
    (aplot.subprocess.Popen, aplot.os._exit, aplot.os.execve, aplot.os.chdir,
     sys.platform) = saved
    os.environ.pop("_PYI_ARCHIVE_FILE", None)
print("the restart: in the home folder, afresh, a helper beside it ok")


# -- 2. macOS: the APlot.app is replaced when APlot has closed -------------------
def bundle(folder, tag):
    """A small APlot.app whose program writes `tag` and its arguments."""
    app = Path(folder) / "APlot.app"
    (app / "Contents" / "MacOS").mkdir(parents=True)
    with open(app / "Contents" / "Info.plist", "wb") as handle:
        plistlib.dump({"CFBundleExecutable": "APlot", "CFBundleName": "APlot",
                       "CFBundleIdentifier": f"test.aplot.update.{os.getpid()}",
                       "CFBundlePackageType": "APPL", "CFBundleVersion": tag,
                       "CFBundleShortVersionString": tag}, handle)
    program = app / "Contents" / "MacOS" / "APlot"
    program.write_text(f'#!/bin/sh\necho "{tag} $*" >> "{STARTED}"\n')
    program.chmod(0o755)
    (app / "Contents" / f"VERSION-{tag}").write_text(tag)
    return app


def waiting(seconds):
    return subprocess.Popen([sys.executable, "-c", f"import time; time.sleep({seconds})"])


def until(test, seconds=40):
    deadline = time.time() + seconds
    while time.time() < deadline:
        if test():
            return True
        time.sleep(0.25)
    return False


if sys.platform == "darwin":
    work = Path(tempfile.mkdtemp(prefix="aplot update ")).resolve()
    STARTED = work / "started.txt"
    image_folder = work / "image"
    image_folder.mkdir()
    bundle(image_folder, "new")
    image = work / "downloads" / "APlot-9.0.0-macOS-arm64.dmg"
    image.parent.mkdir()
    subprocess.run(["/usr/bin/hdiutil", "create", "-quiet", "-srcfolder", str(image_folder),
                    "-volname", "APlot", "-format", "UDZO", str(image)], check=True)
    apps = work / "Applications"
    apps.mkdir()
    graph = work / "my graph.aplt"
    graph.write_text("graph")

    def update(break_it=False):
        shutil.rmtree(apps / "APlot.app", ignore_errors=True)
        old = bundle(apps, "old")
        running = waiting(4)            # stands in for the APlot that runs
        result = aplot.install_release(image, {"version": "9.0.0"}, kind="dmg",
                                       platform="darwin", pid=running.pid,
                                       executable=old / "Contents" / "MacOS" / "APlot")
        assert result["installed"] and result["detached"] and result["where"] == old, result
        staged = apps / ".APlot.app.new-9.0.0"
        assert (staged / "Contents" / "VERSION-new").is_file(), "copied beside it"
        if break_it:
            shutil.rmtree(staged)       # the swap cannot be done
        subprocess.Popen(result["command"] + [str(graph)], start_new_session=True,
                         env=dict(os.environ, **aplot.RELAUNCH_ENV), cwd=HOME,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(1.5)
        assert (old / "Contents" / "VERSION-old").is_file(), \
            "replaced while APlot was still running"
        running.wait()
        return old

    STARTED.write_text("")
    old = update()
    assert until(lambda: "new" in STARTED.read_text()), STARTED.read_text()
    assert (old / "Contents" / "VERSION-new").is_file(), "the new APlot.app is in place"
    assert sorted(p.name for p in apps.iterdir()) == ["APlot.app"], list(apps.iterdir())
    assert STARTED.read_text().strip() == f"new {graph}", STARTED.read_text()
    assert not aplot.UPDATE_FAILED.exists()
    print("macOS: APlot.app replaced after APlot closed, the new one started with the graph ok")

    STARTED.write_text("")
    old = update(break_it=True)
    assert until(lambda: "old" in STARTED.read_text()), STARTED.read_text()
    assert (old / "Contents" / "VERSION-old").is_file(), "the old one is put back"
    assert sorted(p.name for p in apps.iterdir()) == ["APlot.app"], list(apps.iterdir())
    text = aplot.UPDATE_FAILED.read_text()
    assert "9.0.0 could not be put in the place of" in text and str(old) in text, text
    print("macOS: a swap that fails puts the old one back, starts it and says why ok")
    aplot.UPDATE_FAILED.unlink()
    # the small test bundles leave Launch Services again
    subprocess.run([aplot.LSREGISTER, "-u", str(apps / "APlot.app")], capture_output=True)
    shutil.rmtree(work, ignore_errors=True)
else:
    print("(not a Mac: the APlot.app swap is not tried)")

# -- 3. the next start tells an update that did not take place ---------------------
root = tk.Tk()
root.withdraw()
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)
for _ in range(4):
    root.update()


def updated(where, to="9.9.9"):
    for key, value in (("updated_from", aplot.APP_VERSION), ("updated_to", to),
                       ("updated_where", str(where)), ("notes", "x")):
        settings.set("update_state", key, value)


# the helper said why
aplot.UPDATE_FAILED.parent.mkdir(parents=True, exist_ok=True)
aplot.UPDATE_FAILED.write_text("\ufeffAPlot 9.9.9 could not be installed: code 1603.")
updated(aplot.update_target())
said.clear()
info = app._greet_new_version()
assert info and info["failed"] == "9.9.9", info
assert said == [("warning", "Update", "APlot 9.9.9 could not be installed: code 1603.")], said
assert not aplot.UPDATE_FAILED.exists(), "told once"
assert settings.get("update_state", "updated_from") == "" and settings.get("update_state", "updated_to") == ""
said.clear()
assert app._greet_new_version() is None and not said, "only once"
# nothing was written, but this very program is still the old version
updated(aplot.update_target())
info = app._greet_new_version()
assert info["failed"] == "9.9.9" and said and "was not put in place" in said[-1][2], said
# its folder, as for a self-contained APlot (where = the folder of APlot.exe)
updated(Path(aplot.update_target()).parent)
said.clear()
assert app._greet_new_version()["failed"] == "9.9.9" and said
# another copy of APlot (an older one elsewhere): left to the new version
updated(Path(HOME) / "elsewhere" / "aplot.py")
said.clear()
assert app._greet_new_version() is None and not said
assert settings.get("update_state", "updated_to") == "9.9.9", "kept for the new version"
# the new version itself: what is new, as always
settings.set("update_state", "updated_from", "1.0.0")
info = app._greet_new_version()
assert info and not info.get("failed") and info["from"] == "1.0.0"
assert settings.get("update_state", "updated_to") == ""
app._news_window.close()
root.destroy()
print("the next start: why it failed, or that it did not take place - once ok")
print("ALL OK")
