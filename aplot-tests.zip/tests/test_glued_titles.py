"""Headless test (1.6.7): sheets drawn together ("Plot with previous tab")
whose first row holds the column titles - words in the X column - are still
matched up and sorted on X as numbers, so no curve runs back and forth
across the diagram, and the empty rows at the end of the sheets are not
paired with each other (a thousand times a thousand rows)."""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)

root = tk.Tk()
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=6, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


settle()

assert aplot.App.has_numbers(pd.Series(["x_um", -180.0, "", 25.0])) is True
assert aplot.App.has_numbers(pd.Series(["Mon", "Tue", ""])) is False
print("a title among numbers still makes a numeric X column ok")

EMPTY = 200                  # the unused rows below the data of each sheet


def sheet(xs, ys, x_title, y_title):
    x = [x_title] + list(xs) + [""] * EMPTY
    y = [y_title] + list(ys) + [""] * EMPTY
    return pd.DataFrame({"X": x, "Y1": y})


first_x = [-180.0, -179.0, -75.0027, -35.0, 0.014, 25.008, 75.0027, 180.0, 180.0]
second_x = [-195.0, -194.0, -74.992, -50.0, -0.0, 25.0, 74.992, 195.0, 195.0]
first_y = [1.0, 1.0, 0.999, 0.9996, 1.0016, 1.0015, 0.9926, 0.9921, 0.9923]
second_y = [1.0, 1.0, 0.9999, 0.9987, 0.9984, 0.9982, 0.9894, 0.00016, 0.00016]

app.table.set_dataframe(sheet(first_x, first_y, "x_um", "P (20 um)"),
                        check_all=True)
settle(2)
app.add_sheet()
settle(2)
app.table.set_dataframe(sheet(second_x, second_y, "x_um", "P"), check_all=True)
app.table.plot_with_previous_var.set(True)
settle(2)
app.notebook.select(0)
settle(2)
assert len(app.tab_chain(0)) == 2, "the two sheets are drawn together"

merged = app.plot_data(index=0)
assert len(merged) == len(first_x) + len(second_x), \
    f"{len(merged)} rows: titles and empty rows must not be merged in"
keys = merged.iloc[:, 0].to_numpy(dtype=float)
assert np.all(np.diff(keys) >= 0), f"X sorted as numbers: {keys}"
print("titles and empty rows are left out, X is sorted as numbers ok")

plot = app.open_plot("line_symbol")
settle(8)
assert plot is not None
for column, xs, ys in (("Y1", first_x, first_y),
                       ("Y1 (Data 2)", second_x, second_y)):
    names = list(plot.series)
    assert column in names, (column, names)
    line_x, line_y = (np.asarray(one, float)
                      for one in plot.series[column].get_data())
    shown = np.isfinite(line_x) & np.isfinite(line_y)
    assert np.all(np.diff(line_x[shown]) >= 0), \
        f"{column}: the curve goes back and forth: {line_x[shown]}"
    assert np.allclose(line_x[shown], sorted(xs)), (column, line_x[shown])
    assert np.allclose(line_y[shown], ys), (column, line_y[shown])
print("both curves are drawn from left to right, every point in place ok")

root.destroy()
print("ALL OK")
