"""Headless test (1.8.0): the two File menu commands of the scripting
interface, used the way a user uses them.

  * Export as APlot script... writes the whole graph as a Python program
    that draws it with `aplot.Graph`; run on its own it writes the .aplt
    file and the PDF, and the graph it makes is the graph on the screen -
    the same picture, pixel for pixel - also with other numbers put in.
  * Batch export from template... draws other data files with the look of
    the graph on the screen (or of a graph file): one picture each, a file
    that does not fit is reported and the others are still drawn; the
    graph on the screen is not touched.
Both commands are in the File menu of the sheet and of every diagram."""
import os, sys, subprocess, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import matplotlib
import aplot

said = []
aplot.messagebox.showinfo = lambda *a, **k: said.append(("info",) + a[:2])
aplot.messagebox.showwarning = lambda *a, **k: said.append(("warning",) + a[:2])
aplot.messagebox.showerror = lambda *a, **k: said.append(("error",) + a[:2])
aplot.messagebox.askyesno = lambda *a, **k: False
aplot.messagebox.askyesnocancel = lambda *a, **k: False

WORK = tempfile.mkdtemp()
os.chdir(WORK)
root = tk.Tk()
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=6, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def same_picture(first, second):
    a, b = matplotlib.image.imread(first), matplotlib.image.imread(second)
    return a.shape == b.shape and np.array_equal(a, b)


def file_menu_labels(window):
    bar = window.nametowidget(window.cget("menu"))
    for index in range(bar.index("end") + 1):
        if bar.type(index) == "cascade" and bar.entrycget(index, "label") == "File":
            menu = bar.nametowidget(bar.entrycget(index, "menu"))
            return [menu.entrycget(i, "label") for i in range(menu.index("end") + 1)
                    if menu.type(i) == "command"]
    raise AssertionError("no File menu")


settle()
lam = np.linspace(1260.0, 1360.0, 101)


def spectra(scale):
    return pd.DataFrame({"Wavelength (nm)": lam,
                         "TE0": scale * (0.3 + 0.003 * (lam - 1260)),
                         "TM1": scale * (0.2 + 0.05 * np.sin(lam / 9.0))})


app.table.set_dataframe(spectra(1.0), check_all=True)
settle(2)
plot = app.open_plot("line")
settle(8)
state = plot.to_state()
state["title"]["text"] = "Spectra"
state["series"][1].update(color="#000000", linestyle="--", linewidth=2.5)
state["axes"]["y"].update(label="Power fraction", auto=False, min=0.0, max=1.0)
plot.apply_state(state, place=False)
settle(4)
plot.figure_image(os.path.join(WORK, "screen.png"), dpi=100)

# -- the File menu ---------------------------------------------------------------------
for window in (root, plot):
    labels = file_menu_labels(window)
    assert "Export as APlot script..." in labels, labels
    assert "Batch export from template..." in labels, labels
    at = labels.index("Export as matplotlib script...")
    assert labels[at + 1:at + 3] == ["Export as APlot script...",
                                     "Batch export from template..."], labels
print("both commands are in the File menu of the sheet and of the diagram ok")

# -- Export as APlot script... ---------------------------------------------------------
program = os.path.join(WORK, "spectra_aplot.py")
aplot.filedialog.asksaveasfilename = lambda **k: program
assert app.export_aplot_script(plot) == program
assert said[-1][0] == "info" and "python3 spectra_aplot.py" in said[-1][2], said[-1]
source = open(program, encoding="utf-8").read()
compile(source, program, "exec")
for piece in ("aplot.Graph.from_document(LOOK)", "graph.set_data(pd.DataFrame({",
              "d.title('Spectra')", "d.axis('y', label='Power fraction', range=(0, 1)",
              "d.curve('TM1', label='TM1', legend=True, color='#000000', "
              "linestyle='--', width=2.5"):
    assert piece in source, piece
done = subprocess.run([sys.executable, program], capture_output=True, text=True,
                      cwd=WORK, env=dict(os.environ, HOME=HOME), timeout=300)
assert done.returncode == 0, done.stderr
assert done.stdout.split() == [os.path.join(WORK, "spectra.pdf")], done.stdout
assert os.path.exists(os.path.join(WORK, "spectra.aplt"))
check = ("import sys; sys.path.insert(0, %r); import aplot; "
         "aplot.Graph.open(%r).export(%r, dpi=100)")
subprocess.run([sys.executable, "-c", check % (os.path.dirname(aplot.__file__),
                os.path.join(WORK, "spectra.aplt"), os.path.join(WORK, "program.png"))],
               check=True, capture_output=True, env=dict(os.environ, HOME=HOME))
assert same_picture(os.path.join(WORK, "screen.png"), os.path.join(WORK, "program.png")), \
    "the program draws the graph on the screen"
print("the program draws the graph of the screen, pixel for pixel ok")

# the program with other numbers: the look stays
edited = source.replace("graph.set_data(pd.DataFrame({",
                        "graph.set_data(pd.read_csv('other.csv'), sheet=0)\n"
                        "_unused = (pd.DataFrame({", 1)
edited = edited.replace("}), sheet=0)\n", "}), 0)\n", 1)
open(os.path.join(WORK, "edited_aplot.py"), "w", encoding="utf-8").write(edited)
spectra(0.5).to_csv(os.path.join(WORK, "other.csv"), index=False)
done = subprocess.run([sys.executable, "edited_aplot.py"], capture_output=True,
                      text=True, cwd=WORK, env=dict(os.environ, HOME=HOME), timeout=300)
assert done.returncode == 0, done.stderr
made = aplot.read_project_document(os.path.join(WORK, "spectra.aplt"))
rows = made["tabs"][0]["rows"]
assert abs(rows[0][1] - 0.15) < 1e-9, rows[0]                    # 0.5 * 0.3
curve = {c["column"]: c for c in made["plots"][0]["series"]}["TM1"]
assert curve["color"] == "#000000" and curve["linewidth"] == 2.5
print("the program run with other numbers keeps the look ok")

said.clear()

# -- Batch export from template... ---------------------------------------------------
for name, scale in (("run_a", 1.0), ("run_b", 0.5)):
    spectra(scale).to_csv(os.path.join(WORK, f"{name}.csv"), index=False)
spectra(1.0).drop(columns=["TM1"]).to_csv(os.path.join(WORK, "short.csv"), index=False)
before = app.project_document()
dialog = app.batch_export(plot)
settle(4)
assert str(dialog.transient()) == str(plot), "it stays in front of its diagram"
assert dialog.run() is False and "data files" in said[-1][2], said  # nothing chosen yet
dialog.add_files([os.path.join(WORK, f) for f in ("run_a.csv", "short.csv", "run_b.csv")])
dialog.add_files([os.path.join(WORK, "run_a.csv")])         # not twice
assert dialog.files.size() == 3
dialog.out_folder.set(os.path.join(WORK, "batch"))
dialog.format.set("png")
dialog.dpi.set("80")
dialog.save_graphs.set(True)
assert dialog.run() is True
assert dialog.run() is False, "one run at a time"
start = time.time()
while dialog.result is None and time.time() - start < 300:
    settle(2, 0.05)
assert dialog.result == 1, (dialog.result, dialog.lines)          # short.csv fails
folder = os.path.join(WORK, "batch")
assert sorted(os.listdir(folder)) == ["run_a.aplt", "run_a.png", "run_b.aplt",
                                      "run_b.png"], os.listdir(folder)
problems = [one for one in dialog.lines if one.startswith("aplot.py:")]
assert len(problems) == 1 and "short.csv" in problems[0] and "'TM1'" in problems[0], problems
assert "4 file(s) written, 1 problem(s)" in dialog.status.get(), dialog.status.get()
assert dialog.log.get("1.0", "end").count("\n") >= 5
made = aplot.read_project_document(os.path.join(folder, "run_b.aplt"))
assert abs(made["tabs"][0]["rows"][0][1] - 0.15) < 1e-9
assert made["plots"][0]["title"]["text"] == "Spectra"
after = app.project_document()
assert after["tabs"] == before["tabs"], "the graph on the screen is not touched"
assert dialog.scratch is None, "the copy of the graph it drew from is gone"
print("other data drawn with the look of the graph, a misfit reported ok")

# the look of a graph file, and leaving out a missing curve
dialog.template_kind.set("file")
dialog.template_file.set(os.path.join(WORK, "spectra.aplt"))
dialog.files.delete(0, "end")
dialog.add_files([os.path.join(WORK, "short.csv")])
dialog.allow_missing.set(True)
dialog.save_graphs.set(False)
dialog.out_folder.set(os.path.join(WORK, "batch2"))
dialog.result = None
assert dialog.run() is True
start = time.time()
while dialog.result is None and time.time() - start < 300:
    settle(2, 0.05)
assert dialog.result == 0, (dialog.result, dialog.lines)
assert os.listdir(os.path.join(WORK, "batch2")) == ["short.png"]
print("the look of a graph file, a missing curve left out on request ok")

dialog.destroy()
root.destroy()
print("ALL OK")
