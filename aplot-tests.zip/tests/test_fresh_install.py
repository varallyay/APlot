"""Headless test (1.3.2): APlot with the packages a fresh install brings.

`pip install pandas` brings pandas 3 now, whose columns of text take
nothing but text; APlot asks for the plain columns pandas 2 had, so that a
number can be typed (or calculated) into an empty column.  Opening an Excel
file names it in the title without an error.  Runs with pandas 2 as well.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

errors = []
aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: errors.append(a)
aplot.messagebox.showerror = lambda *a, **k: errors.append(a)
print(f"pandas {pd.__version__}, numpy {np.__version__}")

# -- 1. a column of empty cells takes numbers ---------------------------------
blank = pd.DataFrame({"X": [""] * 4, "Y1": [""] * 4})
assert all(dtype == object for dtype in blank.dtypes), blank.dtypes
blank.iat[0, 1] = 1.5
assert blank.iat[0, 1] == 1.5
print("a column of empty cells is a plain column: it takes numbers ok")

root = tk.Tk()
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=4):
    for _ in range(times):
        root.update()
        time.sleep(0.02)
        root.update()


settle()
table = app.table
for row in range(5):
    table._set_cell_value(row, 0, float(row + 1))
table._set_cell_value(0, 2, "a note")
table.cell_formulas[(1, 2)] = "=A2*10"
table.recalculate_all()
settle()
assert float(table.df.iat[1, 2]) == 20.0

# -- 2. Column Math writes its numbers into an empty column -----------------
dialog = aplot.ColumnMathDialog(root, table)
settle(2)
dialog.target_var.set(str(table.df.columns[1]))
dialog.expr_var.set("A * 3")
dialog.dynamic_var.set(False)
dialog.apply()
settle(2)
assert not errors, errors
assert [float(v) for v in table.df.iloc[:5, 1]] == [3.0, 6.0, 9.0, 12.0, 15.0]
assert table.tree.set("4", str(table.df.columns[1])) == "15"
print("Column Math fills an empty column with numbers ok")

# -- 3. an Excel file opens and names itself in the title --------------------
try:
    import openpyxl  # noqa: F401
except ImportError:
    print("openpyxl is not installed here: the Excel part is left out")
else:
    workbook = os.path.join(HOME, "data.xlsx")
    with pd.ExcelWriter(workbook, engine="openpyxl") as writer:
        pd.DataFrame({"t": np.arange(6.0), "v": np.arange(6.0) ** 2}).to_excel(
            writer, sheet_name="first", index=False)
        pd.DataFrame({"a": [1, 2], "b": [3, 4]}).to_excel(
            writer, sheet_name="second", index=False)
    info = app.load_csv(workbook)
    settle(3)
    assert not errors, errors
    assert info and info["rows"] == 6 and info["columns"] == 2, info
    assert "data.xlsx" in root.title() and "6 rows x 2 columns" in root.title(), root.title()
    assert len(app.tables) == 2
    print(f"the Excel file opens, two sheets, title: {root.title()!r} ok")
hint = aplot.excel_problem(ImportError("Missing optional dependency 'openpyxl'."))
assert "-m pip install openpyxl" in hint, hint
assert aplot.install_command("numpy").endswith(" -m pip install numpy")
assert aplot.missing_packages() == []
print(f"a missing package is named with its command: {aplot.install_command('openpyxl')} ok")
app.set_file_title(os.path.join(HOME, "x.csv"), {"separator": ",", "decimal": "."})
assert "? rows" in root.title()

assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.3.2")
assert "| 1.3.2 | 2026-10-06 |" in aplot.DOCUMENTATION
root.destroy()
print("ALL OK")
