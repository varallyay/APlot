"""Headless test (1.3.1): the light grey net between the cells of a sheet.

It lies on the last pixel of every visible row and column (the row numbers
get the lines of their rows), follows sideways scrolling, a new column width
and a new row height, stays put while the sheet scrolls up and down, lies
under the blue outline - and a click, a drag or the wheel on a line reaches
the table under it.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None

root = tk.Tk()
root.geometry("900x560+0+0")
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


settle(6)
x = np.linspace(0.0, 10.0, 60)
table = app.table
table.set_dataframe(pd.DataFrame({"x": x, "y": np.sin(x), "z": np.cos(x),
                                  "w": x ** 2}), check_all=True)
settle(4)
tree, numbers = table.tree, table.row_tree


def lines(key="tree"):
    """The placed lines: (horizontal [(x, y, w)], vertical [(x, y, h)])."""
    flat, upright = [], []
    for line in table._grid_lines[key]:
        if not line.winfo_manager():
            continue
        info = line.place_info()
        x, y = int(info["x"]), int(info["y"])
        w, h = int(info["width"]), int(info["height"])
        (flat if h == 1 else upright).append((x, y, w if h == 1 else h))
    return sorted(flat, key=lambda one: one[1]), sorted(upright)


# -- 1. one line under every visible row, one beside every column ------------
assert aplot.SHEET_GRID is True
flat, upright = lines()
first = int(round(tree.yview()[0] * len(table.df)))
box = tree.bbox(str(first), "#1")
top, step = box[1], box[3]
assert flat and flat[0][1] == top + step - 1, (flat[:2], box)
assert all(b[1] - a[1] == step for a, b in zip(flat, flat[1:])), "one per row"
assert len(flat) >= (tree.winfo_height() - top) // step
rights = [tree.bbox("0", f"#{i}") for i in range(1, 5)]
expected = [b[0] + b[2] - 1 for b in rights if b[0] + b[2] - 1 < tree.winfo_width()]
assert [one[0] for one in upright] == expected, (upright, expected)
assert all(one[1] == top for one in upright), "from the first row down"
row_flat, _ = lines("rows")
assert len(row_flat) == len(flat)
tree_lines = [l for l in table._grid_lines["tree"] if l.winfo_manager()
              and int(l.place_info()["height"]) == 1]
row_lines = [l for l in table._grid_lines["rows"] if l.winfo_manager()]
assert [l.winfo_rooty() for l in sorted(tree_lines, key=lambda l: l.winfo_y())] == \
    [l.winfo_rooty() for l in sorted(row_lines, key=lambda l: l.winfo_y())], \
    "the lines of the row numbers continue those of the cells"
print(f"{len(flat)} row lines, {len(upright)} column lines, at the cell edges ok")

# -- 2. a light grey from the paper, a lighter one on a dark theme ------------
assert table.table_background().lower() in ("#ffffff", "white", "systemtextbackgroundcolor") \
    or sys.platform == "darwin"
colour = table.grid_color()
red, green, blue = (int(colour[i:i + 2], 16) for i in (1, 3, 5))
assert red == green == blue and 0xc8 <= red <= 0xe4, colour
assert str(table._grid_lines["tree"][0].cget("background")) == colour
real_paper = table.table_background
table.table_background = lambda: "#202020"
dark = table.grid_color()
assert 0x30 <= int(dark[1:3], 16) <= 0x60, dark
table.table_background = real_paper
aplot.SHEET_GRID_COLOR = "#ff0000"
assert table.grid_color() == "#ff0000"
aplot.SHEET_GRID_COLOR = None
print(f"the net is {colour} on white, {dark} on a dark table ok")

# -- 3. under the blue outline and the fill handle ---------------------------
table.select_block(2, 1, 5, 2)
settle(3)
order = [str(one) for one in tree.winfo_children()]
outline = [order.index(str(one)) for one in table._outline]
grid = [order.index(str(one)) for one in table._grid_lines["tree"]]
assert max(grid) < min(outline), "the lines lie below the outline"
assert order.index(str(table._fill_handle)) > max(grid)
print("the lines lie under the outline and the fill handle ok")

# -- 4. up and down: the lines stay; sideways: they move ---------------------
before = dict(table._grid_drawn)
table._yview("scroll", 7, "units")
settle(3)
assert tree.yview()[0] > 0.0
assert table._grid_drawn == before, "rows scroll under lines that stay"
started = time.perf_counter()
for _ in range(200):
    table._draw_gridlines()
took = (time.perf_counter() - started) / 200 * 1000
assert took < 5.0, took
table._yview("moveto", 1.0)
settle(3)
flat_end, _ = lines()
shown = len(table.df) - int(round(tree.yview()[0] * len(table.df)))
assert len(flat_end) <= shown
table._yview("moveto", 0.0)
settle(3)
for name in ("x", "y", "z", "w"):                 # as a user makes them
    tree.column(name, width=300, stretch=False)
table._draw_gridlines()
settle(3)
_, upright = lines()
table._xview("moveto", 0.3)
settle(4)
_, moved = lines()
offset = int(round(tree.xview()[0] * 1200))
assert moved and moved != upright, (upright, moved)
assert all(0 <= one[0] < tree.winfo_width() for one in moved)
assert any(abs((one[0] + offset) - 299) <= 2 or abs((one[0] + offset) - 599) <= 2
           for one in moved), (moved, offset)
table._xview("moveto", 0.0)
settle(3)
print(f"rows scroll under the lines ({took:.2f} ms when nothing moves); "
      "sideways they move with the columns ok")

# -- 5. a new column width, a new row height ----------------------------------
tree.column("y", width=180, stretch=False)
table._draw_gridlines()
_, upright = lines()
assert upright[1][0] == 300 + 180 - 1 + tree.bbox("0", "#1")[0], upright
settings.set("table", "font_size", 16)
table.apply_config()
settle(8)
box = tree.bbox(str(int(round(tree.yview()[0] * len(table.df)))), "#1")
flat, _ = lines()
assert box[3] == int(16 * 2.2) and flat[1][1] - flat[0][1] == box[3], (box, flat[:2])
settings.set("table", "font_size", int(aplot.DEFAULTS["table"]["font_size"]))
table.apply_config()
for name in ("x", "y", "z", "w"):
    tree.column(name, width=110, stretch=True)
settle(8)
print("a wider column and a larger font move the lines with them ok")

# -- 6. a click, a drag and the wheel on a line reach the table ----------------
table._draw_gridlines()
flat, upright = lines()
vertical = [l for l in table._grid_lines["tree"] if l.winfo_manager()
            and int(l.place_info()["width"]) == 1]
vertical.sort(key=lambda l: l.winfo_x())
line_b = vertical[1]                    # the right edge of column B
box_row0 = tree.bbox("0", "#2")
line_b.event_generate("<ButtonPress-1>", x=0, y=box_row0[1] + 5 - line_b.winfo_y())
line_b.event_generate("<ButtonRelease-1>", x=0, y=box_row0[1] + 5 - line_b.winfo_y())
settle(3)
table._commit_edit()
assert table.cursor == (0, 1), table.cursor
horizontal = sorted([l for l in table._grid_lines["tree"] if l.winfo_manager()
                     and int(l.place_info()["height"]) == 1], key=lambda l: l.winfo_y())
under_row3 = horizontal[2]              # the bottom edge of row 3
middle_c = tree.bbox("2", "#3")
point = middle_c[0] + 20
under_row3.event_generate("<ButtonPress-1>", x=point, y=0)
under_row3.event_generate("<ButtonRelease-1>", x=point, y=0)
settle(3)
table._commit_edit()
assert table.cursor == (2, 2), table.cursor
print("a click on a line selects the cell under it ok")

# a drag that passes over a line goes on selecting
start = tree.bbox("0", "#1")
tree.event_generate("<ButtonPress-1>", x=start[0] + 10, y=start[1] + 5)
settle(1)
target = tree.bbox("4", "#2")
line_b.event_generate("<Motion>", x=0, y=target[1] + 5 - line_b.winfo_y(),
                      state=0x100)
settle(2)
tree.event_generate("<ButtonRelease-1>", x=target[0] + 10, y=target[1] + 5)
settle(2)
table._commit_edit()
assert table.block_bounds() == (0, 0, 4, 1), table.block_bounds()
print("a drag over a line goes on selecting the block ok")

# the right button: the menu of the table
seen = []
saved = tree.bind("<Button-3>")
tree.bind("<Button-3>", lambda e: seen.append((e.x, e.y)))
under_row3.event_generate("<ButtonPress-3>", x=point, y=0)
settle(2)
tree.bind("<Button-3>", saved)
assert seen == [(point, under_row3.winfo_y())], seen
# the wheel scrolls the sheet
table._yview("moveto", 0.0)
settle(2)
if sys.platform.startswith("linux") and tk.TkVersion < 9:   # Tk 9: <MouseWheel>
    under_row3.event_generate("<ButtonPress-5>", x=point, y=0)
else:
    under_row3.event_generate("<MouseWheel>", x=point, y=0, delta=-120)
settle(3)
assert tree.yview()[0] > 0.0, "the wheel on a line scrolls"
table._yview("moveto", 0.0)
settle(2)
# the line of a row number selects that row
row_line = sorted([l for l in table._grid_lines["rows"] if l.winfo_manager()],
                  key=lambda l: l.winfo_y())[1]          # under row 2
row_line.event_generate("<ButtonPress-1>", x=10, y=0)
row_line.event_generate("<ButtonRelease-1>", x=10, y=0)
settle(3)
bounds = table.block_bounds()
assert bounds[0] == bounds[2] == 1 and bounds[1] == 0 and bounds[3] == 3, bounds
print("the right button, the wheel and the row numbers work on a line too ok")

# -- 7. the net can be switched off --------------------------------------------
aplot.SHEET_GRID = False
assert table._draw_gridlines() == 0
assert not any(l.winfo_manager() for pool in table._grid_lines.values() for l in pool)
aplot.SHEET_GRID = True
assert table._draw_gridlines() > 0
print("SHEET_GRID = False leaves the sheet plain ok")

assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.3.1")
assert "| 1.3.1 | 2026-10-05 |" in aplot.DOCUMENTATION
root.destroy()
print("ALL OK")
