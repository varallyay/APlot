"""Headless test (1.8.0): the scripting interface, `aplot.Graph`.

A program makes a graph, changes its look, writes the `.aplt` file and the
pictures - with no window shown and without touching the settings of the
person who runs it.  The graph opens in APlot as it was made (the same
picture, pixel for pixel), new numbers keep the look, and every mistake
comes back as an `APlotError` with a readable message instead of a dialog.
The figures are those of a simulation report: spectra with a long legend
outside the plot area, symbols with fitted lines that have no legend, and
a colour surface with an outline contour."""
import os, sys, tempfile, warnings

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import numpy as np
import pandas as pd
import matplotlib
import aplot

OUT = tempfile.mkdtemp()


def out(name):
    return os.path.join(OUT, name)


def same_picture(first, second):
    a, b = matplotlib.image.imread(first), matplotlib.image.imread(second)
    return a.shape == b.shape and np.array_equal(a, b)


def raises(what, function, *args, **kwargs):
    try:
        function(*args, **kwargs)
    except aplot.APlotError as error:
        assert what in str(error), (what, str(error))
        return str(error)
    raise AssertionError(f"no APlotError for {what!r}")


ORIGINAL_DIALOGS = {name: getattr(aplot.messagebox, name)
                    for name in aplot._QuietDialogs.NAMES}

# -- 1. spectra: a graph made, styled, saved and written ------------------------
lam = np.linspace(1260.0, 1360.0, 201)
spectra = pd.DataFrame({
    "Wavelength (nm)": lam,
    "TE$_0$": 0.27 + 0.34 * (lam - 1260) / 100,
    "TE$_1$": 0.45 - 0.41 * (lam - 1260) / 100,
    "TM$_1$": 0.17 + 0.09 * np.sin((lam - 1260) / 60),
    "sum of modes": np.full_like(lam, 0.90)})
graph = aplot.Graph(spectra, style="line")
diagram = graph.diagram()
assert diagram.columns == ["TE$_0$", "TE$_1$", "TM$_1$", "sum of modes"], diagram.columns
(diagram.title("")
 .axis("x", label="Wavelength (nm)", range=(1260, 1360))
 .axis("y", label="Power fraction", range=(0, 1), step=0.2)
 .curve("sum of modes", color="#000000", linestyle="dashed", width=2.5)
 .curve("TE$_0$", label="TE$_0$ mode")
 .legend(position="outside right"))
pictures = graph.export(out("spectra.png"), dpi=100) + graph.export(out("spectra.pdf"))
assert all(os.path.getsize(p) > 1000 for p in pictures), pictures
saved = graph.save(out("spectra"))                 # the ending is added
assert saved.endswith(".aplt") and os.path.exists(saved), saved
print("a graph is made, styled and written as PNG, PDF and .aplt ok")

session = aplot._ScriptSession.current
assert session is not None and session.app.hidden
assert not session.root.winfo_viewable(), "the sheet window is not shown"
for window in session.app.open_windows():
    assert not window.winfo_viewable(), "a diagram window is not shown"
assert not os.path.exists(aplot.CONFIG_FILE), "the user's settings are not touched"
assert session.app.settings.path != aplot.Config().path
for name, function in ORIGINAL_DIALOGS.items():
    assert getattr(aplot.messagebox, name) is function, f"{name} is given back"
print("no window was shown, no setting written, the dialogs are given back ok")

# what was asked is what the file holds
state = aplot.read_project_document(saved)["plots"][0]
curves = {c["column"]: c for c in state["series"]}
assert curves["sum of modes"]["color"] == "#000000"
assert curves["sum of modes"]["linestyle"] == "--"
assert curves["sum of modes"]["linewidth"] == 2.5
assert curves["TE$_0$"]["label"] == "TE$_0$ mode"
assert state["axes"]["x"]["label"] == "Wavelength (nm)"
assert (state["axes"]["y"]["min"], state["axes"]["y"]["max"]) == (0.0, 1.0)
assert state["axes"]["y"]["auto"] is False and state["axes"]["y"]["step"] == 0.2
assert state["title"]["text"] == ""
places = [tuple(c["legend_pos"]) for c in state["series"]]
assert all(x > 1.0 for x, _ in places), places          # outside on the right
assert [y for _, y in places] == sorted([y for _, y in places], reverse=True)
print("the file holds the look that was asked for ok")

# opened again - by a script, and by the program as a user opens it
again = aplot.Graph.open(saved)
again.export(out("again.png"), dpi=100)
assert same_picture(out("spectra.png"), out("again.png")), "opened again: same picture"
app = session.app
app.hidden = False                                # the way the GUI opens a file
assert app.load_project(saved)
session.settle(6)
window = app.open_windows()[0]
window.figure_image(out("gui.png"), dpi=100)
assert same_picture(out("spectra.png"), out("gui.png")), "the GUI draws the same"
app.hidden = True
session.close_windows()
print("the graph opens in APlot and by a script with the same picture ok")

# -- 2. new numbers, the same look --------------------------------------------------
template = aplot.Graph.open(saved)
look = {c["column"]: (c["color"], c["linestyle"], c["linewidth"])
        for c in template.document["plots"][0]["series"]}
changed = spectra.copy()
changed["TE$_0$"] = changed["TE$_0$"] * 0.5
template.data = changed
assert np.allclose(template.data["TE$_0$"], changed["TE$_0$"])
template.export(out("changed.png"), dpi=100)
template.save(out("changed.aplt"))
after = {c["column"]: (c["color"], c["linestyle"], c["linewidth"])
         for c in aplot.read_project_document(out("changed.aplt"))["plots"][0]["series"]}
assert after == look, (after, look)
assert not same_picture(out("spectra.png"), out("changed.png")), "the numbers changed"
message = raises("'TE$_1$'", setattr, template, "data", spectra.drop(columns=["TE$_1$"]))
assert "the columns are" in message, message
template.set_data(spectra.drop(columns=["TE$_1$"]), allow_missing=True)
template.export(out("missing.png"), dpi=100)
print("new numbers keep the look; a missing column is an error unless allowed ok")

# -- 3. symbols with fitted lines that have no legend --------------------------------
length = np.arange(0.0, 221.0, 10.0)
frame = {"Section length L (um)": length}
for index, (slope, offset) in enumerate(((0.41, -43.5), (1.97, -34.5))):
    points = np.full_like(length, np.nan)
    points[[5, 10, 15, 20]] = slope * length[[5, 10, 15, 20]] + offset
    frame[f"pair {index}"] = points
    frame[f"pair {index} fit"] = slope * length + offset
symbols = aplot.Graph(frame)                        # a dict of columns
d = symbols.diagram().title("")
for index, colour in enumerate(("#1f77b4", "#ff7f0e")):
    d.curve(f"pair {index}", style="scatter", marker="os"[index], color=colour,
            linestyle="none", markersize=9)
    d.curve(f"pair {index} fit", color=colour, linestyle="--", legend=False)
d.axis("x", range=(0, 220), step=40).legend(position="outside right")
symbols.export(out("symbols.png"), dpi=100)
window = session.app.open_windows()[0]
assert sorted(window.legends) == ["pair 0", "pair 1"], sorted(window.legends)
assert window.series["pair 0"].get_marker() == "o"
assert window.series["pair 1 fit"].get_label().startswith("_")
d.curve("pair 1 fit", legend=True)                  # and back again
assert symbols.diagram().state["series"][3]["label"] == "pair 1 fit"
print("symbols with legend boxes, fitted lines without them ok")

# -- 4. a colour surface with an outline contour -------------------------------------
y = np.linspace(-0.8, 1.6, 49)
z = np.linspace(-0.8, 0.8, 33)
Y, Z = np.meshgrid(y, z)
field = np.exp(-(Y / 0.3) ** 2 - ((Z - 0.12) / 0.15) ** 2) \
    - np.exp(-((Y - 0.8) / 0.3) ** 2 - ((Z - 0.12) / 0.15) ** 2)
core = ((np.abs(Y - 0.4) <= 0.75) & (Z >= 0.0) & (Z <= 0.25)).astype(float)
mode = aplot.Graph(pd.DataFrame({"y (um)": Y.ravel(), "z (um)": Z.ravel(),
                                 "field": field.ravel(), "z2": Z.ravel(),
                                 "n": core.ravel()}), style="pcolor")
d = mode.diagram().title("").legend(False)
surface, outline = d.columns
d.surface(surface, cmap="coolwarm", range=(-1, 1), shading="smooth",
          bar_label="Re $E_y$ (norm.)")
d.surface(outline, style="contour", levels=1, range=(0, 1), color="#000000",
          colorbar=False)
d.axis("x", range=(-0.8, 1.6), step=0.4).axis("y", range=(-0.8, 0.8), step=0.4)
mode.export(out("mode.png"), dpi=100)
window = session.app.open_windows()[0]
assert surface in window.hist2d_bars and outline not in window.hist2d_bars
assert window.series_style[outline] == "contour"
assert window.hist2d_bars[surface].ax.get_ylabel() == "Re $E_y$ (norm.)"
# the Z values belong to the curves: new numbers without them are an error
assert mode.drawn_columns() == ["z (um)", "field", "z2", "n"], mode.drawn_columns()
raises("'field'", setattr, mode, "data", mode.data.drop(columns=["field"]))
print("a colour surface with an outline contour and a labelled colour bar ok")

# -- 5. several diagrams: one picture each ------------------------------------------
both = aplot.Graph.open(saved)
both.add_diagram("scatter")
assert len(both.diagrams) == 2
written = both.export(out("both.png"), dpi=60)
assert [os.path.basename(p) for p in written] == ["both_1.png", "both_2.png"], written
assert os.path.basename(both.export(out("second.png"), dpi=60, diagram=1)[0]) == "second.png"
print("several diagrams give one picture each ok")

# -- 6. mistakes come back as APlotError, never as a dialog -------------------------
d = graph.diagram()
raises("unknown style", aplot.Graph, spectra, style="nonsense")
raises("no curve", d.curve, "nothing", color="red")
raises("no 'y2' axis", d.axis, "y2", label="right")
raises("is not below", d.axis, "x", range=(5, 1))
raises("unknown scale", d.axis, "y", scale="cubic")
raises("unknown line style", d.curve, "TE$_1$", linestyle="wavy")
raises("unknown legend position", d.legend, position="somewhere")
raises("no setting", d.curve, "TE$_1$", wobble=3)
raises("not a surface style", mode.diagram().surface, surface, style="line")
raises("unknown colour scale", mode.diagram().surface, surface, cmap="nocolours")
raises("diagram(s)", graph.diagram, 5)
raises("needs an ending", graph.export, out("noending"))
raises("same name", aplot.Graph, pd.DataFrame([[1, 2], [3, 4]], columns=["a", "a"]))
raises("No such file", aplot.Graph.open, out("missing.aplt"))
with open(out("text.aplt"), "w") as handle:
    handle.write('{"format": "something else"}')
raises("is not an APlot graph", aplot.Graph.open, out("text.aplt"))
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    raises("cannot be drawn", aplot.Graph, pd.DataFrame({"x": ["a", "b"]}), style="line")
for name, function in ORIGINAL_DIALOGS.items():
    assert getattr(aplot.messagebox, name) is function, f"{name} is given back"
print("every mistake is an APlotError with a message ok")

# -- 7. the user's own settings, when asked for -----------------------------------
aplot.Config().save()                      # the user has a settings file
user = aplot.Config()
user.set("plot", "line_width", 4.0)
user.save()
mine = aplot.Graph(spectra, style="line", settings="user")
assert all(c["linewidth"] == 4.0 for c in mine.document["plots"][0]["series"])
plain = aplot.Graph(spectra, style="line")
assert all(c["linewidth"] == 1.5 for c in plain.document["plots"][0]["series"])
print("settings='user' draws with the user's settings, the default does not ok")

aplot.close()
assert aplot._ScriptSession.current is None
print("ALL OK")
