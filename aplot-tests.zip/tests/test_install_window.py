"""Headless test (1.3.9): installing APlot is the same on Linux as on a Mac.

The first start of a plain aplot.py opens one window - `Install APlot` -
with two choices, only for me or for every user of the computer, and it
is asked once.  `Install APlot...` in the menu opens it at any time.  For
every user the system asks for an administrator's password (pkexec on
Linux, the usual dialog on a Mac): here that step is played by a stand-in,
and the "system" folders are temporary ones.  Nothing outside temporary
folders is touched, and no window of a test ever offers it by itself.
"""
import os, re, stat, subprocess, sys, tempfile, time

HOME = os.path.realpath(tempfile.mkdtemp())   # /var is /private/var on a Mac
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import tkinter as tk
import aplot

Path = aplot.Path
said = []
aplot.messagebox.showinfo = lambda *a, **k: said.append(("info",) + a)
aplot.messagebox.showwarning = lambda *a, **k: said.append(("warning",) + a)
aplot.messagebox.showerror = lambda *a, **k: said.append(("error",) + a)
answers = []
aplot.messagebox.askyesno = lambda *a, **k: (said.append(("ask",) + a),
                                             answers.pop(0) if answers else False)[1]
SOURCE = open(aplot.__file__, encoding="utf-8").read()


def version_file(path, version):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(re.sub(r'^APP_VERSION = "[^"]*"', f'APP_VERSION = "{version}"',
                           SOURCE, count=1, flags=re.M), encoding="utf-8")
    return path


def version_of(path):
    return aplot.program_facts(Path(path).read_text(encoding="utf-8"))["version"]


work = Path(tempfile.mkdtemp()) / "My Code"
edited = version_file(work / "aplot.py", "1.3.9")

# -- 1. what can be installed ---------------------------------------------------
for platform in ("linux", "darwin"):
    assert aplot.can_be_installed(edited, platform), platform
assert not aplot.can_be_installed(edited, "win32")
packaged = version_file(Path(tempfile.mkdtemp()) / "aplot.py", "1.3.9")
(packaged.parent / aplot.PACKAGE_MARK).write_text("deb\n")
assert not aplot.can_be_installed(packaged, "linux")
assert aplot.install_folder(False, "darwin") == "~/Applications/APlot.app"
assert aplot.install_folder(True, "darwin") == "/Applications/APlot.app"
assert aplot.install_folder(False, "linux") == "~/.local"
assert aplot.install_folder(True, "linux") == "/usr/local"
print("a plain aplot.py can be installed, a packaged one not ok")

# -- 2. Linux, only for me: everything under ~/.local ---------------------------
result = aplot.install_program(system=False, platform="linux", program=edited)
installed = Path(HOME) / ".local" / "share" / "aplot" / "aplot.py"
assert result["where"] == installed, result
assert installed.read_bytes() == edited.read_bytes()
assert result["command"][-1] == str(installed)
assert (Path(HOME) / ".local" / "share" / "applications" / "aplot.desktop").is_file()
assert (Path(HOME) / ".local" / "bin" / "aplot").is_file()
assert not aplot.can_be_installed(installed, "linux")      # that is the installed one
assert installed in aplot.existing_installations("linux")
print("Linux, only for me: ~/.local/share/aplot/aplot.py and its menu entry ok")

# -- 3. Linux, for every user: the password window, then --system ---------------
SYSTEM = Path(tempfile.mkdtemp()) / "usr-local"
real_paths = aplot.linux_desktop_paths


def paths_here(system=False, prefix=None):
    if prefix is None and system:
        prefix = SYSTEM             # /usr/local, played by a temporary folder
    return real_paths(system, prefix)


aplot.linux_desktop_paths = paths_here
asked_admin = []


def admin_says_yes(command, platform=None, timeout=600):
    asked_admin.append((list(command), platform))
    if platform.startswith("linux"):
        # what `pkexec python3 aplot.py --install-desktop --system` does
        assert command[-2:] == ["--install-desktop", "--system"], command
        assert command[1] == str(edited.resolve()), command
        aplot.install_linux_desktop(system=True, program=command[1], refresh=False)
    else:
        # what the Mac's password window runs: the copy into /Applications
        folder = aplot.MACOS_SYSTEM_APPLICATIONS
        os.chmod(folder, 0o755)
        try:
            done = subprocess.run(command, capture_output=True, text=True)
        finally:
            os.chmod(folder, 0o555)
        assert done.returncode == 0, done.stderr
    return True, ""


def admin_says_no(command, platform=None, timeout=600):
    asked_admin.append((list(command), platform))
    return False, "the password of an administrator was not given"


real_admin = aplot.run_as_administrator
aplot.run_as_administrator = admin_says_no
root_now = hasattr(os, "geteuid") and os.geteuid() == 0
if not root_now:
    try:
        aplot.install_program(system=True, platform="linux", program=edited)
    except aplot.InstallError as error:
        text = str(error)
        assert "password" in text and "--install-desktop --system" in text, text
        assert "sudo" in text, text
    else:
        raise AssertionError("installed without the password")
    assert asked_admin and asked_admin[-1][1] == "linux"
    assert not (SYSTEM / "share" / "aplot" / "aplot.py").exists()
aplot.run_as_administrator = admin_says_yes
asked_admin.clear()
result = aplot.install_program(system=True, platform="linux", program=edited)
assert result["where"] == SYSTEM / "share" / "aplot" / "aplot.py", result
assert result["where"].read_bytes() == edited.read_bytes()
assert (SYSTEM / "share" / "applications" / "aplot.desktop").is_file()
assert bool(asked_admin) != root_now      # root itself is never asked
print("Linux, for every user: asked for the password, written under /usr/local ok")

# pkexec tells who asked: the Space bar viewer goes into that user's home
if not root_now and hasattr(os, "getuid"):
    os.environ.pop("SUDO_USER", None)
    os.environ["PKEXEC_UID"] = str(os.getuid())
    user = aplot._sudo_user()
    assert user is not None and user[1] == os.getuid(), user
    os.environ.pop("PKEXEC_UID")
    assert aplot._sudo_user() is None
    print("pkexec: the user who asked is known ok")

# -- 4. macOS, only for me: ~/Applications/APlot.app --------------------------
result = aplot.install_program(system=False, platform="darwin", program=edited)
bundle = Path(HOME) / "Applications" / "APlot.app"
assert result["where"] == bundle, result
copy = bundle / "Contents" / "Resources" / "aplot.py"
assert copy.read_bytes() == edited.read_bytes()
assert result["command"][:4] == ["/usr/bin/open", "-n", "-a", str(bundle)]
assert copy in aplot.existing_installations("darwin")
print("macOS, only for me: ~/Applications/APlot.app ok")

# -- 5. macOS, for every user: /Applications, through the password window -----
apps = Path(tempfile.mkdtemp()) / "Applications"
apps.mkdir()
os.chmod(apps, 0o555)                    # only an administrator may write it
aplot.MACOS_SYSTEM_APPLICATIONS = apps
asked_admin.clear()
result = aplot.install_program(system=True, platform="darwin", program=edited)
assert result["where"] == apps / "APlot.app", result
launcher = apps / "APlot.app" / "Contents" / "MacOS" / "APlot"
assert os.access(launcher, os.X_OK)
assert version_of(apps / "APlot.app" / "Contents" / "Resources" / "aplot.py") == "1.3.9"
assert not list(apps.glob("*.aplot-new"))
if not os.access(apps, os.W_OK) or asked_admin:
    assert asked_admin and asked_admin[-1][1] == "darwin", asked_admin
    assert asked_admin[-1][0][:2] == ["/bin/sh", "-c"]
# a second time: the old bundle is replaced, not nested inside it
version_file(edited, "1.3.10")
aplot.install_program(system=True, platform="darwin", program=edited)
assert version_of(apps / "APlot.app" / "Contents" / "Resources" / "aplot.py") == "1.3.10"
assert not (apps / "APlot.app" / "APlot.app").exists()
os.chmod(apps, 0o755)
version_file(edited, "1.3.9")
print("macOS, for every user: /Applications/APlot.app, asked for the password ok")

aplot.run_as_administrator = real_admin
ok, why = aplot.run_as_administrator(["true"], platform="win32")
assert not ok and why
print("no password window on other systems ok")

# -- 6. the window: two choices, Install hands the choice on -------------------
root = tk.Tk()


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


for platform in ("linux", "darwin"):
    chosen = []
    dialog = aplot.InstallDialog(root, chosen.append, platform=platform,
                                 first_start=True)
    settle(2)
    texts = []

    def walk(widget):
        try:
            texts.append(str(widget.cget("text")))
        except tk.TclError:
            pass
        for child in widget.winfo_children():
            walk(child)

    walk(dialog)
    joined = "\n".join(texts)
    assert "Only for me" in joined and "For every user of this computer" in joined, joined
    assert aplot.install_folder(False, platform) in joined
    assert aplot.install_folder(True, platform) in joined
    assert "password" in joined and "asked once" in joined, joined
    assert dialog.choice.get() == "user"           # only for me, unless chosen
    dialog.choice.set("system")
    dialog._install()
    settle(1)
    assert chosen == [True], chosen
    assert not dialog.winfo_exists()
print("the window offers both, the same on Linux and on a Mac ok")

# -- 7. the program: never offered by a window of a test, once at a real start -
settings = aplot.Config(os.path.join(HOME, "settings.json"))
assert settings.get("install", "ask_at_start") is True
app = aplot.App(root, settings)                  # as every test builds it
settle(30, 0.03)                                 # longer than the 600 ms
assert not [w for w in root.winfo_children() if isinstance(w, aplot.InstallDialog)]
assert settings.get("install", "ask_at_start") is True
print("a window built by a test does not offer it ok")

aplot.can_be_installed = lambda program=None, platform=None: True
aplot.existing_installations = lambda platform=None: []
assert app._offer_installation() is True
settle(2)
dialogs = [w for w in root.winfo_children() if isinstance(w, aplot.InstallDialog)]
assert len(dialogs) == 1, dialogs
dialogs[0].close()
assert settings.get("install", "ask_at_start") is False
assert settings.get("macos", "ask_app_bundle") is False
assert app._offer_installation() is False          # once, whatever the answer
settings.set("install", "ask_at_start", True)
settings.set("macos", "ask_app_bundle", False)    # asked by 1.3.8 on a Mac
assert app._offer_installation() is (sys.platform != "darwin")
for w in root.winfo_children():
    if isinstance(w, aplot.InstallDialog):
        w.close()
settings.set("install", "ask_at_start", True)
aplot.existing_installations = lambda platform=None: [Path("/somewhere/aplot.py")]
assert app._offer_installation() is False          # installed already
print("the first start asks once, not when it is installed already ok")

# the menu item, on both systems
menubar = app.build_menubar(tk.Toplevel(root))
labels = []
for index in range(menubar.index("end") + 1):
    try:
        sub = root.nametowidget(menubar.entrycget(index, "menu"))
    except (tk.TclError, KeyError):
        continue
    last = sub.index("end")
    for item in range(0 if last is None else last + 1):
        try:
            labels.append(sub.entrycget(item, "label"))
        except tk.TclError:
            pass
assert "Install APlot..." in labels, labels
print("`Install APlot...` is in the menu ok")

# -- 8. Install: the work is done, the user told, the installed one started ----
calls = []


def fake_install(system=False, platform=None, program=None):
    calls.append(system)
    return {"where": Path(HOME) / "installed", "command": ["true"],
            "start": "the applications menu"}


aplot.install_program = fake_install
answers[:] = [False]                               # do not start it now
assert app.perform_install(system=True) is True
for _ in range(60):
    settle(1, 0.02)
    if app.install_result is not None:
        break
assert calls == [True] and app.install_result["where"] == Path(HOME) / "installed"
question = [one for one in said if one[0] == "ask"][-1]
assert "every user" in question[2] and "installed" in question[2], question
assert root.winfo_exists()
print("installed for every user, and the user is told where ok")


def broken_install(system=False, platform=None, program=None):
    raise aplot.InstallError("the password of an administrator was not given")


aplot.install_program = broken_install
said.clear()
app.perform_install(system=True)
for _ in range(60):
    settle(1, 0.02)
    if any(one[0] == "error" for one in said):
        break
assert any(one[0] == "error" and "password" in one[2] for one in said), said
print("a refused password is reported ok")

aplot.install_program = fake_install
started = []
real_popen = aplot.subprocess.Popen
aplot.subprocess.Popen = lambda command, **k: started.append(command)
answers[:] = [True]                                # start it now
app.install_result = None
app.perform_install(system=False)
for _ in range(60):
    settle(1, 0.02)
    if started:
        break
aplot.subprocess.Popen = real_popen
assert started == [["true"]], started
print("the installed APlot is started and this one closes ok")
try:
    settle(20, 0.03)
except tk.TclError:
    pass                                           # closed, as it should be

print("ALL OK")
