"""Headless test (1.6.9): select all, then type - the new text replaces the old.

The habit of renaming anything: `Cmd/Ctrl+A` in a field, then the new text.
Before 1.6.9 the legend text of `Curve properties` (applied at every key)
took the first key for an empty legend and filled the name of the column in
at once: "Hello" typed over "50 um" gave "HelloY1".  Now:

* the legend text of `Curve properties`: the typed text replaces the old one,
  and the legend shows it; a field left empty still gets the column name;
* every other field of every property window (each plot style), the text
  written in place on the graph, and the cell, heading, formula bar and tab
  editors of the sheet: what is typed after select all is all they hold.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import tkinter as tk
from tkinter import ttk
import numpy as np
import pandas as pd
import aplot
from keys_help import Keys

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))
keys = Keys(root)
print("keys:", keys.how)
grid = np.linspace(0.0, 4.0, 5)
X, Y = np.meshgrid(grid, grid)
app.table.set_dataframe(pd.DataFrame({"x": X.ravel(), "y": Y.ravel(),
                                      "z": (X * Y).ravel(),
                                      "w": (X + Y).ravel()}), check_all=True)
keys.settle(4)
FIELDS = ("TEntry", "Entry", "TSpinbox", "Spinbox", "TCombobox")


def replace(widget, new):
    """Select all of the field (as Cmd/Ctrl+A does) and type `new`."""
    for _ in range(10):        # a Mac brings the window in front a moment later
        widget.focus_force()
        keys.settle(2)
        if keys.focus() is widget:
            break
    assert keys.focus() is widget, (keys.focus(), widget)
    try:
        widget.icursor(1)                 # the cursor somewhere in the text
    except (tk.TclError, AttributeError):
        widget.mark_set("insert", "1.1")
    widget.event_generate("<<SelectAll>>")
    keys.settle(2)
    keys.type(new)
    if isinstance(widget, tk.Text):
        return widget.get("1.0", "end-1c")
    return widget.get()


# -- 1. the legend text of Curve properties ---------------------------------
plot = app.open_plot("line_symbol")
keys.settle(15)
line = plot.series["y"]
line.set_label("50 um (EAM)")
plot.refresh_legend()
plot.draw()
dialog = plot.open_series_dialog(line)
keys.settle(15)
got = replace(dialog.label_entry, "Hello")
assert got == "Hello", f"the legend field holds {got!r}"
assert line.get_label() == "Hello", line.get_label()
assert plot.legend_text("y") == "Hello", plot.legend_text("y")
# a field left empty: the name of the column, as before
dialog.label_entry.delete(0, "end")
keys.settle(2)
assert line.get_label() == "Hello", "an empty field for a moment changes nothing"
dialog.style_box.focus_force()            # the field is left
keys.settle(4)
assert dialog.label_var.get() == "y", dialog.label_var.get()
assert line.get_label() == "y", line.get_label()
dialog.label_entry.delete(0, "end")
keys.settle(2)
dialog.close()                            # left empty by closing the window
keys.settle(4)
assert line.get_label() == "y", line.get_label()
assert not errors, errors
print("legend text of Curve properties: typed over, column name when empty ok")


# -- 2. every field of every property window ------------------------------------
def fields(top):
    found, stack = [], [top]
    while stack:
        widget = stack.pop()
        if widget.winfo_class() in FIELDS and widget.winfo_ismapped():
            state = str(widget.cget("state"))
            if "readonly" not in state and state != "disabled":
                found.append(widget)
        stack.extend(widget.winfo_children())
    return found


def notebooks(top):
    found, stack = [], [top]
    while stack:
        widget = stack.pop()
        if isinstance(widget, ttk.Notebook):
            found.append(widget)
        stack.extend(widget.winfo_children())
    return found


checked, wrong = 0, []


def sweep(where, top):
    global checked
    keys.settle(10)
    pages = [(None, None)]
    if notebooks(top):
        pages = [(book, tab) for book in notebooks(top) for tab in book.tabs()]
    for book, tab in pages:
        if book is not None:
            book.select(tab)
            keys.settle(6)
        for widget in fields(top):
            old = widget.get()
            try:
                float(old)
                new = "0.5"               # a number every field takes
            except ValueError:
                new = "Abc"
            got = replace(widget, new)
            checked += 1
            if got != new:
                wrong.append((where, str(widget), old, got))


for code in [one[1] for one in aplot.PLOT_STYLES]:
    window = app.open_plot(code)
    keys.settle(15)
    name = next(iter(window.series))
    dialog = window.open_series_dialog(window.series[name])
    sweep(f"{code}: Curve properties", dialog)
    dialog.close()
    keys.settle(4)
    if code == "line_symbol":
        for which in ("x", "y"):
            dialog = window.open_axes_dialog(which)
            sweep(f"axes {which}", dialog)
            dialog.close()
        dialog = window.open_title_dialog()
        sweep("title", dialog)
        dialog.close()
        dialog = window.edit_legend_entry(name)
        sweep("legend box", dialog)
        dialog.close()
        note = window.add_note((0.4, 0.5), text="Note")
        keys.settle(4)
        dialog = window.edit_note(note)
        sweep("text box", dialog)
        dialog.close()
        editor = window.begin_inline_edit("legend", name)
        keys.settle(5)
        got = replace(editor, "Abc")
        checked += 1
        if got != "Abc":
            wrong.append(("text written in place", str(editor), "", got))
        window.cancel_inline_edit()
    window.destroy()
    keys.settle(4)
assert not wrong, "\n".join(map(str, wrong))
# the made-up numbers may be refused by the diagram (the same lowest and
# highest Z, say): only the text in the fields is checked here
errors.clear()
print(f"{checked} fields of the property windows: the typed text replaces ok")

# -- 3. the editors of the sheet -------------------------------------------------
table = app.table
table._begin_edit("1", 1)
keys.settle(5)
assert replace(table._editor[0], "7") == "7"
table._cancel_edit()
keys.settle(3)
table._begin_heading_edit("#2")
keys.settle(5)
heading = keys.focus()
assert replace(heading, "Abc") == "Abc"
table._cancel_heading_edit()
keys.settle(3)
assert replace(table.formula_bar.entry, "=1+2") == "=1+2"
editor = app.begin_tab_rename(0)
keys.settle(5)
assert replace(editor, "Abc") == "Abc"
app.cancel_tab_rename()
print("cell, heading, formula bar and tab name editors ok")

assert not errors, errors
keys.close()
root.destroy()
print("ALL OK")
