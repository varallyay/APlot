"""Headless test (1.1.2): the opacity boxes are a character wider; a property
window appears right at its place; a right click on a diagram behind a
property window opens its menu; the graph window scrolls by the pixel, a
twentieth of the window for one notch."""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
from matplotlib.backend_bases import MouseEvent
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None

root = tk.Tk()
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=3, pause=0.02):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


settle(4)
x = np.linspace(0.0, 10.0, 30)
app.table.set_dataframe(pd.DataFrame({"x": x, "y": np.sin(x) + 3.0}), check_all=True)
settle(2)
plot = app.open_plot("line")
settle(6)
line = plot.series[list(plot.series)[0]]

# -- 1. a property window appears right at its place --------------------------
mapped = []
real_init = aplot.ToolDialog.__init__


def watching_init(self, *args, **kwargs):
    real_init(self, *args, **kwargs)
    assert self.state() == "withdrawn", "kept hidden while it is built"
    self.bind("<Map>", lambda e, w=self: mapped.append(
        (w.winfo_rootx(), w.winfo_rooty())) if e.widget is w else None, add="+")


aplot.ToolDialog.__init__ = watching_init
dialog = plot.open_series_dialog(line)
assert dialog.state() == "withdrawn" and not dialog.winfo_ismapped()
settle(20)
aplot.ToolDialog.__init__ = real_init
assert dialog.winfo_ismapped() and dialog.state() == "normal"
assert mapped, "it was shown"
first = mapped[0]
final = (dialog.winfo_rootx(), dialog.winfo_rooty())
assert abs(first[0] - final[0]) <= 2 and abs(first[1] - final[1]) <= 2, (first, final)
print(f"the curve window appears at once where it stays: {final} ok")

# -- 2. the opacity boxes have room for 0.35 -----------------------------------
boxes = []


def walk(widget):
    for child in widget.winfo_children():
        if isinstance(child, ttk_spinbox):
            boxes.append(child)
        walk(child)


from tkinter import ttk
ttk_spinbox = ttk.Spinbox
walk(dialog)
by_variable = {str(box.cget("textvariable")): box for box in boxes}
for variable in ("fill_alpha_var", "bar_alpha_var", "h2_alpha_var"):
    var = getattr(dialog, variable, None)
    if var is None:
        continue
    box = by_variable.get(str(var))
    assert box is not None, variable
    assert int(box.cget("width")) == aplot.SPIN_WIDTH + 1, (variable, box.cget("width"))
others = [box for box in boxes if int(box.cget("width")) == aplot.SPIN_WIDTH]
assert others, "the other little boxes keep their width"
print(f"the opacity boxes are {aplot.SPIN_WIDTH + 1} characters wide ok")
dialog.close()
settle(2)

# -- 3. a right click while a property window is in front ----------------------
menus = []
plot.show_object_menu = lambda x, y, rx=None, ry=None: menus.append((x, y))
widget = plot.canvas.get_tk_widget()


def right_click(px, py):
    plot._on_button_press(MouseEvent("button_press_event", plot.canvas,
                                     float(px), float(py), 3))


right_click(200, 200)
assert menus == [(200, 200)], "in front: the menu opens at once"
menus.clear()
dialog = plot.open_series_dialog(line)
settle(20)
plot._activated(type("E", (), {"widget": plot})(), False)   # as a Mac says
assert plot.is_active() is False
right_click(210, 190)
assert menus == [], "not yet: the diagram is brought to the front first"
settle(3, pause=0.05)
time.sleep(aplot.MENU_WAKE_MS / 1000.0)
settle(3)
assert menus == [(210, 190)], menus
assert plot.is_active() is True
print("behind a property window, a right click brings the diagram forward "
      "and opens its menu ok")
# Tk's own report of the same click does not open a second menu...
menus.clear()
widget.event_generate("<Button-3>", x=100, y=100)
settle(2)
assert len(menus) == 1, menus
# ...but one matplotlib did not see opens it all the same
menus.clear()
fake = type("E", (), {"serial": -12345, "num": 2 if sys.platform == "darwin" else 3,
                      "x": 50, "y": 60, "x_root": 0, "y_root": 0})()
plot._right_button(fake)
assert len(menus) == 1, menus
dialog.close()
settle(2)
print("one menu per click, and a click matplotlib missed still opens it ok")

# -- 4. scrolling glides: a twentieth of the window per notch -----------------
plot.set_zoom(2.5)
settle(6)
view = plot.view
view.yview_moveto(0.0)
settle(2)
first, last = view.yview()
assert last - first < 0.9, "the page is larger than the window"
shown = view.winfo_height()
desk = shown / (last - first)


def offset():
    return view.yview()[0] * desk


class Wheel:
    def __init__(self, delta=0, num=0, state=0):
        self.delta, self.num, self.state = delta, num, state


start = offset()
plot._on_wheel(Wheel(num=5) if sys.platform.startswith("linux") else Wheel(delta=-120))
settle(1)
moved = offset() - start
assert abs(moved - aplot.SCROLL_NOTCH * shown) <= 2.0, (moved, shown)
# a trackpad (a Mac reports nearly every push as 1): each push moves half
# of the tenth of the window it moved before, never more
steps = []
for _ in range(6):
    before = offset()
    plot._on_wheel(Wheel(delta=-1))
    settle(1)
    steps.append(offset() - before)
for step in steps:
    assert abs(step - aplot.SCROLL_NOTCH * shown) <= 1.5, steps
assert aplot.SCROLL_NOTCH == 0.05, "half of a tenth"
# a fast spin counts for more, up to two notches
before = offset()
plot._on_wheel(Wheel(delta=-40))
settle(1)
assert abs(offset() - before - aplot.ZOOM_MAX_NOTCHES * aplot.SCROLL_NOTCH * shown) <= 1.5
# the far end stops it, and nothing piles up past it
for _ in range(400):
    plot._on_wheel(Wheel(delta=-120))
settle(1)
assert abs(view.yview()[1] - 1.0) < 1e-6
plot._on_wheel(Wheel(delta=120))
settle(1)
assert view.yview()[1] < 1.0, "the first notch back moves at once"
print(f"one notch (and one push) scrolls {moved:.0f} of {shown} pixels ok")

assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.1.2") and "| 1.1.2 | 2026-10-03 |" in aplot.DOCUMENTATION
print("version 1.1.2 or later ok")
root.destroy()
print("ALL OK")
