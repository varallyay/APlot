"""Headless test (1.4.3): the axes of the three x, y, z styles - colour
surface, contour lines, filled contours - begin and end on a major tick,
as those of every other style do, over a grid and over scattered points.
It stays so when the surface is turned (`Exchange the X and Y axes`),
turned back, drawn again and switched from one of the three styles to
another; the switch `Begin and end on a major tick` still lets the range
end at the edge of the surface, and a range typed in is left alone.
"""
import math, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def close_all():
    for window in app.open_windows():
        window.destroy()
    settle(2)


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-12 * max(1.0, abs(a), abs(b)))


def check(plot, label, x_data=(0.3, 9.7), y_data=(101.5, 148.2)):
    """Both axes hold their data and carry a major tick at both ends."""
    plot.canvas.draw()
    for which, data in (("x", x_data), ("y", y_data)):
        low, high = sorted(plot.current_limits(which))
        ticks = [float(t) for t in plot._axis_pair(which)[1].get_majorticklocs()]
        assert any(close(t, low) for t in ticks), (label, which, low, high, ticks)
        assert any(close(t, high) for t in ticks), (label, which, low, high, ticks)
        assert low <= data[0] and data[1] <= high, (label, which, low, high, data)


def turn(plot, dialog, on):
    dialog.sf_swap_var.set(on)
    dialog._apply()
    settle(4)


xs, ys = np.linspace(0.3, 9.7, 12), np.linspace(101.5, 148.2, 7)
gx, gy = np.meshgrid(xs, ys, indexing="ij")
grid = pd.DataFrame({"x": gx.ravel(), "y": gy.ravel(),
                     "z": np.sin(gx.ravel()) * (gy.ravel() - 100.0)})
rng = np.random.default_rng(1)
rx = np.concatenate(([0.3, 9.7], rng.uniform(0.3, 9.7, 80)))
ry = np.concatenate(([101.5, 148.2], rng.uniform(101.5, 148.2, 80)))
loose = pd.DataFrame({"x": rx, "y": ry, "z": np.sin(rx) * (ry - 100.0)})

# -- 1. opened, turned, turned back: the ends are ticks all the way ----------
for kind, frame in (("grid", grid), ("scattered", loose)):
    for style in aplot.SURFACE_STYLES:
        app.table.set_dataframe(frame, check_all=True)
        settle(2)
        plot = app.open_plot(style)
        settle(6)
        label = f"{style} over {kind} points"
        assert plot.ends_on_ticks("x") and plot.ends_on_ticks("y"), label
        check(plot, label)
        before = (plot.ax.get_xlim(), plot.ax.get_ylim())
        dialog = plot.open_series_dialog(next(iter(plot.series.values())))
        settle(4)
        turn(plot, dialog, True)
        assert plot.surface_swapped("y"), label
        assert (plot.ax.get_xlabel(), plot.ax.get_ylabel()) == ("y", "x"), label
        check(plot, label + ", turned", (101.5, 148.2), (0.3, 9.7))
        assert (plot.ax.get_ylim(), plot.ax.get_xlim()) == before, label
        # drawn again without being measured again: the range stays
        plot.refresh_series_visuals("y")
        plot.draw()
        settle(2)
        check(plot, label + ", turned and drawn again", (101.5, 148.2), (0.3, 9.7))
        turn(plot, dialog, False)
        check(plot, label + ", turned back")
        assert (plot.ax.get_xlim(), plot.ax.get_ylim()) == before, label
        close_all()
        print(f"{label}: ticks at the ends, turned and back ok")

# -- 2. one style switched to another in the dialog ---------------------------
app.table.set_dataframe(grid, check_all=True)
settle(2)
plot = app.open_plot("pcolor")
settle(6)
dialog = plot.open_series_dialog(next(iter(plot.series.values())))
settle(4)
for style in ("contour", "contourf", "pcolor", "contourf"):
    dialog.plot_style_var.set(aplot.name_of(aplot.PLOT_STYLES, style, ""))
    dialog._on_style_changed()
    settle(4)
    assert plot.series_style["y"] == style
    check(plot, f"switched to {style}")
print("switching between the three styles keeps the ticks at the ends ok")

# -- 3. the switch of the axes dialog: the range ends at the surface again ----
for which in ("x", "y"):
    plot.apply_axis(which, {**plot.axis_cfg[which], "ends_on_ticks": False})
settle(4)
assert tuple(plot.ax.get_xlim()) == (0.3, 9.7), plot.ax.get_xlim()
assert tuple(plot.ax.get_ylim()) == (101.5, 148.2), plot.ax.get_ylim()
plot.refresh_series_visuals("y")
plot._rescale()
assert tuple(plot.ax.get_xlim()) == (0.3, 9.7), plot.ax.get_xlim()
print("without the switch the range ends at the edge of the surface ok")

# -- 4. a range typed in is not touched by drawing the contours ---------------
plot.apply_axis("x", {**plot.axis_cfg["x"], "auto": False, "min": 2.5, "max": 7.25})
settle(4)
plot.refresh_series_visuals("y")
plot._rescale()
plot.draw()
assert tuple(plot.ax.get_xlim()) == (2.5, 7.25), plot.ax.get_xlim()
print("a range typed in stays as typed ok")
close_all()

print("ALL OK")
