"""Headless test (1.6.4): a self-contained APlot - its own Python, from the
Releases page - updates itself with the package of the newest release made
for its computer, not with a new aplot.py; a plain aplot.py goes on as
before.  Nothing here reaches GitHub: the answers are made up.
"""
import hashlib, importlib.util, io, json, os, sys, tempfile, types, zipfile
from pathlib import Path

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import aplot

for name in ("APLOT_FROZEN", "APLOT_VERSIONS", "APLOT_UPDATE_TARGET"):
    os.environ.pop(name, None)

# -- 1. which APlot is updated how -------------------------------------------------
assert aplot.release_update_kind() == "", "a plain aplot.py: the aplot.py of main"
os.environ["APLOT_FROZEN"] = "portable"
assert aplot.release_update_kind() == "portable"
os.environ["APLOT_FROZEN"] = "deb"
assert aplot.release_update_kind() == "deb"
del os.environ["APLOT_FROZEN"]
print("a self-contained APlot is updated from the releases, a plain one from main ok")

# -- 2. the file of a release for each kind and computer ---------------------------
name = aplot.release_asset_name
assert name("1.6.4", "portable", "AMD64", "win32") == "APlot-1.6.4-Windows-portable.zip"
assert name("1.6.4", "msi", "AMD64", "win32") == "APlot-1.6.4-Windows.msi"
assert name("1.6.4", "dmg", "arm64", "darwin") == "APlot-1.6.4-macOS-arm64.dmg"
assert name("1.6.4", "dmg", "x86_64", "darwin") == "APlot-1.6.4-macOS-x86_64.dmg"
assert name("1.6.4", "deb", "x86_64", "linux") == "aplot_1.6.4_amd64.deb"
assert name("1.6.4", "rpm", "x86_64", "linux") == "aplot-1.6.4-1.x86_64.rpm"
assert name("1.6.4", "deb", "aarch64", "linux") is None, "no ARM Linux package"
assert name("1.6.4", "portable", "x86_64", "linux") is None, "the Windows zip is not for Linux"
assert name("1.6.4", "frozen", "x86_64", "linux") is None
print("each kind finds its own file of the release ok")

# -- 3. the newest release, as GitHub tells it -------------------------------------
def answer(version, names):
    assets = [{"name": one, "size": 3, "digest": "sha256:" + hashlib.sha256(b"abc").hexdigest(),
               "browser_download_url": f"https://example.invalid/{one}"} for one in names]
    return json.dumps({"tag_name": f"v{version}", "published_at": "2026-11-19T10:00:00Z",
                       "html_url": f"https://example.invalid/v{version}",
                       "assets": assets}).encode()

asked = []
def fetch(url, first_bytes=None, timeout=None):
    asked.append(url)
    return answer("9.0.0", ["APlot-9.0.0-Windows-portable.zip", "aplot_9.0.0_amd64.deb"])

facts = aplot.check_for_release(current="1.6.4", kind="portable", fetch=fetch,
                                machine="AMD64", platform="win32")
assert asked == [aplot.RELEASE_API]
assert facts["newer"] and not facts["missing"] and facts["version"] == "9.0.0", facts
assert facts["date"] == "2026-11-19" and facts["asset"]["name"] == "APlot-9.0.0-Windows-portable.zip"
assert facts["source"].endswith("/v9.0.0/"), "what is new: the README of that release"
facts = aplot.check_for_release(current="1.6.4", kind="rpm", fetch=fetch,
                                machine="x86_64", platform="linux")
assert not facts["newer"] and facts["missing"], "a release without this package is not offered"
facts = aplot.check_for_release(current="9.0.0", kind="deb", fetch=fetch,
                                machine="x86_64", platform="linux")
assert not facts["newer"] and not facts["missing"], "up to date"
try:
    aplot.check_for_release(kind="deb", fetch=lambda *a, **k: b"<html>", machine="x86_64")
    raise AssertionError("a broken answer must be refused")
except aplot.UpdateError:
    pass
print("the newest release is read, and offered only with this computer's package ok")

# -- 4. the download is checked: size and SHA-256 ----------------------------------
facts = aplot.check_for_release(current="1.6.4", kind="deb", fetch=fetch,
                                machine="x86_64", platform="linux")
folder = Path(tempfile.mkdtemp())
path = aplot.download_release(facts, folder=folder, fetch=lambda url, **k: b"abc")
assert path == folder / "9.0.0" / "aplot_9.0.0_amd64.deb" and path.read_bytes() == b"abc"
for wrong in (b"abcd", b"abd"):
    try:
        aplot.download_release(facts, folder=folder, fetch=lambda url, **k: wrong)
        raise AssertionError(f"{wrong!r} must be refused")
    except aplot.UpdateError:
        pass
print("a download of the wrong size or SHA-256 is refused ok")

# -- 5. a portable APlot: unpacked for the user, the older copy taken away ---------
program = "APlot.exe" if os.name == "nt" else "APlot"
def portable_zip(version):
    data = io.BytesIO()
    with zipfile.ZipFile(data, "w") as bundle:
        bundle.writestr(f"APlot/{program}", b"program")
        bundle.writestr("APlot/PORTABLE", "portable\n")
        bundle.writestr("APlot/_internal/aplot.py", f'APP_VERSION = "{version}"\n')
    path = Path(tempfile.mkdtemp()) / f"APlot-{version}-Windows-portable.zip"
    path.write_bytes(data.getvalue())
    return path

versions = Path(tempfile.mkdtemp()) / "versions"
os.environ["APLOT_VERSIONS"] = str(versions)
assert aplot.versions_folder() == versions
old = aplot.unpack_portable(portable_zip("9.0.0"), "9.0.0")
assert (old / program).is_file() and (old / "PORTABLE").is_file()
new = aplot.unpack_portable(portable_zip("9.1.0"), "9.1.0")
assert new == versions / "APlot-9.1.0" and (new / program).is_file()
assert not old.exists(), "the older copy is taken away"
assert [one.name for one in versions.iterdir()] == ["APlot-9.1.0"], list(versions.iterdir())
result = aplot.install_release(portable_zip("9.2.0"), {"version": "9.2.0"}, kind="portable")
assert result["installed"] and result["command"] == [str(versions / "APlot-9.2.0" / program)]
assert "left as it is" in result["notes"][0]
del os.environ["APLOT_VERSIONS"]
print("a portable APlot unpacks the new release for the user and starts it ok")

# -- 6. the .deb and the .rpm: the package manager, as an administrator --------------
ran = []
def admin(command, platform=None):
    ran.append(command)
    return True, ""
package = Path(tempfile.mkdtemp()) / "aplot_9.0.0_amd64.deb"
package.write_bytes(b"deb")
result = aplot.install_release(package, {"version": "9.0.0"}, kind="deb", platform="linux",
                               administrator=admin, executable="/usr/lib/aplot/APlot")
assert result["installed"] and ran[-1][-1] == str(package.resolve()), ran
assert ran[-1][0] in ("apt-get", "dpkg"), ran
assert result["command"] == [str(Path("/usr/lib/aplot/APlot").resolve())]
result = aplot.install_release(package, {"version": "9.0.0"}, kind="deb", platform="linux",
                               administrator=lambda c, p=None: (False, "no password"),
                               executable="/usr/lib/aplot/APlot")
assert not result["installed"] and "sudo " in result["notes"][0] and "no password" in result["notes"][0]
command = aplot.linux_package_command("rpm", package)
assert command[-1] == str(package.resolve()) and command[0] in ("dnf", "zypper", "rpm")
print("a .deb or .rpm is installed by the package manager, or the command is told ok")

# -- 7. the .msi: its installer runs when APlot has closed --------------------------
# (1.6.6) a batch file that waits for APlot to end, runs in the home folder - not in
# the folder the installer replaces - and gets every path in environment variables,
# not written into it in a code page; a failed installer is told at the next start
package = Path(tempfile.mkdtemp(prefix="with space (and brackets) ")) / "APlot-9.0.0-Windows.msi"
package.write_bytes(b"msi")
exe = Path(tempfile.mkdtemp()) / "APlot.exe"
result = aplot.install_release(package, {"version": "9.0.0"}, kind="msi", executable=exe,
                               pid=4321)
assert result["installed"] and result["detached"] and result["open_variable"] == "APLOT_UPDATE_OPEN"
script = package.resolve().parent / "install-update.cmd"
assert result["command"] == f'cmd.exe /d /s /c ""{script}""', result["command"]
raw = script.read_bytes()
raw.decode("ascii")                                   # nothing in a code page
assert b"\r\n" in raw and b"\n" not in raw.replace(b"\r\n", b""), "CRLF lines"
text = raw.decode("ascii")
assert 'cd /d "%USERPROFILE%"' in text.splitlines()[2], "the home folder, first of all"
assert text.index(":wait") < text.index("msiexec.exe /i") < text.index('start "" "%APLOT_UPDATE_PROGRAM%"')
assert "set PYINSTALLER_RESET_ENVIRONMENT=1" in text
assert "(" not in text.split(":install")[1].replace('"', ""), "no ( ) blocks: a path with ) breaks them"
env = result["env"]
assert env["APLOT_UPDATE_PID"] == "4321" and env["APLOT_UPDATE_NAME"] == "APlot.exe"
assert env["APLOT_UPDATE_PACKAGE"] == str(package.resolve())
assert env["APLOT_UPDATE_PROGRAM"] == str(exe.resolve())
assert env["APLOT_UPDATE_FAILED"] == str(aplot.UPDATE_FAILED)
message = Path(env["APLOT_UPDATE_MESSAGE"]).read_text(encoding="utf-8")
assert message.endswith("ended with the code ") and "9.0.0 could not be installed" in message
print("the .msi is installed after APlot closes, and the new one started ok")

# -- 8. a flatpak and a build of one's own are only downloaded ------------------------
for kind in ("flatpak", "frozen"):
    result = aplot.install_release(package, {"version": "9.0.0"}, kind=kind)
    assert not result["installed"] and result["notes"], kind
facts = {"version": "9.0.0", "kind": "portable", "asset": {"name": "x.zip", "size": 57_000_000}}
assert "57 MB" in aplot.release_update_text(facts) and "unpacks" in aplot.release_update_text(facts)
print("the other kinds say what to do, and the dialog says what Update now does ok")

# -- 9. the bootstrap of a portable APlot hands over to the newer copy -------------
spec = importlib.util.spec_from_file_location(
    "aplot_frozen", os.path.join(HERE, "..", "packaging", "frozen", "aplot_frozen.py"))
if spec is not None and os.path.exists(spec.origin):
    boot = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(boot)
    bundled = Path(tempfile.mkdtemp()) / "aplot.py"
    bundled.write_text('APP_VERSION = "1.6.4"\n')
    folder = Path(tempfile.mkdtemp())
    for version in ("1.6.3", "1.7.0", "1.10.0"):
        (folder / f"APlot-{version}").mkdir()
        (folder / f"APlot-{version}" / program).write_bytes(b"")
    (folder / "APlot-2.0.0").mkdir()          # no program inside: not taken
    boot.bundled_program = lambda: bundled
    boot.versions_folder = lambda: folder
    assert boot.newer_portable_copy() == folder / "APlot-1.10.0" / program
    started = []
    boot.kind = lambda: "portable"
    real = boot.subprocess if hasattr(boot, "subprocess") else None
    import subprocess
    saved = subprocess.Popen
    subprocess.Popen = lambda command, **options: started.append((command, options["env"]))
    try:
        saved_argv = sys.argv
        sys.argv = ["APlot.exe", "graph.aplt"]
        assert boot.hand_over() is True
        assert started[-1][0] == [str(folder / "APlot-1.10.0" / program), "graph.aplt"]
        assert started[-1][1][boot.HANDED_OVER] == "1"
        os.environ[boot.HANDED_OVER] = "1"
        assert boot.hand_over() is False, "the copy that is started does not hand over again"
        del os.environ[boot.HANDED_OVER]
        boot.kind = lambda: "msi"
        assert boot.hand_over() is False, "only a portable APlot hands over"
    finally:
        subprocess.Popen = saved
        sys.argv = saved_argv
    bundled.write_text('APP_VERSION = "1.10.0"\n')
    assert boot.newer_portable_copy() is None, "not when it is the newest itself"
    # --script: a helper run with the Python inside
    script = Path(tempfile.mkdtemp()) / "helper.py"
    out = Path(tempfile.mkdtemp()) / "out.txt"
    script.write_text("import sys\nopen(sys.argv[2], 'w').write(sys.argv[0] + ' ' + sys.argv[1])\n")
    boot.run_script(str(script), ["hello", str(out)])
    assert out.read_text() == f"{script} hello", out.read_text()
    print("the bootstrap hands over to the newest copy once, and runs helper scripts ok")
else:
    print("(packaging/frozen is not beside the tests: the bootstrap is left out)")

print("ALL OK")
