"""Headless test (1.3.3): APlot opened and closed again without anything done
to it closes without asking about saving.

The blank sheet grows empty columns by itself when its window is wider, and
every click into a cell opens its editor: neither is an edit of the graph.
A real change - a value typed, a column renamed - is still asked about.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import aplot

asked = []
aplot.messagebox.askyesnocancel = lambda *a, **k: asked.append(a[:2]) or None  # Cancel
aplot.messagebox.askyesno = lambda *a, **k: False
aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None

root = tk.Tk()
root.geometry("950x520+0+0")
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=6, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def quiet():
    """Leaving now asks nothing (and the program would close)."""
    asked.clear()
    return app._may_discard("Quit") is True and asked == []


settle()
table = app.table


def visit(row, col):
    """A click into a cell: its editor opens - and is left again."""
    table.select_cell(row, col)
    table._begin_edit(str(row), col)
    settle(1)
    table._commit_edit()
    settle(1)


def write(row, col, text):
    table.select_cell(row, col)
    table._begin_edit(str(row), col)
    settle(1)
    table._editor[1].set(text)
    table._commit_edit()
    settle(1)


# -- 1. nothing done -------------------------------------------------------
assert app.is_modified() is False and quiet()
print("opened and left alone: nothing to save ok")

# -- 2. a wider window grows the blank sheet: still nothing to save ----------
before = len(table.df.columns)
root.geometry("1480x700")
settle(15)
assert len(table.df.columns) > before, (before, len(table.df.columns))
assert quiet(), "the columns the sheet grew by itself are no edit"
print(f"a wider window: {before} -> {len(table.df.columns)} empty columns, "
      "nothing to save ok")

# -- 3. looking around: cells, settings, About, documentation ----------------
for row, col in ((0, 0), (3, 2), (10, 5), (0, 0)):
    visit(row, col)
table.select_block(0, 0, 5, 3)
settle(1)
app.open_settings().destroy()
app.show_about()
help_window = app.show_documentation()
settle(2)
help_window.destroy()
assert quiet(), "clicks, a selection and the windows of the program are no edit"
# typed and taken back: the sheet is blank again
write(2, 1, "5")
assert app.is_modified() is True
write(2, 1, "")
assert quiet(), "a value typed and deleted again leaves nothing to save"
print("clicking around, the settings, About, the documentation: nothing to save ok")

# -- 4. a real change is asked about -----------------------------------------
write(0, 0, "1.5")
asked.clear()
assert app._may_discard("Quit") is False and asked, "a value typed: asked"
assert app.quit_app() is False and root.winfo_exists(), "Cancel keeps the program"
app.undo_step()
settle(2)
assert quiet(), "Undo brings the untouched sheet back"
assert table.rename_column(str(table.df.columns[1]), "Time")
settle(2)
assert app.is_modified() is True, "a renamed column is an edit"
app.undo_step()
settle(2)
assert quiet()
print("a value typed or a column renamed is asked about; Undo takes it back ok")

# -- 5. a graph from a file: only visiting its cells changes nothing ---------
data = os.path.join(HOME, "counts.csv")
with open(data, "w", encoding="utf-8") as handle:
    handle.write("n,count,label\n1,10,a\n2,,b\n3,30, c\n4,40,d\n")
assert app.load_csv(data)
settle(4)
graph = os.path.join(HOME, "counts.aplt")
assert app.save_project(graph) == graph
assert quiet()
for row in range(4):                   # integers, an empty cell, " c"
    for col in range(3):
        visit(row, col)
assert quiet(), "visiting integers, a gap and text keeps them as they were"
assert app.load_project(graph) is True
settle(4)
assert quiet(), "a graph just opened has nothing to save"
for row in range(4):
    for col in range(3):
        visit(row, col)
assert quiet()
write(1, 1, "20")
assert app.is_modified() is True
print("a graph from a file: visited cells stay as they were, a typed one counts ok")

# -- 6. the rule for the columns at the right end --------------------------------
tab = {"columns": ["X", "Y1", "Y2", "Y3"], "rows": [[1.0, "", None, float("nan")]],
       "axes": {"X": "B", "Y1": "L", "Y2": "L", "Y3": "L"}, "formulas": {},
       "column_widths": {}}
assert aplot.untouched_columns_trimmed(tab)["columns"] == ["X"]
for change, kept in (({"columns": ["X", "Y1", "Y2", "Temp"]}, 4),
                     ({"formulas": {"0,3": "=A1"}}, 4),
                     ({"column_widths": {"Y3": 200}}, 4),
                     ({"axes": {"X": "B", "Y1": "L", "Y2": "R", "Y3": "L"}}, 3),
                     ({"rows": [[1.0, "", 2.0, ""]]}, 3)):
    one = dict(tab, **change)
    assert len(aplot.untouched_columns_trimmed(one)["columns"]) == kept, (change, kept)
assert tab["columns"] == ["X", "Y1", "Y2", "Y3"], "the document itself is left alone"
print("only empty, unnamed, untouched columns at the right end are left out ok")

# -- 7. leaving the untouched program closes it without a word ----------------
app.undo_step()
settle(2)
assert app.load_project(graph) is True
settle(3)
asked.clear()
assert app.quit_app() is True and asked == []
assert aplot.version_tuple(aplot.APP_VERSION) >= aplot.version_tuple("1.3.3")
assert "| 1.3.3 | 2026-10-07 |" in aplot.DOCUMENTATION
print("ALL OK")
