"""Headless test (1.3.9): every axis of a new diagram begins and ends exactly
on a major tick, with its number - on a linear scale (the automatic range
is rounded out to the ticks around the data, with no extra margin) and on
the logarithmic ones (from one power of the base to another: Log 10,
Log 2, ln, and a step of two decades).  It stays so when the window is
resized, for both Y axes, reversed axes and negative or tiny numbers; a
range typed in that is a whole number of some nice step gets that step;
the switch `Begin and end on a major tick` of the axes dialog and the
setting `Axes begin and end on a tick` turn it off (matplotlib's own range
again); the graph file keeps it, and so does the exported script.
"""
import math, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def sheet(x, *columns):
    frame = {"x": np.asarray(x, dtype=float)}
    for index, values in enumerate(columns):
        frame[f"y{index + 1}"] = np.asarray(values, dtype=float)
    app.table.set_dataframe(pd.DataFrame(frame), check_all=True)
    settle(2)


def close_all():
    for window in app.open_windows():
        window.destroy()
    settle(2)


def axis_of(plot, which):
    return plot._axis_pair(which)[1]


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-12 * max(1.0, abs(a), abs(b)))


def ends_are_ticks(plot, which):
    """Both ends of the axis carry a major tick (and so its number)."""
    plot.canvas.draw()
    low, high = sorted(plot.current_limits(which))
    ticks = [float(t) for t in axis_of(plot, which).get_majorticklocs()]
    shown = [t for t in ticks if low - 1e-9 * abs(high - low) <= t
             <= high + 1e-9 * abs(high - low)]
    return (any(close(t, low) for t in shown) and any(close(t, high) for t in shown),
            (low, high, shown))


def check(plot, which, data_low, data_high, label):
    ok, facts = ends_are_ticks(plot, which)
    assert ok, (label, which, facts)
    low, high = facts[0], facts[1]
    assert low <= data_low and data_high <= high, (label, which, facts, data_low, data_high)
    return facts


# -- 0. the locators on their own --------------------------------------------
loc = aplot.EndTickLocator()
assert loc.view_limits(0.3, 9.7) == (0.0, 10.0), loc.view_limits(0.3, 9.7)
assert loc.view_limits(-3.7, 12.2)[0] <= -3.7
low, high = loc.view_limits(1000.13, 1000.42)
assert low <= 1000.13 and high >= 1000.42 and high - low < 1.0, (low, high)
ticks = loc.tick_values(0.0, 7.0)
assert ticks[0] == 0.0 and ticks[-1] == 7.0, ticks
log = aplot.EndTickLogLocator(base=10.0, subs=(1.0,), numticks=400)
assert log.view_limits(0.37, 4200.0) == (0.1, 10000.0), log.view_limits(0.37, 4200.0)
assert log.view_limits(1.0, 100.0) == (1.0, 100.0)
log2 = aplot.EndTickLogLocator(base=2.0, subs=(1.0,), numticks=400)
assert log2.view_limits(3.0, 50.0) == (2.0, 64.0), log2.view_limits(3.0, 50.0)
print("the locators round out to the ticks ok")

# -- 1. a linear diagram: both axes end on ticks, no margin ---------------------
assert aplot.DEFAULTS["plot"]["ends_on_ticks"] is True
x = np.linspace(0.3, 9.7, 25)
sheet(x, 3.2 + 44.7 * (x - 0.3) / 9.4, np.sin(x) * 7.3 + 20.0)
plot = app.open_plot("line_symbol")
settle(6)
assert plot.ends_on_ticks("x") and plot.ends_on_ticks("y")
fx = check(plot, "x", 0.3, 9.7, "linear")
fy = check(plot, "y", 3.2, 47.9, "linear")
assert fx[0] == 0.0 and fx[1] == 10.0, fx
assert fy[0] == 0.0 and fy[1] == 50.0, fy
assert plot.ax.get_xmargin() == 0.0 and plot.ax.get_ymargin() == 0.0
print(f"linear: X {fx[0]:g} .. {fx[1]:g}, Y {fy[0]:g} .. {fy[1]:g}, ticks at the ends ok")

# the window resized: fewer or more ticks, the ends stay ticks
for width, height in ((420, 300), (1500, 1000), (700, 900)):
    plot.geometry(f"{width}x{height}")
    settle(4)
    check(plot, "x", 0.3, 9.7, f"window {width}x{height}")
    check(plot, "y", 3.2, 47.9, f"window {width}x{height}")
print("the ends stay ticks at any window size ok")

# the automatic range the dialog reports is that range as well
assert plot.automatic_limits("x") == tuple(sorted(plot.current_limits("x")))
close_all()

# -- 2. many kinds of data ------------------------------------------------------
rng = np.random.default_rng(7)
cases = [
    (np.linspace(-3.7, 12.2, 30), lambda x: x * x - 5.0),
    (np.linspace(0.0, 1.0, 11), lambda x: 1e-6 * (x + 0.137)),
    (np.linspace(1000.13, 1000.42, 9), lambda x: x - 1000.0),
    (np.linspace(-250.0, -40.0, 15), lambda x: -0.01 * x),
    (np.arange(1, 13, dtype=float), lambda x: rng.normal(0.0, 3.3, len(x))),
    (np.linspace(2.0, 2.0005, 6), lambda x: np.full(len(x), 5.0)),
]
for number, (xs, function) in enumerate(cases, 1):
    ys = function(xs)
    sheet(xs, ys)
    plot = app.open_plot("line")
    settle(5)
    check(plot, "x", xs.min(), xs.max(), f"case {number}")
    check(plot, "y", ys.min(), ys.max(), f"case {number}")
    close_all()
print(f"{len(cases)} kinds of data (negative, tiny, offset, constant) ok")

# -- 3. bars start at zero and end on ticks ---------------------------------
sheet(np.arange(1, 7, dtype=float), [3.0, 7.5, 2.2, 8.9, 6.1, 4.4])
plot = app.open_plot("bar")
settle(5)
fy = check(plot, "y", 0.0, 8.9, "bar")
assert fy[0] == 0.0, fy
check(plot, "x", 1.0, 6.0, "bar")
close_all()
print("bar chart: from zero to a tick ok")

# -- 4. logarithmic scales ------------------------------------------------------
xs = np.linspace(1.0, 20.0, 40)
ys = 0.37 * (4200.0 / 0.37) ** ((xs - 1.0) / 19.0)        # 0.37 ... 4200
sheet(xs, ys)
plot = app.open_plot("line")
settle(5)
for scale, base, expect in (("log10", 10.0, (0.1, 10000.0)),
                            ("log2", 2.0, (0.25, 8192.0)),
                            ("ln", math.e, (math.exp(-1), math.exp(9)))):
    plot.apply_axis("y", {**plot.axis_cfg["y"], "scale": scale, "auto": True,
                          "step": None})
    settle(3)
    facts = check(plot, "y", ys.min(), ys.max(), scale)
    assert close(facts[0], expect[0]) and close(facts[1], expect[1]), (scale, facts)
    for end in facts[:2]:                      # whole powers of the base
        power = math.log(end) / math.log(base)
        assert abs(power - round(power)) < 1e-9, (scale, end)
    print(f"{scale}: Y {facts[0]:.4g} .. {facts[1]:.4g}, whole powers, ticks at the ends ok")
# a step of two decades: 0.01, 1, 100, 10000
plot.apply_axis("y", {**plot.axis_cfg["y"], "scale": "log10", "auto": True, "step": 2})
settle(3)
facts = check(plot, "y", ys.min(), ys.max(), "log10 step 2")
assert close(facts[0], 0.01) and close(facts[1], 10000.0), facts
print("log10, two decades a step: 0.01 .. 10000 ok")
# the X axis logarithmic too, and the window resized
plot.apply_axis("x", {**plot.axis_cfg["x"], "scale": "log10", "auto": True, "step": None})
settle(3)
facts = check(plot, "x", 1.0, 20.0, "log x")
assert close(facts[0], 1.0) and close(facts[1], 100.0), facts
plot.geometry("500x380")
settle(4)
check(plot, "x", 1.0, 20.0, "log x small")
check(plot, "y", ys.min(), ys.max(), "log y small")
print("log X and log Y in a small window ok")
# back to linear: ticks at the ends again
plot.apply_axis("x", {**plot.axis_cfg["x"], "scale": "linear", "auto": True})
plot.apply_axis("y", {**plot.axis_cfg["y"], "scale": "linear", "auto": True, "step": None})
settle(3)
check(plot, "x", 1.0, 20.0, "linear again")
check(plot, "y", ys.min(), ys.max(), "linear again")
print("back to linear ok")

# -- 5. a reversed axis ----------------------------------------------------------
plot.apply_axis("y", {**plot.axis_cfg["y"], "direction": "reverse", "auto": True})
settle(3)
top, bottom = plot.current_limits("y")
assert top > bottom, (top, bottom)            # really turned round
check(plot, "y", ys.min(), ys.max(), "reversed")
plot.apply_axis("y", {**plot.axis_cfg["y"], "direction": "standard", "auto": True})
settle(2)
print("a reversed axis ends on ticks ok")

# -- 6. a range typed in: a whole number of steps gets ticks at its ends -------
plot.apply_axis("x", {**plot.axis_cfg["x"], "auto": False, "min": 0.0, "max": 7.0,
                      "step": None})
settle(3)
ok, facts = ends_are_ticks(plot, "x")
assert ok and facts[0] == 0.0 and facts[1] == 7.0, facts
plot.apply_axis("x", {**plot.axis_cfg["x"], "auto": False, "min": 0.0, "max": 7.31,
                      "step": None})
settle(3)
assert tuple(sorted(plot.current_limits("x"))) == (0.0, 7.31)   # left as typed
plot.apply_axis("x", {**plot.axis_cfg["x"], "auto": True})
settle(3)
check(plot, "x", 1.0, 20.0, "automatic again")
print("a range typed in: 0 .. 7 has both numbers, 0 .. 7.31 stays ok")

# -- 7. the second Y axis --------------------------------------------------------
close_all()
xs = np.linspace(0.0, 6.0, 20)
sheet(xs, np.cos(xs) * 3.1, 120.0 + 37.0 * np.sin(xs))
plot = app.open_plot("line")
settle(4)
plot.move_series(list(plot.series)[1], "right")
plot.apply_axis("y2", {**plot.axis_cfg["y2"], "direction": "standard", "auto": True})
settle(4)
check(plot, "y2", 83.0, 157.0, "right axis")
check(plot, "y", -3.1, 3.1, "left axis")
assert plot.ax2.get_ymargin() == 0.0
print("the right Y axis ends on ticks as well ok")

# -- 8. the file keeps it; the script draws it ---------------------------------
state = plot.to_state()
assert state["axes"]["x"]["ends_on_ticks"] is True
script = plot.to_script()
assert "MultipleLocator(" in script, "the script sets the end-tick spacing"
ns = {}
exec(compile(script.replace("plt.show()", ""), "diagram.py", "exec"), ns)
fig = ns.get("fig")
if fig is not None:
    ax = fig.axes[0]
    fig.canvas.draw()
    lo, hi = ax.get_xlim()
    locs = ax.xaxis.get_majorticklocs()
    assert any(close(t, lo) for t in locs) and any(close(t, hi) for t in locs), (lo, hi, locs)
path = os.path.join(HOME, "ends.aplt")
assert app.save_project(path) == path
close_all()
assert app.load_project(path) is True
settle(6)
plot = app.open_windows()[0]
check(plot, "x", 0.0, 6.0, "reopened")
check(plot, "y", -3.1, 3.1, "reopened")
print("saved and opened again: the ends are ticks ok")

# -- 9. switched off on one axis: matplotlib's range with its margin -----------
plot.apply_axis("x", {**plot.axis_cfg["x"], "ends_on_ticks": False, "auto": True})
settle(3)
low, high = plot.current_limits("x")
assert close(low, -0.3) and close(high, 6.3), (low, high)       # 5 % margin
assert plot.ax.get_xmargin() == 0.05
assert plot.to_state()["axes"]["x"]["ends_on_ticks"] is False
check(plot, "y", -3.1, 3.1, "the other axis keeps it")
print("switched off for X: 5 % margin, Y keeps its ticks at the ends ok")

# the axes dialog has the switch, and Apply takes it
dialog = plot.open_axes_dialog("x")
if dialog is not None:
    settle(3)
    tab = dialog.tabs["x"]
    assert tab.ends_var.get() is False
    tab.ends_var.set(True)
    dialog.apply()
    settle(3)
    assert plot.ends_on_ticks("x")
    check(plot, "x", 0.0, 6.0, "dialog")
    dialog.destroy()
    print("the axes dialog switches it on again ok")
close_all()

# -- 10. the setting off: new diagrams are drawn as before ---------------------
settings.set("plot", "ends_on_ticks", False)
xs = np.linspace(0.3, 9.7, 25)
sheet(xs, xs * 2.0)
plot = app.open_plot("line")
settle(4)
assert not plot.ends_on_ticks("x") and not plot.ends_on_ticks("y")
low, high = plot.current_limits("x")
assert close(low, 0.3 - 0.47) and close(high, 9.7 + 0.47), (low, high)
settings.set("plot", "ends_on_ticks", True)
close_all()
print("the setting off: matplotlib's range ok")

print("ALL OK")
