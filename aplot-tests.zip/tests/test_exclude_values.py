"""Headless test (1.7.0): values left out of the plots and the analysis.

The `#` button (under the add-row button) leaves the selected values out:
they stay in the sheet, shown as `#value` in italics, but the diagrams do
not draw them (the curve runs on from its neighbours; a left out X takes
its whole row), the regression does not fit them, a formula that reads one
gets #N/A and a range goes without it.  The button again takes them back.
They move with their rows and columns, Undo takes the step back, and a
saved graph keeps them; a group of sheets drawn together leaves them out
as well.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
root.geometry("900x600+20+40")
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


x = np.arange(1.0, 11.0)
y = 2.0 * x + 1.0
y[4] = 100.0                         # an outlier in row 5
app.table.set_dataframe(pd.DataFrame({"x": x, "y": y, "z": x ** 2}),
                        check_all=True)
settle(6)
table = app.table

# -- 1. the button, under the add-row button -----------------------------------
button = app.exclude_btn
assert button.winfo_ismapped()
assert abs(button.winfo_rootx() - app.add_row_btn.winfo_rootx()) <= 1
assert button.winfo_rooty() > app.add_row_btn.winfo_rooty()
assert "Exclude selected values (not plotted, not analyzed)" in button.tooltip.text

# -- 2. the outlier left out: italic #value over its cell ----------------------
table.select_cell(4, 1)
settle(2)
assert app.toggle_exclusion() == "excluded"
settle(4)
assert table.excluded == {(4, 1)}
assert table.df.iat[4, 1] == 100.0, "the value stays in the sheet"
shown = [label for label in table._excluded_labels if label.winfo_ismapped()]
assert len(shown) == 1 and shown[0].cget("text") == "#100.0", \
    [one.cget("text") for one in shown]
font = aplot.tkfont.Font(font=shown[0].cget("font"))
assert font.actual("slant") == "italic"
box = table.tree.bbox("4", "#2")
assert abs(shown[0].winfo_x() - box[0]) <= 1 and abs(shown[0].winfo_y() - box[1]) <= 1
# a click on it reaches the cell under it
label = shown[0]
middle = (label.winfo_width() // 2, label.winfo_height() // 2)
label.event_generate("<ButtonPress-1>", x=middle[0], y=middle[1])
label.event_generate("<ButtonRelease-1>", x=middle[0], y=middle[1])
settle(2)
assert tuple(table.cursor) == (4, 1), table.cursor
# the sum and the average of the status bar go without it
table.block = (0, 1, 9, 1)
table._update_status_bar()
summary = table.status_label.cget("text")
assert "Numeric: 9" in summary and "Sum: 109" in summary, summary
table.block = None
table.select_cell(4, 1)
print("the # button leaves a value out, shown as an italic #value ok")

# -- 3. the diagram, the regression, the formulas --------------------------------
plot = app.open_plot("line_symbol")
settle(10)
xs, ys = plot.series["y"].get_data()
assert 100.0 not in list(ys) and len(ys) == 9, ys
assert 5.0 not in list(xs), "the curve runs on from its neighbours"
frame = table.analysis_frame()
assert np.isnan(frame.iat[4, 1]) and frame.iat[4, 2] == 25.0
# a left out X takes its whole row
table.select_cell(7, 0)
app.toggle_exclusion()
app.update_plot()
settle(8)
xs, _ys = plot.series["y"].get_data()
xz, _zs = plot.series["z"].get_data()
assert 8.0 not in list(xs) and 8.0 not in list(xz), (xs, xz)
table.select_cell(7, 0)
app.toggle_exclusion()          # X of row 8 back in
assert table.excluded == {(4, 1)}
# the regression fits the line, not the outlier
dialog = app.open_regression()
settle(12)
dialog.plot_var.set(False)
code = [model.code for model in aplot.FIT_MODELS].index("poly")
dialog.method_list.selection_clear(0, "end")
dialog.method_list.selection_set(code)
dialog._method_chosen()
settle(4)
dialog.setting_vars["order"].set("1")
settle(4)
results = dialog.run_fit()
settle(8)
fit = [one for one in results if one["column"] == "y"][0]
params = sorted(float(one) for one in fit["params"])
assert abs(params[0] - 1.0) < 1e-6 and abs(params[1] - 2.0) < 1e-6, fit["params"]
dialog.close()
settle(2)
app.notebook.select(0)
settle(4)
table = app.table
# a formula that reads it gets #N/A; a range goes without it
table.df["w"] = ""
table.refresh()
table.cell_formulas[(0, 3)] = "=B5"
table.cell_formulas[(1, 3)] = "=SUM(B1:B10)"
table.cell_formulas[(2, 3)] = "=AVERAGE(B4:B6)"
table.recalculate_all()
assert table.df.iat[0, 3] == "#N/A", table.df.iat[0, 3]
assert table.df.iat[1, 3] == int(sum(2 * v + 1 for v in x) - 11), table.df.iat[1, 3]
assert table.df.iat[2, 3] == 11, table.df.iat[2, 3]
print("diagram, regression and formulas go without it ok")

# -- 4. taken back in by the button ---------------------------------------------
table.select_cell(4, 1)
assert app.toggle_exclusion() == "included"
settle(2)
assert not table.excluded
assert table.df.iat[0, 3] == 100, "the formula reads it again"
assert not any(one.winfo_ismapped() for one in table._excluded_labels)
# a block: left out together, and back together
table.block = (1, 1, 3, 2)
assert app.toggle_exclusion() == "excluded"
assert table.excluded == {(r, c) for r in (1, 2, 3) for c in (1, 2)}
table.block = (1, 1, 2, 1)           # part of it: all of those already out
assert app.toggle_exclusion() == "included"
assert table.excluded == {(3, 1), (1, 2), (2, 2), (3, 2)}
table.block = (1, 1, 3, 1)           # some in, some out: all go out
assert app.toggle_exclusion() == "excluded"
assert (1, 1) in table.excluded and (2, 1) in table.excluded
# empty cells are not left out
table.df.iat[9, 3] = ""
table.block = (9, 3, 9, 3)
assert app.toggle_exclusion() is None
print("the button takes them back, a block goes out and in together ok")

# -- 5. they move with their rows and columns; Undo; a saved graph -------------
table.block = None
table.excluded = {(4, 1)}
table.insert_row(2, focus=False)
assert table.excluded == {(5, 1)}, table.excluded
table.delete_row(0)
assert table.excluded == {(4, 1)}, table.excluded
table.insert_column("new", at=0)
assert table.excluded == {(4, 2)}, table.excluded
table.remove_column("new")
assert table.excluded == {(4, 1)}, table.excluded
settle(2)
table.select_cell(6, 1)
before = app.tab_document(0)
app.toggle_exclusion()
assert (6, 1) in table.excluded
app.undo_step()
settle(4)
table = app.table
assert (6, 1) not in table.excluded and (4, 1) in table.excluded, table.excluded
document = app.project_document()
assert document["tabs"][0]["excluded"] == [[4, 1]], document["tabs"][0].get("excluded")
path = os.path.join(HOME, "kept.aplt")
app.save_project(path, quiet=True)
table.excluded = set()
app.load_project(path)
settle(10)
assert app.table.excluded == {(4, 1)}, app.table.excluded
print("they move with rows and columns, Undo, a saved graph ok")

# -- 6. a group of sheets drawn together ----------------------------------------
for window in app.open_windows():
    window.destroy()
settle(2)
table = app.table
table.set_dataframe(pd.DataFrame({"x": x, "y": y}), check_all=True)
table.select_cell(4, 1)
app.toggle_exclusion()
app.add_tab("Data 2")
settle(4)
second = app.tables[-1]
second.set_dataframe(pd.DataFrame({"x": x + 0.5, "y": 3.0 * x}), check_all=True)
app.notebook.select(len(app.tables) - 1)
settle(4)
second.plot_with_previous_var.set(True)
app._plot_with_previous_changed()
settle(4)
data = app.plot_data(index=len(app.tables) - 1)
assert aplot.EXCLUDED_MARK not in data.astype(str).to_numpy().ravel().tolist()
plot = app.open_plot("line_symbol")
settle(10)
first_curve = [name for name in plot.series if str(name).startswith("y")][0]
_xs, ys = plot.series[first_curve].get_data()
finite = [one for one in ys if np.isfinite(one)]
assert 100.0 not in finite and len(finite) == 9, ys
print("a group of sheets drawn together leaves it out too ok")

assert not errors, errors
print("ALL OK")
