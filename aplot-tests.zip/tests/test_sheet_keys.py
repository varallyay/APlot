"""Headless test (1.3.8): walking the spreadsheet with the keyboard.

Real keys and clicks (xdotool and a window manager, see keys_help.py; the
same checks run with the keys handed to Tk where xdotool is missing):

* in an open cell: Enter, Shift+Enter, Tab, Shift+Tab, the arrows, the ends
  of a row (wrapping), the last row (a new row, or none when switched off),
  Ctrl+arrows, Left/Right inside the text, Esc;
* on the table itself (no cell open): the arrows, Tab and Shift+Tab (they
  used to send the keyboard to the formula bar), Enter, typing;
* keys typed faster than the program follows - a burst of keys in an open
  cell, on the table, after Esc - all arrive in the right cell (they used
  to be lost, or written over the cell just left);
* a click into another cell while one is open;
* the formula bar and the address box give the keyboard back to the sheet;
* a row number, a tab of the row of sheets, a toolbar button and coming
  back to the window leave the arrows working on the sheet in front;
* a sheet tab dragged to another place (and Undo), a column edge dragged.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from keys_help import Keys

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
SW, SH = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry(f"{int(SW * 0.6)}x{int(SH * 0.66)}+20+40")
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))
keys = Keys(root)
print("keys:", keys.how)


def blank(columns="ABCD", rows=5, table=None):
    table = table or app.table
    table.set_dataframe(pd.DataFrame({c: [""] * rows for c in columns}),
                        check_all=True)
    keys.settle(4)
    return table


def where(table=None):
    """("edit", row, col) for an open cell, ("grid", row, col) otherwise."""
    table = table or app.table
    editor = table._editor
    if editor is not None:
        return ("edit", int(editor[2]), int(editor[3]))
    return ("grid",) + tuple(int(one) for one in table.cursor)


def values(table=None):
    table = table or app.table
    return [["" if one == "" else one for one in row]
            for row in table.df.values.tolist()]


def click_cell(row, col, table=None):
    table = table or app.table
    table.tree.see(str(row))
    keys.settle(2)
    box = table.tree.bbox(str(row), f"#{col + 1}")
    assert box, ("cell not on the screen", row, col)
    keys.click(table.tree, box[0] + box[2] // 2, box[1] + box[3] // 2)


def focus_class():
    widget = keys.focus()
    return widget.winfo_class() if widget is not None else None


def expect(got, wanted, what):
    assert got == wanted, f"{what}: {got} != {wanted}"


# -- 1. an open cell: Tab, Enter, Shift+Tab, Shift+Enter ----------------------
table = blank()
click_cell(0, 0)
expect(where(), ("edit", 0, 0), "a click opens the cell")
keys.type("1"); keys.press("Tab")
expect(where(), ("edit", 0, 1), "Tab: right")
keys.type("2"); keys.press("Tab")
keys.type("3"); keys.press("Return")
expect(where(), ("edit", 1, 2), "Enter: down")
keys.type("4"); keys.press("shift+Tab")
expect(where(), ("edit", 1, 1), "Shift+Tab: left")
keys.press("shift+Return")
expect(where(), ("edit", 0, 1), "Shift+Enter: up")
keys.press("Down", "Down")
expect(where(), ("edit", 2, 1), "Down")
keys.press("Up")
expect(where(), ("edit", 1, 1), "Up")
expect(values()[:2], [[1, 2, 3, ""], ["", "", 4, ""]], "what was typed")
print("open cell: Tab, Shift+Tab, Enter, Shift+Enter, Up, Down ok")

# -- 2. the ends of a row wrap, the first row stops, the last one grows ---------
click_cell(1, 3)
keys.press("Tab")
expect(where(), ("edit", 2, 0), "Tab at the end of a row: the next row")
keys.press("shift+Tab")
expect(where(), ("edit", 1, 3), "Shift+Tab at the start: the row above")
keys.press("Right")
expect(where(), ("edit", 2, 0), "Right at the end of a row wraps as well")
click_cell(0, 2)
keys.press("Up")
expect(where(), ("edit", 0, 2), "Up in the first row stays")
keys.press("shift+Return")
expect(where(), ("edit", 0, 2), "Shift+Enter in the first row stays")
click_cell(0, 0)
keys.press("shift+Tab")
expect(where(), ("edit", 0, 0), "Shift+Tab in the very first cell stays")
rows = len(table.df)
click_cell(rows - 1, 1)
keys.type("9"); keys.press("Return")
expect(len(table.df), rows + 1, "Enter on the last row adds a row")
expect(where(), ("edit", rows, 1), "...and opens its cell")
keys.press("Escape")
click_cell(len(table.df) - 1, 3)
keys.press("Tab")
expect(len(table.df), rows + 2, "Tab in the very last cell adds a row")
expect(where(), ("edit", rows + 1, 0), "...and goes on at its start")
keys.press("Escape")
app.settings.set("table", "auto_extend", False)
rows = len(table.df)
click_cell(rows - 1, 2)
keys.press("Return")
expect((len(table.df), where()), (rows, ("edit", rows - 1, 2)),
       "with the setting off the table does not grow")
app.settings.set("table", "auto_extend", True)
keys.press("Escape")
print("wrapping at the ends of a row, the first and the last row ok")

# -- 3. inside the text: Left, Right, Ctrl+arrows, Esc --------------------------
table = blank()
click_cell(1, 1)
keys.type("abc")
keys.press("Left", "Left")
expect(where(), ("edit", 1, 1), "Left walks inside the text")
entry = table._editor[0]
expect(entry.index("insert"), 1, "the text cursor")
keys.press("Right", "Right")
expect(where(), ("edit", 1, 1), "Right up to the end of the text")
keys.press("Right")
expect(where(), ("edit", 1, 2), "Right past the end: the next cell")
expect(values()[1][1], "abc", "kept")
keys.type("xy"); keys.press("Left")
keys.press("ctrl+Left")
expect(where(), ("edit", 1, 1), "Ctrl+Left jumps at once")
expect(values()[1][2], "xy", "kept")
keys.press("ctrl+Down")
expect(where(), ("edit", 2, 1), "Ctrl+Down")
keys.type("zzz"); keys.press("Escape")
expect(where(), ("grid", 2, 1), "Esc closes the cell")
expect(values()[2][1], "", "...and keeps what was there")
expect(focus_class(), "Treeview", "the table has the keyboard")
print("Left/Right in the text, Ctrl+arrows, Esc ok")

# -- 4. the table itself: arrows, Tab, Shift+Tab, Enter, typing ------------------
keys.press("Right", "Down")
expect(where(), ("grid", 3, 2), "arrows on the table")
keys.press("Tab")
expect(where(), ("grid", 3, 3), "Tab on the table: one cell right")
expect(focus_class(), "Treeview", "Tab keeps the keyboard on the table")
keys.press("Tab")
expect(where(), ("grid", 4, 0), "Tab at the end of a row: the next row")
keys.press("shift+Tab", "shift+Tab")
expect(where(), ("grid", 3, 2), "Shift+Tab on the table")
keys.press("Left")
expect(where(), ("grid", 3, 1), "the arrows still work after Tab")
keys.press("Return")
expect(where(), ("edit", 3, 1), "Enter opens the cell")
keys.press("Escape")
keys.type("7")
expect(where(), ("edit", 3, 1), "typing opens the cell")
keys.press("Return")
expect(values()[3][1], 7, "and writes into it")
keys.press("Escape")
keys.press("Up", "Up", "Up", "Up", "Up", "Up")
expect(where(), ("grid", 0, 1), "Up stops at the first row")
print("the table: arrows, Tab, Shift+Tab, Enter and typing ok")

# -- 5. keys faster than the program: nothing lost, nothing misplaced -----------
table = blank()
click_cell(0, 0)
keys.burst("1", "Tab", "2", "Tab", "3", "Tab", "4", "Return",
           "5", "Tab", "6", "Return")
expect(values()[:3], [[1, 2, 3, 4], ["", "", "", 5], [6, "", "", ""]],
       "a burst in an open cell")
expect(where(), ("edit", 3, 0), "the burst ends in the right cell")
keys.press("Escape")
click_cell(3, 0)
keys.press("Escape")
keys.burst("1", "2", "Tab", "3", "4", "Return")
expect(values()[3][:2], [12, 34], "a burst on the table: every digit")
expect(where(), ("edit", 4, 1), "...and the right cell")
click_cell(4, 2)
keys.burst("x", "Escape", "Up", "Right")
expect(values()[4][2], "", "Esc in a burst still cancels")
expect(where(), ("grid", 3, 3), "the arrows after Esc walk the table")
print("bursts of keys: nothing lost, nothing written into the wrong cell ok")

# -- 6. a click into another cell while one is open -----------------------------
table = blank()
click_cell(1, 1)
keys.type("ab")
click_cell(3, 2)
expect(where(), ("edit", 3, 2), "the clicked cell is open")
expect(values()[1][1], "ab", "the cell left is kept")
keys.type("5"); keys.press("Return")
expect((values()[3][2], where()), (5, ("edit", 4, 2)), "typing goes on there")
keys.press("Escape")
print("clicking another cell while one is open ok")

# -- 7. the formula bar and the address box give the keyboard back --------------
bar = table.formula_bar
click_cell(2, 1)
keys.press("Escape")
keys.click(bar.entry)
bar.entry.delete(0, "end")
keys.type("=2*3"); keys.press("Return")
expect(values()[2][1], 6, "the formula bar writes the cell")
expect(focus_class(), "Treeview", "Enter in the formula bar: back to the sheet")
keys.press("Down")
expect(where(), ("grid", 3, 1), "the arrows walk on at once")
keys.click(bar.entry)
keys.type("99"); keys.press("Escape")
expect(focus_class(), "Treeview", "Esc in the formula bar: back to the sheet")
keys.click(bar.name_box)
bar.name_box.delete(0, "end")
keys.type("C2"); keys.press("Return")
expect(where(), ("grid", 1, 2), "the address box jumps")
keys.press("Right")
expect(where(), ("grid", 1, 3), "...and the arrows walk on from there")
print("formula bar and address box hand the keyboard back to the sheet ok")

# -- 8. a row number, a toolbar button, coming back to the window ----------------
numbers = table.row_tree
box = numbers.bbox("2")
keys.click(numbers, box[0] + box[2] // 2, box[1] + box[3] // 2)
keys.press("Down")
expect(where()[:2], ("grid", 3), "after a row number the arrows walk the cells")
rows = len(table.df)
before = where()
keys.click(app.add_row_btn)         # a toolbar button
expect(len(table.df), rows + 1, "the button added a row")
opened = where()
expect((opened[0], focus_class()), ("edit", "Entry"),
       "its new cell is open, with the keyboard")
keys.press("Down")
expect(where(), ("edit", opened[1] + 1, opened[2]),
       "after a toolbar button the arrows walk the cells")
keys.press("Escape")
other = tk.Toplevel(root)           # another window in front, then back
other.geometry(f"200x120+{int(SW * 0.7)}+60")
keys.settle(6)
keys.activate(other)
keys.activate(root)
other.destroy()
keys.settle(4)
before = where()
keys.press("Up")
expect(where(), ("grid", before[1] - 1, before[2]),
       "back in the window the arrows walk the cells at once")
print("row numbers, toolbar buttons and coming back keep the arrows on the sheet ok")

# -- 9. the row of sheets: click, drag to another place, Undo ------------------
first = blank("AB", 4)
first.set_dataframe(pd.DataFrame({"A": [1.0, 2.0, 3.0, 4.0],
                                  "B": [5.0, 6.0, 7.0, 8.0]}), check_all=True)
app.add_sheet(); keys.settle(4)
blank("XY", 4)
app.add_sheet(); keys.settle(4)
bar = app.tab_bar


def tab_spot(index):
    bar.flush()
    left, right = bar._spans[index]
    return ((left + right) // 2 - bar.offset(), aplot.TAB_BAR_HEIGHT // 2)


expect(app.tab_names(), ["Data 1", "Data 2", "Data 3"], "three sheets")
keys.click(bar.canvas, *tab_spot(0))
expect(app.active_tab_index, 0, "a click brings the sheet to the front")
keys.press("Down", "Right")
expect(where(app.tables[0]), ("grid", 1, 1), "its cells walk with the arrows")
keys.click(bar.canvas, *tab_spot(1))
expect(app.active_tab_index, 1, "the second sheet")
keys.press("Down")
expect(where(app.tables[1])[:2], ("grid", 1), "the arrows walk that sheet")
expect(where(app.tables[0]), ("grid", 1, 1), "...not the one behind it")
time.sleep(aplot.RENAME_DELAY / 1000.0 + 0.1)   # not a second click
moved = app.tables[0]
start = tab_spot(0)
end = tab_spot(2)
keys.drag(bar.canvas, start, (end[0] + 30, end[1]), steps=12)
expect(app.tab_names(), ["Data 2", "Data 3", "Data 1"], "the tab was carried")
expect(app.tables[2] is moved, True, "the sheet went with its tab")
expect(app.active_tab_index, 2, "the moved sheet stays in front")
expect(values(moved)[0], [1.0, 5.0], "with its data")
keys.press("Up")
expect(where(moved), ("grid", 0, 1), "the arrows walk the moved sheet")
app.undo_step(); keys.settle(6)
expect(app.tab_names(), ["Data 1", "Data 2", "Data 3"], "Undo puts it back")
print("tabs: a click, the arrows, a drag to another place and Undo ok")

# -- 10. a column edge dragged: the column keeps its width ------------------------
app.notebook.select(0); keys.settle(6)
table = app.table
tree = table.tree
name = str(tree["columns"][0])
width = int(tree.column(name, "width"))
box = tree.bbox(tree.get_children()[0], "#1")
edge = box[0] + box[2] - 1
assert tree.identify_region(edge, 4) == "separator", tree.identify_region(edge, 4)
keys.drag(tree, (edge, 4), (edge + 60, 4), steps=10)
wider = int(tree.column(name, "width"))
assert abs(wider - (width + 60)) <= 3, (width, wider)
expect(int(table.column_widths.get(name, 0)), wider, "the width is kept")
root.geometry(f"{int(SW * 0.62)}x{int(SH * 0.66)}"); keys.settle(10)
expect(int(tree.column(name, "width")), wider, "a wider window leaves it alone")
box = tree.bbox(tree.get_children()[0], "#1")
edge = box[0] + box[2] - 1
keys.drag(tree, (edge, 4), (edge - 40, 4), steps=8)
narrower = int(tree.column(name, "width"))
assert abs(narrower - (wider - 40)) <= 3, (wider, narrower)
click_cell(0, 0)
expect(where(), ("edit", 0, 0), "the cells still open after the drag")
box = tree.bbox("0", "#1")
placed = table._editor[0].place_info()
expect((int(placed["x"]), int(placed["width"])), (box[0], box[2]),
       "the open cell covers the new width")
keys.press("Escape", "Right")
expect(where(), ("grid", 0, 1), "and the arrows walk on")
print(f"a column edge dragged {width} -> {wider} -> {narrower} px, kept ok")

assert not errors, errors
keys.close()
print("ALL OK")
