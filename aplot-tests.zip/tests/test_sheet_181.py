"""Headless test (1.8.1): formulas in small letters, left out formula cells,
and the X scale on both sides of the plot area.

1. if(), and(), or(), not() are words of Python: written in small letters
   they could not even be read.  They work now in any case, `;` may stand
   between the arguments, a single `=` compares, SUM / MIN / MAX / AVERAGE
   take single cells and several ranges, IF works out only the branch it
   takes, MEDIAN of an even count is the middle of the two, ROUND takes a
   5 away from zero.
2. A whole row left out with the `#` button: its formula cells show their
   own number as `#value` (not `##N/A`), while a formula elsewhere reading
   a left out cell still gets #N/A.
3. The X column may tick both `x_B` and `x_T`: the X numbers are drawn
   below and above the plot area; at least one box always stays ticked.
"""
import os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot

for name in ("showinfo", "showwarning", "showerror"):
    setattr(aplot.messagebox, name, lambda *a, **k: None)
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

# -- 1. the formulas -----------------------------------------------------------
frame = pd.DataFrame({"A": [1, 2, 3, 4, 5, 6, 7, 8],
                      "B": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8],
                      "C": [0.2, 0.9, 0.4, 0.6, 0.1, 0.3, 0.7, 0.0]})
evaluator = aplot.FormulaEvaluator(frame, {})
cases = {
    "=if(c1<0.5,0,1)": 0, "=IF(C2<0.5,0,1)": 1, "=If(c2<0.5,0,1)": 1,
    "=if(c1<0.5;0;1)": 0, "=if(a1=1,10,20)": 10, "=if(a1<>1,10,20)": 20,
    "=if(a1>=1,10,20)": 10, "=if(a1==1,10,20)": 10, "=if(a1>5,1)": 0,
    "=if(c8=0,0,1/c8)": 0,                      # the other branch is not worked out
    "=and(a1>0,b1>0)": 1, "=AND(A1>0,B1>5)": 0, "=or(a1>5,b1>0)": 1,
    "=not(a1>5)": 1, "=NOT(A1<5)": 0, "=xor(a1>0,b1>0)": 0,
    "=if(and(a1>0,b1<1),1,0)": 1, "=a1>0 and (b1>0)": 1, "=a1>5 or b1>1": 0,
    "=min(a1,b2)": 0.2, "=MAX(A1,B2)": 1, "=max(a1:b3)": 3,
    "=sum(a1,a2,a3)": 6, "=sum(a1:a3,b1)": 6.1, "=SUM(A1:A2,A3:A4)": 10,
    "=average(a1,a2)": 1.5, "=count(a1:a8,b1)": 9, "=median(a1:a4)": 2.5,
    "=median(a1:a5)": 3, "=round(2.5,0)": 3, "=round(-2.5)": -3,
    "=round(2.675,2)": 2.68, "=round(1234,-2)": 1200,
    "=avg(a1:a4)": 2.5, "=int(-2.5)": -3, "=INT(B8*10)": 8,
    '=if(a1>0,"if(a=b)","no")': "if(a=b)",     # text in quotes stays text
}
for formula, wanted in cases.items():
    got = evaluator.evaluate(formula, 0, 3)
    if isinstance(wanted, str):
        assert got == wanted, (formula, got)
    else:
        assert isinstance(got, (int, float)) and abs(got - wanted) < 1e-9, \
            (formula, got, wanted)
print("formulas in small letters ok")

errors = []
root = tk.Tk()
root.report_callback_exception = lambda kind, value, tb: errors.append(value)
root.geometry("900x600+20+40")
app = aplot.App(root, aplot.Config(os.path.join(HOME, "settings.json")))


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


# -- 2. a whole row left out: its formula cells keep their number -------------
x = np.arange(1.0, 13.0)
app.table.set_dataframe(pd.DataFrame({"X": x, "Y1": np.zeros(12),
                                      "Y2": np.zeros(12)}), check_all=True)
settle(6)
table = app.table
for row in range(12):
    table.cell_formulas[(row, 1)] = f"=cos(a{row + 1}/2)"
table.cell_formulas[(6, 2)] = "=A6"              # reads a cell of row 6
table.recalculate_all()
settle(2)
assert abs(table.df.iat[5, 1] - round(np.cos(3.0), 8)) < 1e-9

table.block = (5, 0, 5, 2)                        # the whole row 6
table.cursor = (5, 0)
assert app.toggle_exclusion() == "excluded"
settle(4)
assert {(5, 0), (5, 1)} <= table.excluded, table.excluded
value = table.df.iat[5, 1]
assert isinstance(value, float) and abs(value - round(np.cos(3.0), 8)) < 1e-9, value
shown = [label.cget("text") for label in table._excluded_labels
         if label.winfo_ismapped()]
assert f"#{value}" in shown, shown
assert not any(text.startswith("##") for text in shown), shown
# a formula that is not left out still cannot read a left out cell
assert table.df.iat[6, 2] == "#N/A", table.df.iat[6, 2]
# ... and the diagrams go without the row
assert np.isnan(table.analysis_frame().iat[5, 1])
# the button again takes the row back in
assert app.toggle_exclusion() == "included"
settle(2)
assert table.df.iat[6, 2] == 6
print("a whole row left out keeps the numbers of its formulas ok")

# -- 3. the X scale below and above the plot area -----------------------------
app.table.set_dataframe(pd.DataFrame({"X": x, "Y": x ** 2}), check_all=True)
settle(6)
table = app.table
assert table.column_axis("X") == "B"
top_box = table.axis_check("X", "T")
top_box.invoke()                                  # tick x_T as well
settle(2)
assert table.column_axis("X") == "BT", table.column_axis("X")
assert table.plot_layout()["x_side"] == "both"
bottom_box = table.axis_check("X", "B")
bottom_box.invoke()                               # x_B off: only the top
settle(2)
assert table.column_axis("X") == "T"
top_box.invoke()                                  # the last one stays on
settle(2)
assert table.column_axis("X") == "T"
bottom_box.invoke()
settle(2)
assert table.column_axis("X") == "BT"
# a Y column still has one axis: ticking y_R clears y_L
table.axis_check("Y", "R").invoke()
settle(2)
assert table.column_axis("Y") == "R"
table.axis_check("Y", "L").invoke()
settle(2)
assert table.column_axis("Y") == "L"
assert table.set_column_axis("Y", "LR") is False

window = app.open_plot("line")
settle(8)
assert window.x_side == "both"
ticks = [tick for tick in window.ax.xaxis.get_major_ticks()]
assert any(tick.label1.get_visible() for tick in ticks)
assert any(tick.label2.get_visible() for tick in ticks)
assert any(tick.tick2line.get_visible() for tick in ticks)
assert set(window.used_sides()) >= {"bottom", "top"}
window.canvas.draw()
box = window.ax.get_window_extent()
# both edges belong to the X axis (a double click there opens its page)
assert window.edge_axis_at(box.x0 + 20, box.y1) == "x"
assert window.edge_axis_at(box.x0 + 20, box.y0) == "x"
# the matplotlib program draws them on both sides as well
script = window.to_script()
assert "labeltop=True, labelbottom=True" in script, "labeltop missing"
# the graph keeps it: saved and opened again
path = os.path.join(HOME, "both.aplt")
document = app.project_document()
assert document["plots"][0]["x_side"] == "both"
assert document["tabs"][0]["axes"]["X"] == "BT"
app.load_document(document)
settle(8)
assert app.table.column_axis("X") == "BT"
assert app.open_windows()[0].x_side == "both"
print("the X scale on both sides ok")

assert not errors, errors
print("ALL OK")
