"""Headless test (1.5.0): `3D Surface` - x, y, z drawn as a surface in
space (ax.plot_surface) on axes of its own.  Dragging the surface turns the
view and the curve dialog shows the two angles; an axis is selected by a
click on its line and made longer or shorter by its ends; the three labels
are dragged, written in place and opened by a double click like the labels
of any other diagram; the colour bar is off to begin with and there to be
switched on; the view is kept by Undo, by a saved diagram and by the
exported program.  And a diagram that opens with a flat surface - colour
surface, contour lines, filled contours - has `Frame with ticks (outward)`.
"""
import math, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from matplotlib.backend_bases import MouseEvent

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def close_all():
    for window in app.open_windows():
        window.destroy()
    settle(2)


def near(a, b, tol=1e-6):
    return all(math.isclose(p, q, abs_tol=tol) for p, q in zip(a, b))


def mouse(plot, name, x, y, dblclick=False):
    event = MouseEvent(name, plot.canvas, x, y, button=1, dblclick=dblclick)
    {"button_press_event": plot._on_button_press,
     "motion_notify_event": plot._on_motion,
     "button_release_event": plot._on_release}[name](event)


def click(plot, x, y, dblclick=False):
    mouse(plot, "button_press_event", x, y, dblclick)
    mouse(plot, "button_release_event", x, y)
    settle(2)


def drag(plot, start, end, steps=5):
    mouse(plot, "button_press_event", *start)
    for step in range(1, steps + 1):
        mouse(plot, "motion_notify_event",
              start[0] + (end[0] - start[0]) * step / steps,
              start[1] + (end[1] - start[1]) * step / steps)
    mouse(plot, "button_release_event", *end)
    settle(2)


def fresh(plot):
    plot.canvas.draw()
    settle(1)


def box_middle(plot):
    fresh(plot)
    corners = plot.box3d_corners()
    return (sum(x for x, _y in corners) / len(corners),
            sum(y for _x, y in corners) / len(corners))


def axis_middle(plot, name):
    fresh(plot)
    first, second = plot.axis3d_ends(name)
    return (0.5 * (first[0] + second[0]), 0.5 * (first[1] + second[1]))


def axis_length(plot, name):
    fresh(plot)
    first, second = plot.axis3d_ends(name)
    return math.hypot(second[0] - first[0], second[1] - first[1])


def corners(surface):
    """The corners of every cell of a drawn surface: three rows, x, y, z.
    (matplotlib keeps them under another name since 3.11.)"""
    if hasattr(surface, "_vec"):
        return np.asarray(surface._vec, float)[:3]
    faces = np.array(np.ma.filled(np.ma.asarray(surface._faces, dtype=float),
                                  np.nan))
    unused = np.broadcast_to(np.asarray(surface._invalid_vertices, bool),
                             faces.shape[:2])
    faces[unused] = np.nan
    return faces.reshape(-1, 3).T


def label_middle(plot, name):
    fresh(plot)
    box = plot.text_artist(name).get_window_extent(plot._renderer())
    return (0.5 * (box.x0 + box.x1), 0.5 * (box.y0 + box.y1))


xs, ys = np.linspace(-3.0, 3.0, 25), np.linspace(-2.0, 2.0, 17)
gx, gy = np.meshgrid(xs, ys, indexing="ij")
zs = 10.0 * np.exp(-(gx.ravel() ** 2 + gy.ravel() ** 2) / 2.0)
grid = pd.DataFrame({"x": gx.ravel(), "y": gy.ravel(), "height": zs})

# -- 1. the style is there, and draws a surface in space -----------------------
assert "surface3d" in [code for _label, code, *_rest in aplot.PLOT_STYLES]
assert "surface3d" in aplot.SURFACE_STYLES
assert "surface3d" in aplot.PLOT_ICON_PAINTERS
app.table.set_dataframe(grid, check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)
assert plot.is_3d() and plot.ax3d is not None
assert plot.ax3d.name == "3d"
assert not plot.ax.axison, "the flat axes are not drawn"
main = plot.surface_artists["y"][0]
assert main.axes is plot.ax3d and type(main).__name__ == "Poly3DCollection"
assert "y" not in plot.hist2d_bars, "no colour bar to begin with"
assert plot.surface_cfg["y"]["colorbar"] is False
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -60.0))
fresh(plot)
# the axes in space lie over the plot area and carry its ranges and labels
flat, space = plot.ax.get_window_extent(), plot.ax3d.get_window_extent()
assert flat.x0 - 1 <= space.x0 and space.x1 <= flat.x1 + 1
assert flat.y0 - 1 <= space.y0 and space.y1 <= flat.y1 + 1
assert near(plot.ax3d.get_xlim(), (-3.0, 3.0)) and near(plot.ax3d.get_ylim(), (-2.0, 2.0))
assert near(plot.ax3d.get_zlim(), (0.0, 10.0)), plot.ax3d.get_zlim()
assert plot.text_artist("x").get_text() == "x"
assert plot.text_artist("y").get_text() == "y"
assert plot.text_artist("z").get_text() == "height"
assert plot.text_artist("x") is plot.ax3d.xaxis.label
print("a surface in space is drawn on axes of its own ok")

# -- 2. dragging the surface turns it; the dialog shows the angles -------------
dialog = plot.open_series_dialog(plot.series["y"])
settle(6)
assert dialog.surface3d_box.winfo_manager(), "the 3D section is shown"
assert not dialog.pcolor_box.winfo_manager() and not dialog.contour_box.winfo_manager()
assert dialog.v3_elev_var.get() == "30" and dialog.v3_azim_var.get() == "-60"
assert not dialog.sf_bar_var.get()
here = box_middle(plot)
assert plot.in_3d_box(*here) and plot.series_at(
    MouseEvent("button_press_event", plot.canvas, *here, button=1)) == "y"
box = plot.frame_cfg.copy()
drag(plot, here, (here[0] + 60, here[1] + 40))
view = (plot.view3d["elev"], plot.view3d["azim"])
assert view[0] < 30.0 and view[1] < -60.0, view
assert view[0] == round(view[0]) and view[1] == round(view[1]), view
assert plot.frame_cfg == box, "the graph itself was not moved"
fresh(plot)
assert near((plot.ax3d.elev, plot.ax3d.azim), view)
assert dialog.v3_elev_var.get() == aplot.field_number(view[0]), dialog.v3_elev_var.get()
assert dialog.v3_azim_var.get() == aplot.field_number(view[1]), dialog.v3_azim_var.get()
# a click that does not move turns nothing
click(plot, *box_middle(plot))
assert (plot.view3d["elev"], plot.view3d["azim"]) == view
# Undo takes the turn back, Redo does it again
app.undo_step()
settle(4)
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -60.0)), plot.view3d
assert dialog.v3_elev_var.get() == "30"
app.redo_step()
settle(4)
assert near((plot.view3d["elev"], plot.view3d["azim"]), view)
# the angles typed into the dialog turn the surface
dialog.v3_elev_var.set("45")
dialog.v3_azim_var.set("20")
settle(4)
assert near((plot.view3d["elev"], plot.view3d["azim"]), (45.0, 20.0))
fresh(plot)
assert near((plot.ax3d.elev, plot.ax3d.azim), (45.0, 20.0))
dialog.v3_elev_var.set("-")                 # half typed: nothing happens
settle(2)
assert plot.view3d["elev"] == 45.0
dialog.v3_elev_var.set("30")
dialog.v3_azim_var.set("-60")
settle(4)
print("the pointer and the dialog turn the view ok")

# -- 3. an axis is selected by its line and stretched by its ends --------------
plot.select_object(None, None)
for name in ("x", "y", "z"):
    spot = axis_middle(plot, name)
    assert plot.axis3d_at(*spot) == name, (name, plot.axis3d_at(*spot))
    assert plot.object_at(*spot) == ("axis3d", name)
    click(plot, *spot)
    assert plot.selection == ("axis3d", name), plot.selection
    assert len(plot.selected_handle_positions()) == 2
click(plot, *axis_middle(plot, "x"))
assert plot.selection == ("axis3d", "x")
before = plot.view3d_box()
assert near(before, (4.0, 4.0, 3.0))
long_before = axis_length(plot, "x")
ends = plot.axis3d_ends("x")
handle = tuple(plot.ax.transAxes.transform(plot.selected_handle_positions()[1]))
assert near(handle, ends[1], 1.0), (handle, ends)
away = (ends[1][0] + 0.5 * (ends[1][0] - ends[0][0]),
        ends[1][1] + 0.5 * (ends[1][1] - ends[0][1]))
drag(plot, handle, away)
after = plot.view3d_box()
assert math.isclose(after[0], 6.0, rel_tol=0.03), after
assert near(after[1:], before[1:]), after
assert axis_length(plot, "x") > long_before + 3.0
assert plot.selection == ("axis3d", "x")
# the control points stand on the ends of the line as it is drawn now
fresh(plot)
handle = tuple(plot.ax.transAxes.transform(plot.selected_handle_positions()[0]))
assert near(handle, plot.axis3d_ends("x")[0], 1.0)
assert [one.get() for one in dialog.v3_box_vars] == [
    aplot.field_number(one) for one in after], [one.get() for one in dialog.v3_box_vars]
# pushed back in: shorter again
ends = plot.axis3d_ends("x")
handle = tuple(plot.ax.transAxes.transform(plot.selected_handle_positions()[1]))
drag(plot, handle, (0.5 * (ends[0][0] + ends[1][0]), 0.5 * (ends[0][1] + ends[1][1])))
assert math.isclose(plot.view3d_box()[0], 0.5 * after[0], rel_tol=0.05), plot.view3d_box()
app.undo_step()
settle(4)
assert near(plot.view3d_box(), after, 1e-6), plot.view3d_box()
# dragging the line itself carries the whole graph
spot = axis_middle(plot, "y")
left = plot.frame_cfg["left"]
drag(plot, spot, (spot[0] + 40, spot[1]))
assert plot.frame_cfg["left"] > left + 0.01, (left, plot.frame_cfg["left"])
assert near(plot.view3d_box(), after, 1e-6)
# the lengths typed into the dialog
dialog.v3_box_vars[2].set("2")
settle(4)
assert plot.view3d_box()[2] == 2.0
# a double click on an axis opens the page of that axis
plot.select_object(None, None)
click(plot, *axis_middle(plot, "x"), dblclick=True)
settle(4)
assert plot._dialogs.get("axes") is not None and plot._dialogs["axes"].winfo_exists()
plot._dialogs["axes"].close()
settle(2)
print("an axis in space is selected, stretched and carries the graph ok")

# -- 4. the labels: dragged, written in place, opened by a double click --------
plot.select_object(None, None)
for name in ("x", "y", "z"):
    spot = label_middle(plot, name)
    assert plot.text_at(*spot) == name, (name, plot.text_at(*spot))
    assert plot.object_at(*spot) == ("text", name)
    click(plot, *spot)
    assert plot.selection == ("text", name) and plot.is_marked()
    assert near(plot.text_offset[name], (0.0, 0.0)), "a click moves nothing"
    drag(plot, spot, (spot[0] + 25, spot[1] - 15))
    assert near(plot.text_offset[name], (plot.points(25), plot.points(-15))), (
        name, plot.text_offset[name])
    there = label_middle(plot, name)
    assert near(there, (spot[0] + 25, spot[1] - 15), 2.0), (name, spot, there)
    assert plot.text_at(*there) == name
# the label goes on following its axis when the view is turned
plot.set_view3d(azim=-30)
plot.draw()
moved = label_middle(plot, "z")
assert not near(moved, there, 2.0)
assert near(plot.text_offset["z"], (plot.points(25), plot.points(-15)))
# a slow second click writes the label of the Z axis in place
plot.select_object(None, None)
spot = label_middle(plot, "z")
click(plot, *spot)
time.sleep(0.45)
click(plot, *spot)
assert plot.is_editing_inline(), "the slow second click opens the editor"
editor = plot._inline["editor"]
assert editor.get("1.0", "end-1c") == "height"
editor.delete("1.0", "end")
editor.insert("1.0", "Field [V/m]")
plot.commit_inline_edit()
settle(4)
fresh(plot)
assert plot.axis_cfg["z"]["label"] == "Field [V/m]"
assert plot.text_artist("z").get_text() == "Field [V/m]"
# ... and the X label, which is the X label of the axes page
plot.set_text_value("text", "x", "Position [mm]")
plot.draw()
fresh(plot)
assert plot.text_artist("x").get_text() == "Position [mm]"
assert plot.axis_label("x") == "Position [mm]"
# a double click opens the window of the label
spot = label_middle(plot, "z")
click(plot, *spot)
mouse(plot, "button_press_event", *spot, dblclick=True)
mouse(plot, "button_release_event", *spot)
settle(4)
window = plot._dialogs.get("label-z")
assert isinstance(window, aplot.TextStyleDialog), list(plot._dialogs)
window.size_var.set("17")
window.apply()
settle(4)
fresh(plot)
assert round(plot.text_artist("z").get_fontsize()) == 17
window.close()
# `Reset dragged texts` puts all three back
plot.reset_text_offsets()
settle(2)
assert all(near(plot.text_offset[name], (0.0, 0.0)) for name in ("x", "y", "z"))
print("the labels of the axes in space are dragged and written ok")

# -- 5. the Z axis, the colour bar and the colour scale ------------------------
plot.apply_axis("z", {**plot.axis_cfg["z"], "auto": False, "min": -5.0, "max": 20.0})
fresh(plot)
assert near(plot.ax3d.get_zlim(), (-5.0, 20.0)), plot.ax3d.get_zlim()
plot.apply_axis("z", {**plot.axis_cfg["z"], "auto": True})
fresh(plot)
assert near(plot.ax3d.get_zlim(), (0.0, 10.0)), plot.ax3d.get_zlim()
# the settings 1.5.0 and 1.5.1 kept with the view still reach the Z axis
plot.set_view3d(zmin=-2, zmax=12)
fresh(plot)
assert near(plot.ax3d.get_zlim(), (-2.0, 12.0)), plot.ax3d.get_zlim()
plot.set_view3d(zmin=None, zmax=None)
fresh(plot)
assert plot.axis_cfg["z"]["auto"] and near(plot.ax3d.get_zlim(), (0.0, 10.0))
dialog.sf_bar_var.set(True)
dialog._apply()
settle(4)
assert "y" in plot.hist2d_bars, "the colour bar is switched on"
assert near(plot.color_bar_box("y"), aplot.BAR_BOX_3D)
bar = plot.hist2d_bars["y"]
assert bar.mappable is plot.surface_artists["y"][0]
dialog.sf_vmin_var.set("2")
dialog.sf_vmax_var.set("8")
settle(4)
norm = plot.hist2d_bars["y"].mappable.norm
assert near((norm.vmin, norm.vmax), (2.0, 8.0))
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -30.0))
dialog.sf_edges_var.set(True)
dialog._apply()
settle(4)
assert plot.surface_cfg["y"]["edges"] is True
print("the Z axis, the colour bar and the colour scale ok")

# -- 6. the exported program and the saved diagram -----------------------------
script = plot.to_script()
compile(script, "exported", "exec")
assert "projection='3d'" in script and "ax3d.plot_surface(" in script
assert "ax3d.view_init(elev=30.0, azim=-30.0)" in script, [
    line for line in script.splitlines() if "view_init" in line]
assert "ax3d.set_zlabel('Field [V/m]'" in script
assert "ax3d.set_xlabel('Position [mm]'" in script
assert "fig.colorbar(surf_s1" in script
document = app.plot_document(plot)
text = repr(document)
assert "view3d" in text and "surface3d" in text
plot.set_view3d(elev=10, azim=10, box=[1, 1, 1])
plot.draw()
app.apply_plot_document(document)
settle(6)
plot = app.open_windows()[-1]
assert plot.is_3d() and plot.ax3d is not None
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -30.0)), plot.view3d
assert plot.axis_cfg["z"]["label"] == "Field [V/m]"
assert plot.axis_cfg["z"]["label_size"] == 17
assert "y" in plot.hist2d_bars
print("the exported program and the saved diagram keep the view ok")

# -- 7. to a flat surface and back: the axes follow the style ------------------
dialog = plot.open_series_dialog(plot.series["y"])
settle(6)
dialog.plot_style_var.set(aplot.name_of(aplot.PLOT_STYLES, "pcolor", None))
dialog._on_style_changed()
settle(6)
assert not plot.is_3d() and plot.ax3d is None
assert plot.ax.axison, "the flat axes are back"
assert plot.surface_artists["y"][0].axes is plot.ax
assert dialog.pcolor_box.winfo_manager() and not dialog.surface3d_box.winfo_manager()
fresh(plot)
assert plot.text_artist("x") is plot.ax.xaxis.label
assert plot.text_at(*label_middle(plot, "x")) == "x"
dialog.plot_style_var.set(aplot.name_of(aplot.PLOT_STYLES, "surface3d", None))
dialog._on_style_changed()
settle(6)
assert plot.is_3d() and plot.ax3d is not None and not plot.ax.axison
assert plot.surface_artists["y"][0].axes is plot.ax3d
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -30.0))
close_all()
print("a surface changes between flat and space ok")

# -- 8. points scattered freely are joined into triangles ----------------------
rng = np.random.default_rng(5)
px, py = rng.uniform(-3, 3, 200), rng.uniform(-2, 2, 200)
cloud = pd.DataFrame({"x": px, "y": py, "z": np.sin(px) * np.cos(py)})
app.table.set_dataframe(cloud, check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)
assert plot.ax3d is not None and len(plot.surface_artists["y"]) == 1
script = plot.to_script()
compile(script, "exported", "exec")
assert "ax3d.plot_trisurf(" in script
close_all()
print("scattered points are drawn as a surface of triangles ok")

# -- 8b. the surface is cut at the ends of the axes; the Z page; the numbers;
#        the frame (1.5.1) ------------------------------------------------------
app.table.set_dataframe(grid, check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)
fresh(plot)


def reach(plot):
    """How far the surface reaches along the three axes."""
    xs, ys, zs = (np.asarray(one, float)
                  for one in corners(plot.surface_artists["y"][0])[:3])
    return [(float(np.nanmin(one)), float(np.nanmax(one)))
            for one in (xs, ys, zs)]


whole = reach(plot)
assert near(whole[0], (-3.0, 3.0)) and near(whole[1], (-2.0, 2.0)), whole
assert plot.surface_artists["y"][0].aplot_clip == (
    (-3.0, 3.0), (-2.0, 2.0), (0.0, 10.0))
# a range made smaller than the data: nothing hangs out of the box
plot.apply_axis("x", {**plot.axis_cfg["x"], "auto": False, "min": -1.0, "max": 1.5})
plot.apply_axis("y", {**plot.axis_cfg["y"], "auto": False, "min": -1.0, "max": 1.0})
plot.draw()
fresh(plot)
assert near(plot.ax3d.get_xlim(), (-1.0, 1.5)) and near(plot.ax3d.get_ylim(), (-1.0, 1.0))
cut = reach(plot)
assert -1.0 - 1e-9 <= cut[0][0] and cut[0][1] <= 1.5 + 1e-9, cut
assert -1.0 - 1e-9 <= cut[1][0] and cut[1][1] <= 1.0 + 1e-9, cut
assert cut[0][1] - cut[0][0] > 2.0 and cut[1][1] - cut[1][0] > 1.7, cut
# the Z axis has a page of its own in `Axes properties`
dialog = plot.open_axes_dialog("z")
settle(6)
assert isinstance(dialog.z_tab, aplot.AxisTab) and dialog.z_tab.which == "z"
assert [dialog.notebook.tab(one, "text") for one in dialog.notebook.tabs()] == [
    "Title and fonts", "X axis", "Left Y axis", "Z axis", "Right Y axis",
    "Frame and origin"]
assert dialog.notebook.tab(dialog.notebook.select(), "text") == "Z axis"
page = dialog.z_tab
assert page.auto_var.get() and page.label_var.get() == "height"
assert (page.min_var.get(), page.max_var.get()) == ("0", "10")
page.auto_var.set(False)
page._toggle_auto()
page.min_var.set("0")
page.max_var.set("4")
page.step_var.set("0.5")
page.label_var.set("Height [m]")
page.tick_size_var.set("9")
assert dialog.apply()
settle(6)
fresh(plot)
assert near(plot.ax3d.get_zlim(), (0.0, 4.0)), plot.ax3d.get_zlim()
cfg = plot.axis_cfg["z"]
assert not cfg["auto"] and (cfg["min"], cfg["max"]) == (0.0, 4.0), cfg
assert cfg["step"] == 0.5 and cfg["tick_size"] == 9, cfg
assert cfg["label"] == "Height [m]"
assert plot.text_artist("z").get_text() == "Height [m]"
assert round(plot.ax3d.zaxis.get_major_ticks()[0].label1.get_fontsize()) == 9
ticks = [t for t in plot.ax3d.get_zticks() if 0.0 <= t <= 4.0]
assert near(ticks, np.arange(0.0, 4.01, 0.5)), ticks
cut = reach(plot)
assert cut[2][1] <= 4.0 + 1e-9, cut            # the top of the hill is cut off
# the X and Y ranges set there were kept by the same Apply
assert near(plot.ax3d.get_xlim(), (-1.0, 1.5))
# Undo takes the whole Apply back
app.undo_step()
settle(6)
fresh(plot)
assert plot.axis_cfg["z"]["auto"] and near(plot.ax3d.get_zlim(), (0.0, 10.0))
app.redo_step()
settle(6)
fresh(plot)
assert near(plot.ax3d.get_zlim(), (0.0, 4.0))
# the page of the Z axis is the page every axis has (1.5.2): each of its
# settings acts on the axis in space
for name in ("label_var", "label_size_var", "label_color", "label_pad_var",
             "tick_size_var", "tick_color", "tick_pad_var", "auto_var",
             "ends_var", "min_var", "max_var", "step_var", "minor_var",
             "axis_color", "label_on_var", "ticks_on_var",
             "tick_labels_on_var", "gmajor_var", "gstyle_var", "gwidth_var",
             "grid_color", "direction_var", "scale_var"):
    assert hasattr(page, name) and hasattr(dialog.tabs["x"], name), name
assert str(page.scale_box.cget("state")) == "readonly", \
    "an axis in space can be a logarithmic one (1.6.0)"
assert page.gmajor_var.get(), "a box in space opens with its net"
page.axis_color.set_color("#cc0000")
page.label_color.set_color("#0000cc")
page.label_pad_var.set("30")
page.gmajor_var.set(False)
page.direction_var.set("Reverse")
assert dialog.apply()
settle(6)
fresh(plot)
cfg = plot.axis_cfg["z"]
assert cfg["axis_color"] == "#cc0000" and cfg["direction"] == "reverse"
assert aplot.to_hex(plot.ax3d.zaxis.line.get_color()) == "#cc0000"
assert aplot.to_hex(plot.ax3d.zaxis.label.get_color()) == "#0000cc"
assert near(plot.ax3d.get_zlim(), (4.0, 0.0)), plot.ax3d.get_zlim()
assert (page.min_var.get(), page.max_var.get()) == ("4", "0")
assert plot.ax3d.zaxis._axinfo["grid"]["linewidth"] == 0.0
assert plot.ax3d.xaxis._axinfo["grid"]["linewidth"] > 0.0
assert math.isclose(plot.ax3d.zaxis.labelpad, plot.page_points(30.0))
# no numbers, no label, then no axis at all
page.direction_var.set("Standard")
page.tick_labels_on_var.set(False)
page.label_on_var.set(False)
assert dialog.apply()
settle(6)
fresh(plot)
assert near(plot.ax3d.get_zlim(), (0.0, 4.0))
assert plot.text_artist("z").get_text() == "" and plot.text_at(0, 0) != "z"
assert not any(one.label1.get_visible() for one in plot.ax3d.zaxis.get_major_ticks())
assert plot.ax3d.zaxis._axinfo["tick"]["linewidth"][True] > 0.0
page.direction_var.set("No Z axis")
assert dialog.apply()
settle(6)
fresh(plot)
assert not plot.ax3d.zaxis.line.get_visible()
assert plot.ax3d.zaxis._axinfo["tick"]["linewidth"][True] == 0.0
page.direction_var.set("Standard")
page.tick_labels_on_var.set(True)
page.label_on_var.set(True)
page.gmajor_var.set(True)
assert dialog.apply()
settle(6)
fresh(plot)
assert plot.ax3d.zaxis.line.get_visible()
assert plot.text_artist("z").get_text() == "Height [m]"
# the X page acts on the axis in space as well
tab = dialog.tabs["x"]
tab.gmajor_var.set(False)
tab.ticks_on_var.set(False)
assert dialog.apply()
settle(6)
fresh(plot)
assert plot.ax3d.xaxis._axinfo["grid"]["linewidth"] == 0.0
assert plot.ax3d.xaxis._axinfo["tick"]["linewidth"][True] == 0.0
assert not any(one.label1.get_visible() for one in plot.ax3d.xaxis.get_major_ticks())
tab.gmajor_var.set(True)
tab.ticks_on_var.set(True)
assert dialog.apply()
settle(6)
fresh(plot)
# a double click on the numbers of an axis opens the page of that axis
plot._dialogs["axes"].close()
settle(2)
renderer = plot._renderer()
for name, words in (("x", "X axis"), ("y", "Left Y axis"), ("z", "Z axis")):
    axis = getattr(plot.ax3d, f"{name}axis")
    low, high = sorted(axis.get_view_interval())
    inside = [t for t in axis.get_major_ticks() if low <= t.get_loc() <= high]
    box = inside[1].label1.get_window_extent(renderer)
    spot = (0.5 * (box.x0 + box.x1), 0.5 * (box.y0 + box.y1))
    assert plot.numbers3d_at(*spot) == name, (name, plot.numbers3d_at(*spot))
    mouse(plot, "button_press_event", *spot, dblclick=True)
    mouse(plot, "button_release_event", *spot)
    settle(4)
    dialog = plot._dialogs.get("axes")
    assert dialog is not None and dialog.winfo_exists(), name
    assert dialog.notebook.tab(dialog.notebook.select(), "text") == words, name
    # ... and a single press on them carries the graph
    left = plot.frame_cfg["left"]
    drag(plot, spot, (spot[0] + 30, spot[1]))
    assert plot.frame_cfg["left"] > left + 0.005, name
    fresh(plot)
    renderer = plot._renderer()
# the frame style acts on the box
assert plot.frame_cfg["style"] == "box"
assert plot.ax3d.xaxis.pane.get_visible()
before = dict(plot.ax3d.xaxis._axinfo["tick"])
dialog.frame_tab.style_var.set(aplot.name_of(aplot.FRAME_STYLES, "none", None))
assert dialog.apply()
settle(4)
assert not plot.ax3d.xaxis.pane.get_visible(), "no frame: no walls"
dialog.frame_tab.style_var.set(aplot.name_of(aplot.FRAME_STYLES, "box_out", None))
assert dialog.apply()
settle(4)
assert plot.ax3d.zaxis.pane.get_visible()
out = dict(plot.ax3d.xaxis._axinfo["tick"])
dialog.frame_tab.style_var.set(aplot.name_of(aplot.FRAME_STYLES, "box_in", None))
assert dialog.apply()
settle(4)
into = dict(plot.ax3d.xaxis._axinfo["tick"])
assert (into["inward_factor"], into["outward_factor"]) != (
    out["inward_factor"], out["outward_factor"])
assert (out["inward_factor"] > 0) != (into["inward_factor"] > 0)
assert (before["inward_factor"] > 0) and (before["outward_factor"] > 0)
# saved and opened again: the Z axis comes back as it was set
plot.apply_axis("z", {**plot.axis_cfg["z"], "auto": False, "min": 1.0,
                      "max": 6.0, "direction": "reverse", "tick_size": 9})
document = app.plot_document(plot)
plot.apply_axis("z", {**plot.default_z_cfg()})
app.apply_plot_document(document)
settle(6)
plot = app.open_windows()[-1]
fresh(plot)
cfg = plot.axis_cfg["z"]
assert (cfg["auto"], cfg["min"], cfg["max"], cfg["direction"]) == (
    False, 1.0, 6.0, "reverse"), cfg
assert near(plot.ax3d.get_zlim(), (6.0, 1.0)), plot.ax3d.get_zlim()
assert cfg["label"] == "Height [m]" and cfg["tick_size"] == 9
plot.apply_axis("z", {**plot.axis_cfg["z"], "direction": "standard"})
dialog = plot.open_axes_dialog("frame")
settle(4)
# back to a flat surface: the Z page goes away
series = plot.open_series_dialog(plot.series["y"])
settle(6)
series.plot_style_var.set(aplot.name_of(aplot.PLOT_STYLES, "pcolor", None))
series._on_style_changed()
settle(6)
dialog = plot.open_axes_dialog("x")
settle(4)
assert dialog.z_tab is None
close_all()
print("the surface is cut at the axes; the Z page, the numbers, the frame ok")

# -- 8c. shading: flat, smooth, and light and shadow (1.5.2) --------------------
coarse_x, coarse_y = np.linspace(-3.0, 3.0, 13), np.linspace(-2.0, 2.0, 9)
cx, cy = np.meshgrid(coarse_x, coarse_y, indexing="ij")
coarse = pd.DataFrame({"x": cx.ravel(), "y": cy.ravel(),
                       "height": 10.0 * np.exp(-(cx.ravel() ** 2 + cy.ravel() ** 2) / 2.0)})
app.table.set_dataframe(coarse, check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)
fresh(plot)


def cells(plot):
    return corners(plot.surface_artists["y"][0]).shape[1] // 4


flat_cells = cells(plot)
assert flat_cells == 12 * 8, flat_cells
dialog = plot.open_series_dialog(plot.series["y"])
settle(6)
assert not hasattr(dialog, "v3_zmin_var"), "the Z axis has its own page now"
assert dialog.sf_shading_var.get() == aplot.name_of(aplot.SURFACE_SHADINGS, "flat", None)
assert not dialog.sf_light_var.get()
dialog.sf_shading_var.set(aplot.name_of(aplot.SURFACE_SHADINGS, "smooth", None))
dialog._apply()
settle(6)
fresh(plot)
assert plot.surface_cfg["y"]["shading"] == "smooth"
assert cells(plot) == (12 * 4) * (8 * 4), cells(plot)     # four times finer
main = plot.surface_artists["y"][0]
assert main.get_array() is not None, "coloured by its height"
dialog.sf_bar_var.set(True)
dialog.sf_light_var.set(True)
dialog._apply()
settle(6)
fresh(plot)
assert plot.surface_cfg["y"]["light"] is True
main = plot.surface_artists["y"][0]
assert main.get_array() is None, "every cell carries a colour of its own"
faces = np.asarray(main.get_facecolor())
assert len(np.unique(np.round(faces[:, :3], 3), axis=0)) > 100
bar = plot.hist2d_bars["y"]
assert near((bar.mappable.norm.vmin, bar.mappable.norm.vmax), (plot.surface_plan("y")["low"],
                                                                plot.surface_plan("y")["high"]))
script = plot.to_script()
compile(script, "exported", "exec")
assert "LightSource(azdeg=315, altdeg=45)" in script and "ScalarMappable(" in script
assert "fig.colorbar(map_s1" in script and "np.interp(" in script
# back to flat without light
dialog.sf_light_var.set(False)
dialog.sf_shading_var.set(aplot.name_of(aplot.SURFACE_SHADINGS, "flat", None))
dialog._apply()
settle(6)
fresh(plot)
assert cells(plot) == flat_cells and plot.surface_artists["y"][0].get_array() is not None
close_all()
print("flat, smooth, and light and shadow ok")

# -- 8d. the copied picture holds the three labels whole (1.5.3) ----------------
app.table.set_dataframe(grid.rename(columns={"height": "the height of it"}),
                        check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)


def labels_inside(plot, where):
    """The picture `Copy figure` cuts out holds every label whole."""
    from PIL import Image
    path = plot.figure_image(dpi=100)
    fresh(plot)
    renderer = plot._renderer()
    cut = plot.fig.get_tightbbox(renderer)                  # in inches
    dpi = float(plot.fig.dpi)
    for name in ("x", "y", "z"):
        if not plot.text_artist(name).get_text():
            continue
        box = plot.text_artist(name).get_window_extent(renderer)
        assert cut.x0 * dpi <= box.x0 + 0.5 and box.x1 - 0.5 <= cut.x1 * dpi, \
            (where, name, cut.extents * dpi, box.extents)
        assert cut.y0 * dpi <= box.y0 + 0.5 and box.y1 - 0.5 <= cut.y1 * dpi, \
            (where, name, cut.extents * dpi, box.extents)
    with Image.open(path) as picture:
        wide, high = picture.size
    pad = 2.0 * aplot.EXPORT_PAD
    assert abs(wide - (cut.width + pad) * 100.0) <= 3, (where, wide, cut.width)
    assert abs(high - (cut.height + pad) * 100.0) <= 3, (where, high, cut.height)
    return cut


first_cut = labels_inside(plot, "as opened")
plot.text_offset["z"] = (70.0, 15.0)        # the Z label dragged far out
plot.text_offset["x"] = (0.0, -60.0)
moved_cut = labels_inside(plot, "dragged")
assert moved_cut.x1 > first_cut.x1 + 0.5 and moved_cut.y0 < first_cut.y0 - 0.5
plot.axis_cfg["z"]["label_on"] = False      # a label switched off takes no room
plot.text_offset["z"] = (0.0, 0.0)
plot.text_offset["x"] = (0.0, 0.0)
plot.sync_3d_axes()
assert labels_inside(plot, "without the Z label").x1 < first_cut.x1 - 0.05
close_all()
print("the copied picture holds the labels of the axes in space ok")

# -- 8e. minor ticks and logarithmic axes in space (1.6.0) ----------------------
assert aplot.MPL_VERSION[:2] == tuple(
    int(one) for one in aplot.matplotlib.__version__.split(".")[:2])
assert aplot.SPACE_LOG_NATIVE == (aplot.MPL_VERSION >= (3, 11))
assert aplot.SPACE_LABELS_MEASURED == (aplot.MPL_VERSION >= (3, 11))
assert aplot.version_numbers("3.11.0rc1") == (3, 11, 0)
assert aplot.version_numbers("3.9") == (3, 9)

log_x, log_y = np.logspace(-1.0, 2.0, 25), np.linspace(-2.0, 2.0, 17)
lx, ly = np.meshgrid(log_x, log_y, indexing="ij")
log_z = 1000.0 * np.exp(-((np.log10(lx.ravel()) - 0.5) ** 2
                          + ly.ravel() ** 2)) + 0.01
decades = pd.DataFrame({"x": lx.ravel(), "y": ly.ravel(), "height": log_z})


def shown_ticks(axis, major):
    """The ticks of one kind that stand inside the range of their axis."""
    low, high = sorted(axis.get_view_interval())
    air = abs(high - low) * 1e-9
    places = axis.get_majorticklocs() if major else axis.get_minorticklocs()
    ticks = axis.get_major_ticks(len(places)) if major \
        else axis.get_minor_ticks(len(places))
    return [tick for tick, place in zip(ticks, places)
            if low - air <= float(place) <= high + air]


def tick_length(tick):
    xs, ys = (np.asarray(one, float) for one in tick.tick1line.get_data())
    return float(np.hypot(xs[1] - xs[0], ys[1] - ys[0]))


def grid_lines(axis):
    return len(axis.gridlines.get_segments())


def space_axes(native):
    """Minor ticks and logarithmic axes, the way this matplotlib draws
    them itself (`native`) or the long way round."""
    kept = aplot.SPACE_LOG_NATIVE
    aplot.SPACE_LOG_NATIVE = native
    try:
        app.table.set_dataframe(decades, check_all=True)
        settle(2)
        plot = app.open_plot("surface3d")
        settle(8)
        ax3d = plot.ax3d
        # -- minor ticks on linear axes: shorter, and no net of their own
        for which, count in (("x", 4), ("y", 1), ("z", 3)):
            plot.apply_axis(which, {**plot.axis_cfg[which], "minor": count})
        plot.draw()
        fresh(plot)
        for which, count in (("x", 4), ("y", 1), ("z", 3)):
            axis = getattr(ax3d, f"{which}axis")
            majors, minors = shown_ticks(axis, True), shown_ticks(axis, False)
            assert len(minors) >= count * (len(majors) - 1) > 0, (
                which, len(majors), len(minors))
            long_one = np.median([tick_length(one) for one in majors])
            short_one = np.median([tick_length(one) for one in minors])
            ratio = plot.frame_cfg["minor_tick_length"] \
                / plot.frame_cfg["major_tick_length"]
            assert 0 < short_one < long_one, (which, short_one, long_one)
            assert abs(short_one / long_one - ratio) < 0.12, (
                which, short_one / long_one, ratio)
            assert grid_lines(axis) == len(majors), (
                which, grid_lines(axis), len(majors))
            assert all(not tick.label1.get_text() for tick in minors), which
        # `Minor grid lines` draws the net of the minor ticks as well
        grid_cfg = {**plot.axis_cfg["z"]["grid"], "minor": True}
        plot.apply_axis("z", {**plot.axis_cfg["z"], "grid": grid_cfg})
        plot.draw()
        fresh(plot)
        axis = ax3d.zaxis
        assert grid_lines(axis) == len(shown_ticks(axis, True)) \
            + len(shown_ticks(axis, False))
        plot.apply_axis("z", {**plot.axis_cfg["z"],
                              "grid": {**grid_cfg, "minor": False}})
        # no minor ticks: none are drawn
        plot.apply_axis("y", {**plot.axis_cfg["y"], "minor": 0})
        plot.draw()
        fresh(plot)
        assert len(ax3d.yaxis.get_minorticklocs()) == 0

        # -- logarithmic X and Z
        linear_colours = np.asarray(
            plot.surface_artists["y"][0].get_array(), float)
        plot.apply_axis("x", {**plot.axis_cfg["x"], "scale": "log10",
                              "minor": 8})
        plot.apply_axis("z", {**plot.axis_cfg["z"], "scale": "log10",
                              "minor": 8})
        plot.draw()
        fresh(plot)
        assert plot.axis_scale("z") == "log10" and plot.space_log("x")
        assert not plot.space_log("y")
        assert near(plot.z_limits(), (1.0, 10000.0)), plot.z_limits()
        assert near(plot.space_limits("x"), (0.1, 100.0), 1e-6)
        if native:
            assert ax3d.get_zscale() == "log" and ax3d.get_xscale() == "log"
            assert near(ax3d.get_zlim(), (1.0, 10000.0))
            assert near(ax3d.get_xlim(), (0.1, 100.0), 1e-6)
        else:
            assert ax3d.get_zscale() == "linear"
            assert near(ax3d.get_zlim(), (0.0, 4.0)), ax3d.get_zlim()
            assert near(ax3d.get_xlim(), (-1.0, 2.0), 1e-6), ax3d.get_xlim()
        assert ax3d.get_yscale() == "linear"
        # the numbers are powers of ten, standing on the decades
        z_ticks = shown_ticks(ax3d.zaxis, True)
        assert [tick.label1.get_text() for tick in z_ticks] == [
            "$\\mathdefault{10^{%d}}$" % power for power in range(5)], [
            tick.label1.get_text() for tick in z_ticks]
        assert near(plot.from_space("z", [tick.get_loc() for tick in z_ticks]),
                    [1.0, 10.0, 100.0, 1000.0, 10000.0], 1e-6)
        x_ticks = shown_ticks(ax3d.xaxis, True)
        assert near(plot.from_space("x", [tick.get_loc() for tick in x_ticks]),
                    [0.1, 1.0, 10.0, 100.0], 1e-6)
        # eight minor ticks in every decade: 2, 3 ... 9
        z_minor = plot.from_space(
            "z", [tick.get_loc() for tick in shown_ticks(ax3d.zaxis, False)])
        assert len(z_minor) == 32, len(z_minor)
        assert near(sorted(z_minor)[:8], [2, 3, 4, 5, 6, 7, 8, 9], 1e-6)
        assert tick_length(shown_ticks(ax3d.zaxis, False)[0]) \
            < tick_length(z_ticks[0])
        assert grid_lines(ax3d.zaxis) == 5 and grid_lines(ax3d.xaxis) == 4
        # the surface: where its values are, on all three axes
        surface = plot.surface_artists["y"][0]
        assert surface.aplot_space == plot.space_signature()
        xs, ys, zs = corners(surface)
        xs, zs = plot.from_space("x", xs), plot.from_space("z", zs)
        assert near((np.nanmin(xs), np.nanmax(xs)), (0.1, 100.0), 1e-6)
        assert near((np.nanmin(ys), np.nanmax(ys)), (-2.0, 2.0), 1e-6)
        assert near((np.nanmin(zs), np.nanmax(zs)),
                    (log_z.min(), log_z.max()), 1e-6), (np.nanmin(zs),
                                                        np.nanmax(zs))
        # ... and its colours count in the values, not in the logarithms
        colours = np.asarray(surface.get_array(), float)
        assert log_z.min() <= np.nanmin(colours) and \
            100.0 < np.nanmax(colours) <= log_z.max(), (
                np.nanmin(colours), np.nanmax(colours))
        assert len(colours) == len(linear_colours)
        # a range typed in cuts the surface, as on a linear axis
        plot.apply_axis("z", {**plot.axis_cfg["z"], "auto": False,
                              "min": 10.0, "max": 100.0})
        plot.draw()
        fresh(plot)
        zs = plot.from_space("z", corners(plot.surface_artists["y"][0])[2])
        assert 10.0 - 1e-6 <= np.nanmin(zs) and np.nanmax(zs) <= 100.0 + 1e-6
        # a range that reaches zero is not obeyed: it never does
        plot.apply_axis("z", {**plot.axis_cfg["z"], "auto": False,
                              "min": -5.0, "max": 1000.0})
        assert near(plot.z_limits(), (1.0, 1000.0)), plot.z_limits()
        plot.apply_axis("z", {**plot.axis_cfg["z"], "auto": True})
        # light and shadow, and the smooth shading, on logarithmic axes
        curve = plot.open_series_dialog(plot.series["y"])
        settle(6)
        curve.sf_shading_var.set(
            aplot.name_of(aplot.SURFACE_SHADINGS, "smooth", None))
        curve.sf_light_var.set(True)
        curve._apply()
        settle(6)
        fresh(plot)
        lit = plot.surface_artists["y"][0]
        zs = plot.from_space("z", corners(lit)[2])
        assert near((np.nanmax(zs),), (log_z.max(),), 1e-6)
        assert len(corners(lit)[2]) > len(corners(surface)[2]), "finer"
        script = plot.to_script()
        compile(script, "exported", "exec")
        assert "norm_s1(10.0 ** fz_s1)" in script
        curve.sf_light_var.set(False)
        curve.sf_shading_var.set(
            aplot.name_of(aplot.SURFACE_SHADINGS, "flat", None))
        curve._apply()
        curve.close()
        settle(4)
        fresh(plot)
        # the picture, the exported program and the saved diagram
        plot.figure_image(dpi=50)
        script = plot.to_script()
        compile(script, "exported", "exec")
        assert "np.log10(gx_s1[px_s1])" in script and "np.log10(gz_s1)" in script
        assert "ax3d.set_zticks([0.0, 1.0, 2.0, 3.0, 4.0])" in script
        assert "ax3d.set_zlim(0.0, 4.0)" in script
        assert "set_zscale" not in script.replace(
            "ax3d.set_zscale('log') instead", "")
        document = app.plot_document(plot)
        plot.apply_axis("z", {**plot.axis_cfg["z"], "scale": "linear"})
        plot.apply_axis("x", {**plot.axis_cfg["x"], "scale": "linear"})
        plot.draw()
        fresh(plot)
        # back on linear axes: plain numbers again, and a linear box
        assert ax3d.get_zscale() == "linear" and ax3d.get_xscale() == "linear"
        assert near(ax3d.get_xlim(), plot.ax.get_xlim())
        texts = [tick.label1.get_text()
                 for tick in shown_ticks(ax3d.zaxis, True)]
        assert texts and all("10^" not in text for text in texts), texts
        zs = corners(plot.surface_artists["y"][0])[2]
        assert near((np.nanmax(zs),), (log_z.max(),), 1e-6)
        app.apply_plot_document(document)
        settle(6)
        plot = app.open_windows()[-1]
        fresh(plot)
        assert plot.axis_scale("z") == "log10" and plot.axis_scale("x") == "log10"
        assert plot.axis_cfg["z"]["minor"] == 8
        assert near(plot.z_limits(), (1.0, 10000.0)), plot.z_limits()
        assert len(shown_ticks(plot.ax3d.zaxis, True)) == 5
        # the Z page of the dialog sets the scale like the other pages
        dialog = plot.open_axes_dialog("z")
        settle(2)
        page = dialog.tabs["z"]
        assert page.scale_code() == "log10"
        page.scale_var.set(aplot.name_of(aplot.AXIS_SCALES, "log2", None))
        page._scale_chosen()
        dialog._apply()
        settle(4)
        fresh(plot)
        assert plot.axis_scale("z") == "log2"
        texts = [tick.label1.get_text()
                 for tick in shown_ticks(plot.ax3d.zaxis, True)]
        assert texts and all("2^" in text for text in texts), texts
        dialog.close()
        close_all()

        # -- values at and below zero have no place on a logarithmic axis
        holed = decades.copy()
        holed.loc[holed.index[::7], "height"] = 0.0
        holed.loc[holed.index[3::11], "height"] = -4.0
        app.table.set_dataframe(holed, check_all=True)
        settle(2)
        plot = app.open_plot("surface3d")
        settle(8)
        plot.apply_axis("z", {**plot.axis_cfg["z"], "scale": "log10"})
        plot.draw()
        fresh(plot)
        low, high = plot.z_limits()
        assert 0 < low < high and high >= holed["height"].max(), (low, high)
        zs = plot.from_space("z", corners(plot.surface_artists["y"][0])[2])
        assert np.nanmin(zs) > 0
        close_all()

        # -- scattered points on logarithmic axes
        rng = np.random.default_rng(3)
        px = 10.0 ** rng.uniform(-1.0, 2.0, 80)
        py = rng.uniform(-2.0, 2.0, 80)
        pz = 1000.0 * np.exp(-((np.log10(px) - 0.5) ** 2 + py ** 2)) + 0.01
        app.table.set_dataframe(pd.DataFrame({"x": px, "y": py, "height": pz}),
                                check_all=True)
        settle(2)
        plot = app.open_plot("surface3d")
        settle(8)
        plot.apply_axis("x", {**plot.axis_cfg["x"], "scale": "log10"})
        plot.apply_axis("z", {**plot.axis_cfg["z"], "scale": "log10"})
        plot.draw()
        fresh(plot)
        surface = plot.surface_artists["y"][0]
        zs = plot.from_space("z", corners(surface)[2])
        assert near((np.nanmax(zs),), (pz.max(),), 1e-6)
        assert np.nanmax(np.asarray(surface.get_array(), float)) > 50.0
        script = plot.to_script()
        compile(script, "exported", "exec")
        assert "sx_s1 = np.log10(sx_s1)" in script
        assert "surf_s1.set_array(10.0 ** surf_s1.get_array())" in script
        close_all()
    finally:
        aplot.SPACE_LOG_NATIVE = kept


space_axes(aplot.SPACE_LOG_NATIVE)
if aplot.SPACE_LOG_NATIVE:
    space_axes(False)       # the long way round, on a matplotlib that needs none
    print("logarithmic axes in space, drawn by matplotlib and the long way ok")
print("minor ticks and logarithmic axes in space ok")

# -- 8f. the count of the numbers, and the uncut surface (1.6.1) ---------------
app.table.set_dataframe(grid, check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)
fresh(plot)
# a plot area much wider than it is high: the flat X axis underneath is far
# longer than the X axis of the box, and would hold many more numbers
plot.apply_frame({**plot.frame_cfg, "x_length": 0.8, "y_length": 0.3})
plot.sync_3d_axes()
fresh(plot)
counts = {}
for size in (12, 11, 10):
    for name in ("x", "y", "z"):
        plot.apply_axis(name, {**plot.axis_cfg[name], "tick_size": size},
                        redraw=False)
    plot.draw()
    fresh(plot)
    for name in ("x", "y", "z"):
        axis = getattr(plot.ax3d, name + "axis")
        assert isinstance(axis.get_major_locator(), aplot.SpaceTickLocator), name
        ticks = axis.get_majorticklocs()
        assert len(ticks) - 1 <= plot.space_tick_bins(name) + 1, (name, size)
        counts[(name, size)] = len(ticks)
    # the numbers of one axis do not stand on one another
    renderer = plot.canvas.get_renderer()
    for name in ("x", "y", "z"):
        boxes = [text.get_window_extent(renderer)
                 for text in getattr(plot.ax3d, name + "axis").get_ticklabels()
                 if text.get_text() and text.get_visible()]
        for first, second in zip(boxes, boxes[1:]):
            assert not first.overlaps(second), (name, size)
for name in ("x", "y", "z"):
    assert counts[(name, 11)] <= counts[(name, 12)] + 1, (name, counts)
    assert counts[(name, 10)] < 2 * counts[(name, 12)], (name, counts)
# turning the view leaves the ticks alone
before = [list(getattr(plot.ax3d, name + "axis").get_majorticklocs())
          for name in "xyz"]
plot.set_view3d(elev=42, azim=56)
plot.draw()
fresh(plot)
assert before == [list(getattr(plot.ax3d, name + "axis").get_majorticklocs())
                  for name in "xyz"]
# an interval typed in is kept as typed
plot.apply_axis("x", {**plot.axis_cfg["x"], "auto": False, "min": -3.0,
                      "max": 3.0, "step": 1.5})
fresh(plot)
assert near(plot.ax3d.xaxis.get_majorticklocs(), (-3.0, -1.5, 0.0, 1.5, 3.0))
# the surface is not cut at the edge of the plot area
surface = plot.surface_artists["y"][0]
assert not surface.get_clip_on()
script = plot.to_script()
compile(script, "exported", "exec")
assert ".set_clip_on(False)" in script
assert tuple(int(one) for one in aplot.APP_VERSION.split(".")[:3]) >= (1, 6, 1)
close_all()
print("as many numbers as fit along an axis in space; the surface uncut ok")

# -- 8g. a double click on the numbers; the numbers slid along (1.6.2) ---------
app.table.set_dataframe(grid, check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)
plot.set_view3d(elev=19, azim=50)       # the X and the Y label are slanted
for name in ("x", "y"):
    plot.apply_axis(name, {**plot.axis_cfg[name],
                           "label": "a long label of the %s axis" % name})
plot.draw()
fresh(plot)


def number_middles(plot, name):
    """The middle of every number of one axis, in pixels."""
    fresh(plot)
    axis = getattr(plot.ax3d, name + "axis")
    low, high = sorted(axis.get_view_interval())
    renderer = plot.canvas.get_renderer()
    middles = []
    for tick in axis.get_major_ticks():
        if low - 1e-9 <= tick.get_loc() <= high + 1e-9 \
                and tick.label1.get_text():
            box = tick.label1.get_window_extent(renderer)
            middles.append(((box.x0 + box.x1) / 2, (box.y0 + box.y1) / 2))
    return middles


asked = []
kept_dialog, kept_label = plot.open_axes_dialog, plot.edit_axis_label
plot.open_axes_dialog = lambda which="x": asked.append(("axes", which))
plot.edit_axis_label = lambda name: asked.append(("label", name))
try:
    for name in ("x", "y", "z"):
        middles = number_middles(plot, name)
        assert len(middles) >= 3, (name, middles)
        for x, y in middles:
            plot.select_object(None, None)
            fresh(plot)
            del asked[:]
            mouse(plot, "button_press_event", x, y, dblclick=True)
            assert asked == [("axes", name)], (name, x, y, asked)
    # ... and the label itself still opens as a label
    for name in ("x", "y", "z"):
        plot.select_object(None, None)
        fresh(plot)
        del asked[:]
        mouse(plot, "button_press_event", *label_middle(plot, name),
              dblclick=True)
        assert asked == [("label", name)], (name, asked)
finally:
    plot.open_axes_dialog, plot.edit_axis_label = kept_dialog, kept_label
plot.select_object(None, None)

# `Parallel offset`: the numbers slide along their axis, as far as it says
ratio = plot.page_points(1.0) * plot.fig.dpi / 72.0     # pixels of one [px]
for name in ("x", "y", "z"):
    assert plot.axis_cfg[name]["tick_shift"] == 0.0
    plain = np.asarray(number_middles(plot, name))
    grows = plain[-1] - plain[0]
    grows = grows / np.hypot(*grows)
    for value in (12.0, -9.0):
        plot.apply_axis(name, {**plot.axis_cfg[name], "tick_shift": value})
        moved = np.asarray(number_middles(plot, name)) - plain
        for step in moved:
            assert near((np.hypot(*step),), (abs(value) * ratio,), 1.0), (
                name, value, step)
            assert float(step @ grows) * value > 0, (name, value, step)
            assert abs(float(step @ grows)) > 0.9 * np.hypot(*step), (
                name, value, step)
        # painted twice, they are not slid twice
        assert near(np.asarray(number_middles(plot, name)).ravel(),
                    (plain + moved).ravel(), 0.5)
    plot.apply_axis(name, {**plot.axis_cfg[name], "tick_shift": 0.0})
    assert near(np.asarray(number_middles(plot, name)).ravel(),
                plain.ravel(), 0.5), name
# the box of the dialog, the saved diagram and the exported program
dialog = plot.open_axes_dialog("y")
settle(6)
for page in (dialog.tabs["x"], dialog.tabs["y"], dialog.tabs["z"]):
    assert page.tick_shift_var.get() == "0"
    assert str(page.tick_shift_entry.cget("state")) != "disabled"
dialog.tabs["y"].tick_shift_var.set("-14")
dialog.z_tab.tick_shift_var.set("6.5")
assert dialog.apply()
settle(6)
assert plot.axis_cfg["x"]["tick_shift"] == 0.0
assert plot.axis_cfg["y"]["tick_shift"] == -14.0
assert plot.axis_cfg["z"]["tick_shift"] == 6.5
dialog.close()
script = plot.to_script()
compile(script, "exported", "exec")
assert "Parallel offset" in script
document = app.plot_document(plot)
plot.apply_axis("y", {**plot.axis_cfg["y"], "tick_shift": 0.0})
app.apply_plot_document(document)
settle(6)
plot = app.open_windows()[-1]
assert plot.axis_cfg["y"]["tick_shift"] == -14.0
assert plot.axis_cfg["z"]["tick_shift"] == 6.5
close_all()
# on a flat diagram the box is grey
plot = app.open_plot("pcolor")
settle(6)
dialog = plot.open_axes_dialog("x")
settle(4)
assert str(dialog.tabs["x"].tick_shift_entry.cget("state")) == "disabled"
dialog.close()
assert tuple(int(one) for one in aplot.APP_VERSION.split(".")[:3]) >= (1, 6, 2)
close_all()
print("the numbers of an axis in space: a double click, and slid along ok")

# -- 9. the frame a diagram opens with -----------------------------------------
app.table.set_dataframe(grid, check_all=True)
settle(2)
for style in ("pcolor", "contour", "contourf"):
    plot = app.open_plot(style)
    settle(6)
    assert plot.frame_cfg["style"] == "box_out", (style, plot.frame_cfg["style"])
    assert all(spine.get_visible() for spine in plot.ax.spines.values()), style
    close_all()
plot = app.open_plot("surface3d")           # a box in space shows its walls
settle(6)
assert plot.frame_cfg["style"] == "box", plot.frame_cfg["style"]
close_all()
usual = aplot.code_of(aplot.FRAME_STYLES, settings.get("frame", "style"), "none")
for style in ("line", "hist2d"):
    plot = app.open_plot(style)
    settle(6)
    assert plot.frame_cfg["style"] == usual, (style, plot.frame_cfg["style"])
    close_all()
print("a flat surface opens with a frame and ticks pointing outwards ok")

print("ALL OK")
