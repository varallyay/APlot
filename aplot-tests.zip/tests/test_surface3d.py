"""Headless test (1.5.0): `3D Surface` - x, y, z drawn as a surface in
space (ax.plot_surface) on axes of its own.  Dragging the surface turns the
view and the curve dialog shows the two angles; an axis is selected by a
click on its line and made longer or shorter by its ends; the three labels
are dragged, written in place and opened by a double click like the labels
of any other diagram; the colour bar is off to begin with and there to be
switched on; the view is kept by Undo, by a saved diagram and by the
exported program.  And a diagram that opens with a flat surface - colour
surface, contour lines, filled contours - has `Frame with ticks (outward)`.
"""
import math, os, sys, tempfile, time

HOME = tempfile.mkdtemp()
os.environ["HOME"] = HOME
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import tkinter as tk
import numpy as np
import pandas as pd
import aplot
from matplotlib.backend_bases import MouseEvent

aplot.messagebox.showinfo = lambda *a, **k: None
aplot.messagebox.showwarning = lambda *a, **k: None
aplot.messagebox.showerror = lambda *a, **k: None
aplot.messagebox.askyesno = lambda *a, **k: True
aplot.messagebox.askyesnocancel = lambda *a, **k: False

root = tk.Tk()
settings = aplot.Config(os.path.join(HOME, "settings.json"))
app = aplot.App(root, settings)


def settle(times=4, pause=0.03):
    for _ in range(times):
        root.update()
        time.sleep(pause)
        root.update()


def close_all():
    for window in app.open_windows():
        window.destroy()
    settle(2)


def near(a, b, tol=1e-6):
    return all(math.isclose(p, q, abs_tol=tol) for p, q in zip(a, b))


def mouse(plot, name, x, y, dblclick=False):
    event = MouseEvent(name, plot.canvas, x, y, button=1, dblclick=dblclick)
    {"button_press_event": plot._on_button_press,
     "motion_notify_event": plot._on_motion,
     "button_release_event": plot._on_release}[name](event)


def click(plot, x, y, dblclick=False):
    mouse(plot, "button_press_event", x, y, dblclick)
    mouse(plot, "button_release_event", x, y)
    settle(2)


def drag(plot, start, end, steps=5):
    mouse(plot, "button_press_event", *start)
    for step in range(1, steps + 1):
        mouse(plot, "motion_notify_event",
              start[0] + (end[0] - start[0]) * step / steps,
              start[1] + (end[1] - start[1]) * step / steps)
    mouse(plot, "button_release_event", *end)
    settle(2)


def fresh(plot):
    plot.canvas.draw()
    settle(1)


def box_middle(plot):
    fresh(plot)
    corners = plot.box3d_corners()
    return (sum(x for x, _y in corners) / len(corners),
            sum(y for _x, y in corners) / len(corners))


def axis_middle(plot, name):
    fresh(plot)
    first, second = plot.axis3d_ends(name)
    return (0.5 * (first[0] + second[0]), 0.5 * (first[1] + second[1]))


def axis_length(plot, name):
    fresh(plot)
    first, second = plot.axis3d_ends(name)
    return math.hypot(second[0] - first[0], second[1] - first[1])


def label_middle(plot, name):
    fresh(plot)
    box = plot.text_artist(name).get_window_extent(plot._renderer())
    return (0.5 * (box.x0 + box.x1), 0.5 * (box.y0 + box.y1))


xs, ys = np.linspace(-3.0, 3.0, 25), np.linspace(-2.0, 2.0, 17)
gx, gy = np.meshgrid(xs, ys, indexing="ij")
zs = 10.0 * np.exp(-(gx.ravel() ** 2 + gy.ravel() ** 2) / 2.0)
grid = pd.DataFrame({"x": gx.ravel(), "y": gy.ravel(), "height": zs})

# -- 1. the style is there, and draws a surface in space -----------------------
assert "surface3d" in [code for _label, code, *_rest in aplot.PLOT_STYLES]
assert "surface3d" in aplot.SURFACE_STYLES
assert "surface3d" in aplot.PLOT_ICON_PAINTERS
app.table.set_dataframe(grid, check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)
assert plot.is_3d() and plot.ax3d is not None
assert plot.ax3d.name == "3d"
assert not plot.ax.axison, "the flat axes are not drawn"
main = plot.surface_artists["y"][0]
assert main.axes is plot.ax3d and type(main).__name__ == "Poly3DCollection"
assert "y" not in plot.hist2d_bars, "no colour bar to begin with"
assert plot.surface_cfg["y"]["colorbar"] is False
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -60.0))
fresh(plot)
# the axes in space lie over the plot area and carry its ranges and labels
flat, space = plot.ax.get_window_extent(), plot.ax3d.get_window_extent()
assert flat.x0 - 1 <= space.x0 and space.x1 <= flat.x1 + 1
assert flat.y0 - 1 <= space.y0 and space.y1 <= flat.y1 + 1
assert near(plot.ax3d.get_xlim(), (-3.0, 3.0)) and near(plot.ax3d.get_ylim(), (-2.0, 2.0))
assert near(plot.ax3d.get_zlim(), (0.0, 10.0)), plot.ax3d.get_zlim()
assert plot.text_artist("x").get_text() == "x"
assert plot.text_artist("y").get_text() == "y"
assert plot.text_artist("z").get_text() == "height"
assert plot.text_artist("x") is plot.ax3d.xaxis.label
print("a surface in space is drawn on axes of its own ok")

# -- 2. dragging the surface turns it; the dialog shows the angles -------------
dialog = plot.open_series_dialog(plot.series["y"])
settle(6)
assert dialog.surface3d_box.winfo_manager(), "the 3D section is shown"
assert not dialog.pcolor_box.winfo_manager() and not dialog.contour_box.winfo_manager()
assert dialog.v3_elev_var.get() == "30" and dialog.v3_azim_var.get() == "-60"
assert not dialog.sf_bar_var.get()
here = box_middle(plot)
assert plot.in_3d_box(*here) and plot.series_at(
    MouseEvent("button_press_event", plot.canvas, *here, button=1)) == "y"
box = plot.frame_cfg.copy()
drag(plot, here, (here[0] + 60, here[1] + 40))
view = (plot.view3d["elev"], plot.view3d["azim"])
assert view[0] < 30.0 and view[1] < -60.0, view
assert view[0] == round(view[0]) and view[1] == round(view[1]), view
assert plot.frame_cfg == box, "the graph itself was not moved"
fresh(plot)
assert near((plot.ax3d.elev, plot.ax3d.azim), view)
assert dialog.v3_elev_var.get() == aplot.field_number(view[0]), dialog.v3_elev_var.get()
assert dialog.v3_azim_var.get() == aplot.field_number(view[1]), dialog.v3_azim_var.get()
# a click that does not move turns nothing
click(plot, *box_middle(plot))
assert (plot.view3d["elev"], plot.view3d["azim"]) == view
# Undo takes the turn back, Redo does it again
app.undo_step()
settle(4)
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -60.0)), plot.view3d
assert dialog.v3_elev_var.get() == "30"
app.redo_step()
settle(4)
assert near((plot.view3d["elev"], plot.view3d["azim"]), view)
# the angles typed into the dialog turn the surface
dialog.v3_elev_var.set("45")
dialog.v3_azim_var.set("20")
settle(4)
assert near((plot.view3d["elev"], plot.view3d["azim"]), (45.0, 20.0))
fresh(plot)
assert near((plot.ax3d.elev, plot.ax3d.azim), (45.0, 20.0))
dialog.v3_elev_var.set("-")                 # half typed: nothing happens
settle(2)
assert plot.view3d["elev"] == 45.0
dialog.v3_elev_var.set("30")
dialog.v3_azim_var.set("-60")
settle(4)
print("the pointer and the dialog turn the view ok")

# -- 3. an axis is selected by its line and stretched by its ends --------------
plot.select_object(None, None)
for name in ("x", "y", "z"):
    spot = axis_middle(plot, name)
    assert plot.axis3d_at(*spot) == name, (name, plot.axis3d_at(*spot))
    assert plot.object_at(*spot) == ("axis3d", name)
    click(plot, *spot)
    assert plot.selection == ("axis3d", name), plot.selection
    assert len(plot.selected_handle_positions()) == 2
click(plot, *axis_middle(plot, "x"))
assert plot.selection == ("axis3d", "x")
before = plot.view3d_box()
assert near(before, (4.0, 4.0, 3.0))
long_before = axis_length(plot, "x")
ends = plot.axis3d_ends("x")
handle = tuple(plot.ax.transAxes.transform(plot.selected_handle_positions()[1]))
assert near(handle, ends[1], 1.0), (handle, ends)
away = (ends[1][0] + 0.5 * (ends[1][0] - ends[0][0]),
        ends[1][1] + 0.5 * (ends[1][1] - ends[0][1]))
drag(plot, handle, away)
after = plot.view3d_box()
assert math.isclose(after[0], 6.0, rel_tol=0.03), after
assert near(after[1:], before[1:]), after
assert axis_length(plot, "x") > long_before + 3.0
assert plot.selection == ("axis3d", "x")
# the control points stand on the ends of the line as it is drawn now
fresh(plot)
handle = tuple(plot.ax.transAxes.transform(plot.selected_handle_positions()[0]))
assert near(handle, plot.axis3d_ends("x")[0], 1.0)
assert [one.get() for one in dialog.v3_box_vars] == [
    aplot.field_number(one) for one in after], [one.get() for one in dialog.v3_box_vars]
# pushed back in: shorter again
ends = plot.axis3d_ends("x")
handle = tuple(plot.ax.transAxes.transform(plot.selected_handle_positions()[1]))
drag(plot, handle, (0.5 * (ends[0][0] + ends[1][0]), 0.5 * (ends[0][1] + ends[1][1])))
assert math.isclose(plot.view3d_box()[0], 0.5 * after[0], rel_tol=0.05), plot.view3d_box()
app.undo_step()
settle(4)
assert near(plot.view3d_box(), after, 1e-6), plot.view3d_box()
# dragging the line itself carries the whole graph
spot = axis_middle(plot, "y")
left = plot.frame_cfg["left"]
drag(plot, spot, (spot[0] + 40, spot[1]))
assert plot.frame_cfg["left"] > left + 0.01, (left, plot.frame_cfg["left"])
assert near(plot.view3d_box(), after, 1e-6)
# the lengths typed into the dialog
dialog.v3_box_vars[2].set("2")
settle(4)
assert plot.view3d_box()[2] == 2.0
# a double click on an axis: X and Y open their page, Z the curve
plot.select_object(None, None)
click(plot, *axis_middle(plot, "x"), dblclick=True)
settle(4)
assert plot._dialogs.get("axes") is not None and plot._dialogs["axes"].winfo_exists()
plot._dialogs["axes"].close()
settle(2)
print("an axis in space is selected, stretched and carries the graph ok")

# -- 4. the labels: dragged, written in place, opened by a double click --------
plot.select_object(None, None)
for name in ("x", "y", "z"):
    spot = label_middle(plot, name)
    assert plot.text_at(*spot) == name, (name, plot.text_at(*spot))
    assert plot.object_at(*spot) == ("text", name)
    click(plot, *spot)
    assert plot.selection == ("text", name) and plot.is_marked()
    assert near(plot.text_offset[name], (0.0, 0.0)), "a click moves nothing"
    drag(plot, spot, (spot[0] + 25, spot[1] - 15))
    assert near(plot.text_offset[name], (plot.points(25), plot.points(-15))), (
        name, plot.text_offset[name])
    there = label_middle(plot, name)
    assert near(there, (spot[0] + 25, spot[1] - 15), 2.0), (name, spot, there)
    assert plot.text_at(*there) == name
# the label goes on following its axis when the view is turned
plot.set_view3d(azim=-30)
plot.draw()
moved = label_middle(plot, "z")
assert not near(moved, there, 2.0)
assert near(plot.text_offset["z"], (plot.points(25), plot.points(-15)))
# a slow second click writes the label of the Z axis in place
plot.select_object(None, None)
spot = label_middle(plot, "z")
click(plot, *spot)
time.sleep(0.45)
click(plot, *spot)
assert plot.is_editing_inline(), "the slow second click opens the editor"
editor = plot._inline["editor"]
assert editor.get("1.0", "end-1c") == "height"
editor.delete("1.0", "end")
editor.insert("1.0", "Field [V/m]")
plot.commit_inline_edit()
settle(4)
fresh(plot)
assert plot.view3d["zlabel"] == "Field [V/m]"
assert plot.text_artist("z").get_text() == "Field [V/m]"
assert dialog.v3_zlabel_var.get() == "Field [V/m]", dialog.v3_zlabel_var.get()
# ... and the X label, which is the X label of the axes page
plot.set_text_value("text", "x", "Position [mm]")
plot.draw()
fresh(plot)
assert plot.text_artist("x").get_text() == "Position [mm]"
assert plot.axis_label("x") == "Position [mm]"
# a double click opens the window of the label
spot = label_middle(plot, "z")
click(plot, *spot)
mouse(plot, "button_press_event", *spot, dblclick=True)
mouse(plot, "button_release_event", *spot)
settle(4)
window = plot._dialogs.get("label-z")
assert isinstance(window, aplot.TextStyleDialog), list(plot._dialogs)
window.size_var.set("17")
window.apply()
settle(4)
fresh(plot)
assert round(plot.text_artist("z").get_fontsize()) == 17
window.close()
# `Reset dragged texts` puts all three back
plot.reset_text_offsets()
settle(2)
assert all(near(plot.text_offset[name], (0.0, 0.0)) for name in ("x", "y", "z"))
print("the labels of the axes in space are dragged and written ok")

# -- 5. the Z axis, the colour bar and the colour scale ------------------------
dialog.v3_zmin_var.set("-5")
dialog.v3_zmax_var.set("20")
settle(4)
fresh(plot)
assert near(plot.ax3d.get_zlim(), (-5.0, 20.0)), plot.ax3d.get_zlim()
dialog.v3_zmin_var.set("")
dialog.v3_zmax_var.set("")
settle(4)
fresh(plot)
assert near(plot.ax3d.get_zlim(), (0.0, 10.0)), plot.ax3d.get_zlim()
dialog.sf_bar_var.set(True)
dialog._apply()
settle(4)
assert "y" in plot.hist2d_bars, "the colour bar is switched on"
assert near(plot.color_bar_box("y"), aplot.BAR_BOX_3D)
bar = plot.hist2d_bars["y"]
assert bar.mappable is plot.surface_artists["y"][0]
dialog.sf_vmin_var.set("2")
dialog.sf_vmax_var.set("8")
settle(4)
norm = plot.hist2d_bars["y"].mappable.norm
assert near((norm.vmin, norm.vmax), (2.0, 8.0))
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -30.0))
dialog.sf_edges_var.set(True)
dialog._apply()
settle(4)
assert plot.surface_cfg["y"]["edges"] is True
print("the Z axis, the colour bar and the colour scale ok")

# -- 6. the exported program and the saved diagram -----------------------------
script = plot.to_script()
compile(script, "exported", "exec")
assert "projection='3d'" in script and "ax3d.plot_surface(" in script
assert "ax3d.view_init(elev=30.0, azim=-30.0)" in script, [
    line for line in script.splitlines() if "view_init" in line]
assert "ax3d.set_zlabel('Field [V/m]'" in script
assert "ax3d.set_xlabel('Position [mm]'" in script
assert "fig.colorbar(surf_s1" in script
document = app.plot_document(plot)
text = repr(document)
assert "view3d" in text and "surface3d" in text
plot.set_view3d(elev=10, azim=10, box=[1, 1, 1])
plot.draw()
app.apply_plot_document(document)
settle(6)
plot = app.open_windows()[-1]
assert plot.is_3d() and plot.ax3d is not None
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -30.0)), plot.view3d
assert plot.view3d["zlabel"] == "Field [V/m]"
assert "y" in plot.hist2d_bars
print("the exported program and the saved diagram keep the view ok")

# -- 7. to a flat surface and back: the axes follow the style ------------------
dialog = plot.open_series_dialog(plot.series["y"])
settle(6)
dialog.plot_style_var.set(aplot.name_of(aplot.PLOT_STYLES, "pcolor", None))
dialog._on_style_changed()
settle(6)
assert not plot.is_3d() and plot.ax3d is None
assert plot.ax.axison, "the flat axes are back"
assert plot.surface_artists["y"][0].axes is plot.ax
assert dialog.pcolor_box.winfo_manager() and not dialog.surface3d_box.winfo_manager()
fresh(plot)
assert plot.text_artist("x") is plot.ax.xaxis.label
assert plot.text_at(*label_middle(plot, "x")) == "x"
dialog.plot_style_var.set(aplot.name_of(aplot.PLOT_STYLES, "surface3d", None))
dialog._on_style_changed()
settle(6)
assert plot.is_3d() and plot.ax3d is not None and not plot.ax.axison
assert plot.surface_artists["y"][0].axes is plot.ax3d
assert near((plot.view3d["elev"], plot.view3d["azim"]), (30.0, -30.0))
close_all()
print("a surface changes between flat and space ok")

# -- 8. points scattered freely are joined into triangles ----------------------
rng = np.random.default_rng(5)
px, py = rng.uniform(-3, 3, 200), rng.uniform(-2, 2, 200)
cloud = pd.DataFrame({"x": px, "y": py, "z": np.sin(px) * np.cos(py)})
app.table.set_dataframe(cloud, check_all=True)
settle(2)
plot = app.open_plot("surface3d")
settle(8)
assert plot.ax3d is not None and len(plot.surface_artists["y"]) == 1
script = plot.to_script()
compile(script, "exported", "exec")
assert "ax3d.plot_trisurf(" in script
close_all()
print("scattered points are drawn as a surface of triangles ok")

# -- 9. the frame a diagram opens with -----------------------------------------
app.table.set_dataframe(grid, check_all=True)
settle(2)
for style in ("pcolor", "contour", "contourf"):
    plot = app.open_plot(style)
    settle(6)
    assert plot.frame_cfg["style"] == "box_out", (style, plot.frame_cfg["style"])
    assert all(spine.get_visible() for spine in plot.ax.spines.values()), style
    close_all()
usual = aplot.code_of(aplot.FRAME_STYLES, settings.get("frame", "style"), "none")
for style in ("line", "hist2d", "surface3d"):
    plot = app.open_plot(style)
    settle(6)
    assert plot.frame_cfg["style"] == usual, (style, plot.frame_cfg["style"])
    close_all()
print("a flat surface opens with a frame and ticks pointing outwards ok")

print("ALL OK")
